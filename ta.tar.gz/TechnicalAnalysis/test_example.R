library(testthat)
library(readr)

# Define your test function
test_that("ema CSV Test", {
  # Read the CSV data
  data <- read_csv("compdir/AAPL.US.csv")
  
  # Perform tests
  expect_true(nrow(data) > 0, "Data loaded successfully")
  expect_equal(ncol(data), 3, "Data has expected number of columns")
  expect_true(all(c("column1", "column2", "column3") %in% colnames(data)), "Columns names are correct")
  # Add more tests as needed
})