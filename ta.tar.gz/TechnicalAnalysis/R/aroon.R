# """Aroon & Aroon Oscillator (AROON)

# Aroon attempts to identify if a security is trending and how strong.

# Sources:
#     https://www.tradingview.com/wiki/Aroon
#     https://www.tradingtechnologies.com/help/x-study/technical-indicator-definitions/aroon-ar/

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     length (int): It's period. Default: 14
#     scalar (float): How much to magnify. Default: 100
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.DataFrame: aroon_up, aroon_down, aroon_osc columns.
# """

#' @export
aroon <- function(.high=NULL, .low=NULL, ohlc, n=14L, scalar=1, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
    }
    
    # Validate    
    .high <- vector.check.minlength(.high, n+1)
    .low <- vector.check.minlength(.low, n+1)

    if (is.null(.high) || is.null(.low))
        return (NULL)

 
    # Calculate
    # periods_from_hh <- rollapplyr(.high, width = n, FUN=function(x) { which.max(rev(x))) }, fill=NA)
    periods_from_hh <- (n+1) - roll_idxmax(.high, width = n+1) 
    periods_from_ll <- (n+1) - roll_idxmin(.low, width = n+1)  

    aroon_up = aroon_down = scalar
    aroon_up <- aroon_up * (1 - (periods_from_hh / length))
    aroon_down <- aroon_down * (1 - (periods_from_ll / length))
    aroon_osc <- aroon_up - aroon_down

    # Offset
    if (is.integer(offset) && offset != 0L) {
        aroon_up <- shift(aroon_up, offset)
        aroon_dn <- shift(aroon_dn, offset)
        aroon_osc <- shift(aroon_osc, offset)
    }

    # Fill
    aroon_up <- vec_fill(aroon, ...)
    aroon_dn <- vec_fill(aroon_dn, ...)
    aroon_osc <- vec_fill(aroon_osc, ...)

 
    # Name and Category
    aroon_up.name <- paste("aroonu", n, sep="_")
    aroon_down.name <- paste("aroond", n, sep="_")
    aroon_osc.name <- paste("aroonosc", n, sep="_")

    arron <- bind_cols(!!aroon_up.name := arron_up, !!aroon_down.name := arron_down, !!aroon_osc.name := aroon_osc)
    attr(aroon, "name") <- paste("aroon", n, sep="_")
    attr(aroon, "category") <- "trend"

    return (aroon)
}
