# """Bias (BIAS)

# Rate of change between the source and a moving average.

# Sources:
#     Few internet resources on definitive definition.
#     Request by Github user homily, issue #46

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): The period. Default: 26
#     mamode (str): See ``help(ta.ma)``. Default: 'sma'
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """



# Awesome Oscillator (bias)

# The Awesome Oscillator is an indicator used to measure a security's
# momentum. bias is generally used to affirm trends or to anticipate
# possible reversals.

# Sources:
#     https://www.tradingview.com/wiki/Awesome_Oscillator_(bias)
#     https://www.ifcm.co.uk/ntx-indicators/awesome-oscillator

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     fast (int): The short period. Default: 5
#     slow (int): The long period. Default: 34
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
#' @export
bias <- function(.close=NULL, ohlc, n=26L, mamode="sma", offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }
    
    # Validate    
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    .ma <- ma(mamode)

    # Calculate
    bma <- .ma(.close, n)
    bias <- (.close / bma) - 1

    
    # Offset
    if (is.integer(offset) && offset != 0L)
        bias <- shift(bias, offset)

    # Fill
    bias <- vec_fill(bias, ...)


    # Name and Category
    attr(bias, "name") <- paste("bias", mamode, n, sep="_")
    attr(bias, "category") <- "momentum"

    return (bias)
}
