# """Decreasing

# Returns True if the series is decreasing over a period, False otherwise.
# If the kwarg 'strict' is True, it returns True if it is continuously
# decreasing over the period. When using the kwarg 'asint', then it
# returns 1 for True or 0 for False.

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 1
#     strict (bool): If True, checks if the series is continuously
#         decreasing over the period. Default: False
#     percent (float): Percent as an integer. Default: None
#     asint (bool): Returns as binary. Default: True
#     drift (int): The difference period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
decreasing <- function(.close=NULL, ohlc, n=1L, strict=TRUE, asint=TRUE, percent=FALSE, drift=1L, offset=0L, ..., append=FALSE) {

    # Validate

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)    

    if (is.null(.close))
        return (NULL)

    drift <- ifelse(missing(drift), 1L, as.integer(drift))
    strict <- ifelse(strict, FALSE, as.logical(strict))
    asint <- ifelse(asint, TRUE, as.logical(asint))
    percent <- ifelse(is.percent(percent), FALSE, as.integer(percent))


    .ma <- ma(mamode)

    
    # Calculate
    close_ <- ifelse(percent, (1 - 0.01 * percent) * .close, .close)
    if (strict) {
        # Returns value as float64? Have to cast to bool
        decreasing <- close < shift(close_, drift)
        for (x in 3:(length + 1))
            decreasing <- decreasing & (close.shift(x - (drift + 1)) < close_.shift(x - drift))

        # decreasing.fillna(0, inplace=True)
        # decreasing <- decreasing.astype(bool)
    }
    else {
        decreasing <- diff(close_, n) < 0
    }

    if (asint)
        decreasing <- as.integer(decreasing)

    # Offset
    if (is.integer(offset) && offset != 0L)
        decreasing <- shift(decreasing, offset)

    # Fill
    decreasing <- vec_fill(decreasing, ...)


    # Name and Category
    percent <- ifelse(percent, paste("p", 0.01 * percent, sep="_"), "")
    props <- ifelse(strict, "sdec", "dec")

    attr(decreasing, "name") <- paste(props, n, percent, sep="_")
    attr(decreasing, "category") <- "trend"

    return (decreasing)
}