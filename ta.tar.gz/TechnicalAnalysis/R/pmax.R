# """Rolling pmax
# Calculates the pmax over a rolling period.

# WARNING: This function may leak future data when used for machine learning.
#     Setting lookahead=False does not currently prevent leakage.
#     See https://github.com/twopirllc/pandas-ta/issues/667.
# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 30
#     offset (int): How many periods to offset the result. Default: 0
# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method
# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_max
#' @export
pmax <- function(.close=NULL, ohlc, n = 10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    pmax <- roll_max(.close, n, online=FALSE)
    
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        pmax <- shift(pmax, offset)

    # Fill
    pmax <- vec_fill(pmax, ...)

    # Name and Category
    attr(pmax, "name") <- paste("pmax", n, sep="_")
    attr(pmax, "category") <- "pivot"

    return (pmax)
}
