# """Archer Moving Averages Trends (AMAT)

# Archer Moving Averages Trends (AMAT) developed by Kevin Johnson provides
# creates both long run ``help(ta.long_run)`` and short run
# ``help(ta.short_run)`` trend signals given two moving average speeds,
# fast and slow. The long runs and short runs are binary Series where '1'
# is a trend and '0' is not a trend.

# Sources:
#     https://www.tradingview.com/script/Z2mq63fE-Trade-Archer-Moving-Averages-v1-4F/

# Args:
#     close (pd.Series): Series of 'close's
#     fast (int): The period of the fast moving average. Default: 8
#     slow (int): The period of the slow moving average. Default: 21
#     lookback (int): Lookback period for long_run and short_run. Default: 2
#     mamode (str): See ``help(ta.ma)``. Default: 'ema'
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     run_length (int): Trend length for OBV long and short runs. Default: 2
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.DataFrame: AMAT_LR, AMAT_SR columns.
# """
#' @export
amat <- function(.close=NULL, fast=9L, slow=21L, loopback=2L, mamode="ema", offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }
    
    # Validate    
    .close <- vector.check.minlength(.close, max(fast, slow, loopback))
    
    if (is.null(.close))
        return (NULL)

 
    # Calculate
    .ma <- ma(mamode)
   
    fast_ma <- .ma(.close, n=fast)
    slow_ma <- .ma(.close, n=slow)
    
    mas_long <- long_run(fast_ma, slow_ma, length=lookback)
    mas_short <- short_run(fast_ma, slow_ma, length=lookback)


    # Offset
    if (is.integer(offset) && offset != 0L) {
        mas_long <- shift(mas_long, offset)
        mas_short <- shift(mas_short, offset)        
    }

    # Fill
    mas_long <- vec_fill(mas_long, ...)
    mas_short <- vec_fill(mas_short, ...)
    
 
    # Name and Category
    aroon_up.name <- paste("aroonu", n, sep="_")
    aroon_down.name <- paste("aroond", n, sep="_")
    aroon_osc.name <- paste("aroonosc", n, sep="_")

    arron <- bind_cols(!!aroon_up.name := arron_up, !!aroon_down.name := arron_down, !!aroon_osc.name := aroon_osc)
    attr(aroon, "name") <- paste("aroon", n, sep="_")
    attr(aroon, "category") <- "trend"

    return (aroon)
}


