# """ Year - Quarter
#  Mon=1
#' @importFrom lubridate year quarter
#' @export
yearquarter <- function(.date=NULL, ohlc, sep="", offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("date" %in% names(ohlc))
        .date <- ohlc$date
    }

    # Validate
    if (is.null(.date) || !is.Date(.date))
        return (NULL)


    # Calculate
    # create a string for year and quarter
    yearquarter <- paste(year(.date), sprintf("%02d", quarter(.date)), sep=sep)

    # Offset
    if (is.integer(offset) && offset != 0L)
        yearquarter <- shift(yearquarter, offset)

    # Fill
    yearquarter <- vec_fill(yearquarter, ...)

    # Name and Category
    attr(yearquarter, "name") <- paste("yearquarter")
    attr(yearquarter, "category") <- "datetime"


    # Prefix/Suffix
    year_quarter <- name_append(year_quarter, ...)


    # Append
    if (append && !missing(ohlc)) {
        ohlc[[attr(year_quarter, "name")]] = year_quarter
        return(ohlc)
    }


    return (yearquarter)
}
