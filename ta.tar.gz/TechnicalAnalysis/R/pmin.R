# """Rolling pmin
# Calculates the pmin over a rolling period.

# WARNING: This function may leak future data when used for machine learning.
#     Setting lookahead=False does not currently prevent leakage.
#     See https://github.com/twopirllc/pandas-ta/issues/667.
# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 30
#     offset (int): How many periods to offset the result. Default: 0
# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method
# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_min
#' @export
pmin <- function(.close=NULL, ohlc, n = 10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    pmin <- roll_min(.close, n, online=FALSE)
    
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        pmin <- shift(pmin, offset)

    # Fill
    pmin <- vec_fill(pmin, ...)

    # Name and Category
    attr(pmin, "name") <- paste("pmin", n, sep="_")
    attr(pmin, "category") <- "pivot"

    return (pmin)
}
