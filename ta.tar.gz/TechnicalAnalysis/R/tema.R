# """Triple Exponential Moving Average (TEMA)

# A less laggy Exponential Moving Average.

# Sources:
#     https://www.tradingtechnologies.com/help/x-study/technical-indicator-definitions/triple-exponential-moving-average-tema/

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     adjust (bool): Default: True
#     presma (bool, optional): If True, uses SMA for initial value.
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export 
tema <- function(.close=NULL, ohlc, n=10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    # Calculate
    ema1 = ema(close=close, n=n)
    ema2 = ema(close=ema1, n=n)
    ema3 = ema(close=ema2, n=n)
    tema = 3 * (ema1 - ema2) + ema3


    # Offset
    if (is.integer(offset) && offset != 0L)
        tema <- shift(tema, offset)

    # Fill
    tema <- vec_fill(tema, ...)

    # Name and Category
    attr(tema, "name") <- paste("tema", n, sep="_")
    attr(tema, "category") <- "overlap"

    # Append
    # if (append)
    #    bind_cols(ohlc, tema)

    return (tema)
}
