
# Ehler's Super Smoother Filter
# http://traders.com/documentation/feedbk_docs/2014/01/traderstips.html
# m.pi, m.sqrt2 use machine pi and sqrt approximation
np_ssf <- function(x, n, m.pi, m.sqrt2) {
    m <- length(x)
    result <- c()
    ratio <- m.sqrt2 / n
    a = exp(-m.pi * ratio)
    b = 2 * a * cos(180 * ratio)
    c = a * a - b + 1

    for (i in 2:m)
        result[i] <- 0.5 * c * (x[i] + x[i - 1]) + b * result[i - 1] - a * a * result[i - 2]

    return (result)
}

# John F. Ehler's Super Smoother Filter by Everget (2 poles), Tradingview
# https://www.tradingview.com/script/VdJy0yBJ-Ehlers-Super-Smoother-Filter/

np_ssf_everget <- function(x, n, m.pi, m.sqrt2) {
    m <- length(x)
    result <- c()
    arg <- m.pi * m.sqrt2 / n
    
    a = exp(-arg)
    b = 2 * a * cos(arg)

    for (i in 2:m) 
        result[i] = 0.5 * (a * a - b + 1) * (x[i] + x[i - 1]) + b * result[i - 1] - a * a * result[i - 2]

    return (result)
}

# """Ehler's Super Smoother Filter (SSF) © 2013

# John F. Ehlers's solution to reduce lag and remove aliasing noise with
# his research in Aerospace analog filter design. This implementation had
# two poles. Since SSF is a (Recursive) Digital Filter, the number of
# poles determine how many prior recursive SSF bars to include in the
# filter design.

# For Everget's calculation on TradingView, set arguments:
#     m.pi = np.m.pi, m.sqrt2 = np.sqrt(2)

# WARNING: This function may leak future data when used for machine learning.
#     Setting lookahead=False does not currently prevent leakage.
#     See https://github.com/twom.pirllc/pandas-ta/issues/667.

# Sources:
#     http://traders.com/documentation/feedbk_docs/2014/01/traderstips.html
#     https://www.tradingview.com/script/VdJy0yBJ-Ehlers-Super-Smoother-Filter/
#     https://www.mql5.com/en/code/588

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 20
#     everget (bool): Everget's implementation of ssf that uses m.pi
#         instead of 180 for the b factor of ssf. Default: False
#     m.pi (float): The value of m.PI to use. The default is Ehler's
#         truncated value 3.14159. Adjust the value for more precision.
#         Default: 3.14159
#     m.sqrt2 (float): The value of sqrt(2) to use. The default is Ehler's
#         truncated value 1.414. Adjust the value for more precision.
#         Default: 1.414
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
ssf <- function(.close=NULL, ohlc, n=20L, m.pi=3.14159, m.sqrt2=1.414, everget=FALSE, offset=0L, ..., append=FALSE) {
    
    # Validate
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }
    if (is.null(.close))
        return (NULL)

    # Calculate
    if (everget)
        ssf <- np_ssf_everget(.close, n, m.pi, m.sqrt2)
    else
        ssf <- np_ssf(.close, n, m.pi, m.sqrt2)


    # Offset
    if (is.integer(offset) && offset != 0L)
        mon <- shift(ssf, offset)

    # Fill
    ssf <- vec_fill(ssf, ...)

    # Name and Category

    attr(ssf, "name") <- if (everget) paste("ssfe", n, sep="_") else paste("ssf", n, sep="_")
    attr(ssf, "category") <- "overlap"

    return (ssf)
}
