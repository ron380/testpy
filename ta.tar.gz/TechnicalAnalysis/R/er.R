# """Efficiency Ratio (ER)

# The Efficiency Ratio was invented by Perry J. Kaufman and presented in
# his book "New Trading Systems and Methods". It is designed to account
# for market noise or volatility.

# It is calculated by dividing the net change in price movement over
# N periods by the sum of the absolute net changes over the same N periods.

# Sources:
#     https://help.tc2000.com/m/69404/l/749623-kaufman-efficiency-ratio

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_sum
#' @export
er <- function(.close=NULL, ohlc, n=10L, drift=1L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)


    # Calculate
    abs_diff = abs(diff(.close, n))    
    abs_volatility_rsum = roll_sum(abs_diff, n, online=FALSE)

    er = abs_diff / abs_volatility_rsum
    
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        er <- shift(er, offset)

    # Fill
    er <- vec_fill(er, ...)

    # Name and Category
    attr(er, "name") <- paste("er", n, sep="_")
    attr(er, "category") <- "momentum"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (er)
}
