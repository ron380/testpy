# """wildeR's Moving Average (RMA)

# The WildeR's Moving Average is simply an EMA with a modified
# alpha = 1 / length.

# Sources:
#     https://tlc.thinkorswim.com/center/reference/Tech-Indicators/studies-library/V-Z/WildersSmoothing
#     https://www.incrediblecharts.com/indicators/wilder_moving_average.php

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
rma <- function(.close=NULL, ohlc, n=10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    # Calculation
    # https://bookdown.org/kochiuyu/technical-analysis-with-r-second-edition/simple-moving-average-rma.html
    alpha <- ifelse(n > 0, 1 / n, 0.5)

    rma <- c()
    # this is done automatically
    # rma <- close.ewm(alpha=alpha, adjust=False).mean()


    rma[1:(n-1)] <- NA
    for (i in n:length(.close)) {
        rma[i] <- base::mean(.close[(i-n+1):i])
    }
    # print(rma)
    # use roll_mean
  
    # Offset
    if (is.integer(offset) && offset != 0L)
        rma <- shift(rma, offset)

    # Fill
    rma <- vec_fill(rma, ...)

    # Name and Category
    attr(rma, "name") <- paste("rma", n, sep="_")
    attr(rma, "category") <- "overlap"

    return (rma)
}
