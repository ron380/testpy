# """True Range

# An method to expand a classical range (high minus low) to include
# possible gap scenarios.

# Sources:
#     https://www.macroption.com/true-range/

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     prenan (bool): If True, behave like TA Lib with some initial nan
#         based on drift (typically 1). Default: False
#     drift (int): The shift period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.Series: New feature
# """

#' @export
true_range <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, prenan=TRUE, drift=1L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))

        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }
    
    # Validate
    if (is.null(.high) || is.null(.low) || is.null(.close)  )
        return (NULL)
 
    # Calculate
    hl_range <- non_zero_range(high, low)
    prev_close <- close.shift(drift)  # previous close
    ranges <- lapply(list(hl_range, .high - prev_close, prev_close - .low), abs)
    
    true_range <- do.call(pmax, ranges)
    if (prenan)
        true_range[1:drift] <- NA


    # Offset
    if (is.integer(offset) && offset != 0L)
        true_range <- shift(true_range, offset)

    # Fill
    true_range <- vec_fill(true_range, ...)

 
    # Name and Category
    true_range.name <- paste("true_range", drift)
    true_range.category <- "volatility"

    return (true_range)
}