# """Elder Ray Index (ERI)

# Elder's Bulls Ray Index contains his Bull and Bear Powers. Which are
# useful ways to look at the price and see the strength behind the market.
# Bull Power measures the capability of buyers in the market, to lift
# prices above an average consensus of value.

# Bears Power measures the capability of sellers, to drag prices below
# an average consensus of value. Using them in tandem with a measure of
# trend allows you to identify favourable entry points.

# Sources:
#     https://admiralmarkets.com/education/articles/forex-indicators/bears-and-bulls-power-indicator

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 14
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.DataFrame: bull power and bear power columns.
# """
#' @export
eri <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, n=14L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }

    # Validate
    .high <- vector.check.minlength(.high, n)
    .low <- vector.check.minlength(.low, n)
    .close <- vector.check.minlength(.close, n)

    if (is.null(.high) || is.null(.low) || is.null(.close))
        return (NULL)

    # Calculate
    ema_ <- ema(.close, n=n)
    bull <- .high - ema_
    bear <- .low - ema_

    # Offset
    if (is.integer(offset) && offset != 0L) {
        bull <- shift(bull, offset)
        bear <- shift(bear, offset)
    }

    # Fill
    bull <- vec_fill(bull, ...)
    bear <- vec_fill(bear, ...)

    # Name and Category
    data <- list(bull, bear)
    setNames(data, c(paste("bullp", n, sep="_"), paste("bearp", n, sep="_")))


    attr(eri, "name") <- paste("eri", n, sep="_")
    attr(eri, "category") <- "momentum"

    return (eri)
}
