# """Day of week 
#  Mon=1
#' @importFrom lubridate month
#' @export
month <- function(.date=NULL, ohlc, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("date" %in% names(ohlc))
        .date <- ohlc$date
    }

    # Validate
    if (is.null(.date) || !is.Date(.date))
        return (NULL)


    # Calculate
    month <- month(.date)

    # Offset
    if (is.integer(offset) && offset != 0L)
        month <- shift(month, offset)

    # Fill
    month <- vec_fill(month, ...)

    # Name and Category
    attr(month, "name") <- paste("month")
    attr(month, "category") <- "datetime"


    # Prefix/Suffix
    month <- name_append(month, ...)


    # Append
    if (append && !missing(ohlc)) {
        ohlc[[attr(month, "name")]] = month
        return(ohlc)
    }


    return (month)
}
