# """OHLC4

# OHLC4 is the average of open, high, low and close.

# Args:
#     open_ (pd.Series): Series of 'open's
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value). Only works if
#         result is offset.

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
ohlc4 <- function(.open=NULL, .high=NULL, .low=NULL, .close=NULL, ohlc, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("open" %in% names(ohlc))
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))

        .open <- ohlc$open
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }
    
    # Validate
    if (is.null(.open) || is.null(.high) || is.null(.low) || is.null(.close)  )
        return (NULL)

 
    # Calculate
    ohlc4 <- 0.25 * (.open + .high + .low + .close) 


    # Offset
    if (is.integer(offset) && offset != 0L)
        ohlc4 <- shift(ohlc4, offset)

    # Fill
    ohlc4 <- vec_fill(ohlc4, ...)

 
    # Name and Category
    ohlc4.name <- "ohlc4"
    ohlc4.category <- "overlap"

    return (ohlc4)
}
