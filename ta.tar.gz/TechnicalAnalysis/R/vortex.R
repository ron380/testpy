# """Vortex

# Two oscillators that capture positive and negative trend movement.

# Sources:
#     https://stockcharts.com/school/doku.php?id=chart_school:technical_indicators:vortex_indicator

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     length (int): ROC 1 period. Default: 14
#     drift (int): The difference period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.DataFrame: vip and vim columns
# """
#' @importFrom roll roll_sum
#' @export
vortex <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, n=14L, drift=1L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }
    
    # Validate
    .high <- vector.check.minlength(.high, .length)
    .low <- vector.check.minlength(.low, .length)
    .close <- vector.check.minlength(.close, .length)

    if (is.null(.high) || is.null(.low) || is.null(.close))
        return (NULL)

 
    # Calculate
    tr <- true_range(.high=.high, .low=.low, .close=.close)
    tr_sum <- roll_sum(tr, n)

    vmp <- abs(.high - shift(.low, drift))
    vmm <- abs(.low - shift(.high, drift))

    vip <- roll_sum(vmp, n) / tr_sum
    vim <- roll_sum(vmm, n) / tr_sum

    # Offset
    if (is.integer(offset) && offset != 0L) {
        vip <- shift(vip, offset)
        vim <- shift(vim, offset)
    }

    # Fill
    vip <- vec_fill(vip, ...)
    vim <- vec_fill(vim, ...)

 
    # Name and Category
    vip.name <- paste("vtxp", n, sep="_")
    vim.name <- paste("vtxm", n, sep="_")
    
    vortex <- bind_cols(!!vip.name := vip, !!vim.name := vim)

    attr(vortex, "name") <- paste("vtx", n, sep="_")
    attr(vortex, "category") <- "trend"

    return (vortex)
}