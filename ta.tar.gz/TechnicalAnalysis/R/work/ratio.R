# """Price Ratio

# Calculates the price ratio of a Series compared the previous Close.
# See also: help(df.ta.percent_return) for additional **kwargs a valid 'df'.

# Sources:
#     https://stackoverflow.com/questions/31287552/logarithmic-returns-in-pandas-dataframe

# Calculation:
#     Default Inputs:
#         length=1, cumulative=False
#     PCTRET = open/(length)
#     or
#     PCTRET = (open - close)/close.shift(length)
#     CUMPCTRET = PCTRET.cumsum() if cumulative

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period.  Default: 20
#     cumulative (bool): If True, returns the cumulative returns.  Default: False
#     offset (int): How many periods to offset the result.  Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """

#' @export
mom <- function(.open=NULL, .close=NULL, ohlc, scalar=1, offset=0L, ..., append=FALSE) {
    
    # Validate
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        stopifnot("open" %in% names(ohlc))
        .open <- ohlc$open
        .close <- ohlc$close

    }

    if (is.null(.close) || is.null(.open))
        return (NULL)

    # Calculate
    fff = 1 if pct else 0
    pct = scalar * (open_/close.shift(periods=length) - fff)

    if cumulative:
        pct = pct.cumsum()


    # Offset
    if (is.integer(offset) && offset != 0L)
        mon <- shift(mom, offset)

    # Fill
    mom <- vec_fill(mom, ...)

    # Name and Category
    attr(mom, "name") <- paste("MOM", n, sep="_")
    attr(mom, "category") <- "momentum"

    return (mom)
}


from pandas import Series
from numpy import log, nan, roll
from pandas_ta._typing import DictLike, Int, IntFloat
from pandas_ta.utils import v_bool, v_offset, v_pos_default, v_series, v_scalar


def ratio(
    open_: Series, close: Series, length: Int = None, scalar: IntFloat = None, pct: bool = None,
    cumulative: bool = None,
    offset: Int = None, **kwargs: DictLike
) -> Series:
    """Price Ratio

    Calculates the price ratio of a Series compared the previous Close.
    See also: help(df.ta.percent_return) for additional **kwargs a valid 'df'.

    Sources:
        https://stackoverflow.com/questions/31287552/logarithmic-returns-in-pandas-dataframe

    Calculation:
        Default Inputs:
            length=1, cumulative=False
        PCTRET = open/(length)
        or
        PCTRET = (open - close)/close.shift(length)
        CUMPCTRET = PCTRET.cumsum() if cumulative

    Args:
        close (pd.Series): Series of 'close's
        length (int): It's period.  Default: 20
        cumulative (bool): If True, returns the cumulative returns.  Default: False
        offset (int): How many periods to offset the result.  Default: 0

    Kwargs:
        fillna (value, optional): pd.DataFrame.fillna(value)
        fill_method (value, optional): Type of fill method

    Returns:
        pd.Series: New feature generated.
    """


    # Validate Arguments
    close = v_series(close)
    open_ = v_series(open_)
    length = v_pos_default(length, 1)
    offset = v_offset(offset)
    scalar = v_scalar(scalar, 100)
    pct = v_bool(pct, False)

    # Calculate Result
    fff = 1 if pct else 0
    pct = scalar * (open_/close.shift(periods=length) - fff)

    if cumulative:
        pct = pct.cumsum()

    # Offset
    if offset != 0:
        pct = pct.shift(offset)

    # Name and Category
    pct.name = f"{'CUM' if cumulative else ''}RATIO_{length}"
    pct.category = 'transform'

    return pct