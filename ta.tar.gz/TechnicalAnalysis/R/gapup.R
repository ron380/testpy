# """Percent Return

# Calculates the percent return of a Series.
# See also: help(df.ta.gapup) for additional **kwargs a valid 'df'.

# Sources:
#     https://stackoverflow.com/questions/31287552/logarithmic-returns-in-pandas-dataframe

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): Its period. Default: 1
#     cumulative (bool): If True, returns the cumulative returns.
#         Default: False
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.Series: New feature generated.
# """

#' @export 
gapup <- function(.high=NULL, .low=NULL, ohlc, n = 1L, percent=TRUE, scalar=100, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low        
    }

    # Validate
    .high <- vector.check.minlength(.high, n+1)
    .low <- vector.check.minlength(.low, n+1)

    if (is.null(.high) && is.null(.low))
        return (NULL)

    # Calculate (check if rest of parameters are passed)
    gapup <- ratio(.low, .high, n=n, ...)
    if (percent)
        gapup[gapup < 0] <- NA
    else 
        gapup[gapup < scalar] <- NA
        
    # Offset
    if (is.integer(offset) && offset != 0L)
        gapup <- shift(gapup, offset)

    # Fill
    gapup <- vec_fill(roc, ...)

    # Name and Category
    props <- paste0(ifelse(cumulative, "cum", ""), ifelse(percent, "pct", ""))    
    attr(gapup, "name") <- paste(paste0(props, "gapup"), n, sep="_")
    attr(gapup, "category") <- "performance"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (gapup)
}
