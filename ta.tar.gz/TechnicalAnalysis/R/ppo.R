# """Percentage Price Oscillator (PPO)

# The Percentage Price Oscillator is similar to ppo in measuring momentum.

# Sources:
#     https://www.investopedia.com/terms/p/ppo.asp

# Args:
#     close(pandas.Series): Series of 'close's
#     fast(int): The short period. Default: 12
#     slow(int): The long period. Default: 26
#     signal(int): The signal period. Default: 9
#     scalar (float): How much to magnify. Default: 100
#     mamode (str): See ``help(ta.ma)``. Default: 'sma'
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset(int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.DataFrame: ppo, histogram, signal columns
# """
#' @export
ppo <- function(.close=NULL, ohlc, fast=12L, slow=26L, offset=0L, scalar=100, mammode="sma", ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }
    
    # Validate
    if (slow < fast)
        return (NULL)
    
    .length <- max(fast, slow, signal)
    .close <- vector.check.minlength(.close, .length)

    if (is.null(.close))
        return (NULL)

    .ma <- ma(mamode)

    # Calculate
    fastma <- .ma(.close, n=fast)
    slowma <- .ma(.close, n=slow)
    ppo <- scalar * (fastma - slowma) / slowma

    signalma <- ema(ppo, n=signal)
    histogram <- ppo - signalma


    # Offset
    if (is.integer(offset) && offset != 0L) {
        ppo <- shift(ppo, offset)
        histogram <- shift(histogram, offset)
        signalma <- shift(signalma, offset)
    }

    # Fill
    ppo <- vec_fill(ppo, ...)
    histogram <- vec_fill(histogram, ...)
    signalma <- vec_fill(signalma, ...) 

 
    # Name and Category
    props = paste(fast, slow, signal, sep="_")
    data <- list(ppo, histogram, signalma)
    data <- setNames(data, c(paste("ppo", props, sep="_"), paste("histogram", props, sep="_"), paste("signalma", props, sep="_")))
    
    attr(ppo, "name") <- paste("ppo", props, sep="_")
    attr(ppo, "category") <- "momentum"

    return (ppo)
}
