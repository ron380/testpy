

# """Center of Gravity (CG)

# The Center of Gravity Indicator by John Ehlers attempts to identify
# turning points while exhibiting zero lag and smoothing.

# Sources:
#     http://www.mesasoftware.com/papers/TheCGOscillator.pdf

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): The length of the period. Default: 10
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
cg <- function(.close=NULL, ohlc, n=10L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }
    
    # Validate    
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)


    # Calculate
    coefficients <- 1:n
    numerator < roll_sum(.close, n, coefficients)
    cg <-  -numerator / roll_sum(.close.rolling, n)
 

    # Offset
    if (is.integer(offset) && offset != 0L)
        cg <- shift(cg, offset)

    # Fill
    cg <- vec_fill(cg, ...)


    # Name and Category
    attr(cg, "name") <- paste("cg", mamode, n, sep="_")
    attr(cg, "category") <- "momentum"

    return (cg)
}
