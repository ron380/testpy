# """Correlation Trend Indicator (CTI)

# The Correlation Trend Indicator is an oscillator created
# by John Ehler in 2020. It assigns a value depending on how close prices
# in that range are to following a positively- or negatively-sloping
# straight line. Values range from -1 to 1. This is a wrapper
# for ta.linreg(close, r=True).

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 12
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: Series of the CTI values for the given period.
# """
#' @importFrom roll roll_sum
#' @export
cti <- function(.close=NULL, ohlc, n=12L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    cti <- linreg(.close, n, r=TRUE)
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        cti <- shift(cti, offset)

    # Fill
    cti <- vec_fill(cti, ...)

    # Name and Category
    attr(cti, "name") <- paste("cti", n, sep="_")
    attr(cti, "category") <- "momentum"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (cti)
}
