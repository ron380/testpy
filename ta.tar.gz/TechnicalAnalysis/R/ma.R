# """Simple MA Utility for easier MA selection

# Available MAs:
#     dema, ema, fwma, hma, linreg, midpoint, pwma, rma, sinwma, sma, ssf,
#     swma, t3, tema, trima, vidya, wma

# Examples:
#     ema8 = ta.ma("ema", df.close, length=8)
#     sma50 = ta.ma("sma", df.close, length=50)
#     pwma10 = ta.ma("pwma", df.close, length=10, asc=False)

# Args:
#     name (str): One of the Available MAs. Default: "ema"
#     source (pd.Series): The 'source' Series.

# Kwargs:
#     Any additional kwargs the MA may require.

# Returns:
#     pd.Series: New feature generated.
# """
# _mas = [
#     "dema", "ema", "fwma", "hma", "linreg", "midpoint", "pwma", "rma",
#     "sinwma", "sma", "ssf", "swma", "t3", "tema", "trima", "vidya", "wma"
# ]
#' @export
ma <- function(mamode=c("dema", "ema", "fwma", "hma", "linreg", "midpoint", "pwma", 
                        "rma", "sinwma", "sma", "ssf", "swma", "t3", "tema", "trima", "vidya", "wma")) {

    # if not specified
    #    name = _mas[1]
    if (missing(mamode))
        return (ema)
    name <- match.arg(mamode)
    
    # to get a function from its name use `get`` or `match.fun`
    return (match.fun(name))
    # return (get(name))
}