# @njit
# def np_ema(x: np.ndarray, n: int):
#     m = x.size
#     result = np.zeros(m)
#     a = 1 / (n + 1)
#     for i in range(1, m):
#         result[i] = a * x[i - 1] + (1 - a) * x[i]
#     result[0] = np.nan
#     return result
#     # return np_prepend(result, n - 1)

# """Exponential Moving Average (EMA)

# The Exponential Moving Average is a more responsive moving average
# compared to the Simple Moving Average (SMA). The weights are determined
# by alpha which is proportional to it's length.  There are several
# different methods of calculating EMA. One method uses just the standard
# definition of EMA and another uses the SMA to generate the initial value
# for the rest of the calculation.

# Sources:
#     https://stockcharts.com/school/doku.php?id=chart_school:technical_indicators:moving_averages
#     https://www.investopedia.com/ask/answers/122314/what-exponential-moving-average-ema-formula-and-how-ema-calculated.asp

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     presma (bool, optional): If True, uses SMA for initial value like
#         TA Lib. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     adjust (bool, optional): Default: False
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
#' @export
ema <- function(.close=NULL, ohlc, n=10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    # zoo library have ewma (set align to right since the default is center)
    # but rollapplyr does rollapply with right allignment
    # > ewma
    # function(x, n) {
    #     rollapply(x, width = n, FUN = function(x) sum(x * 0.5^(1:length(x))), align = "right", fill = NA)
    # }


    # taken from https://bookdown.org/kochiuyu/technical-analysis-with-r-second-edition/exponential-moving-average-ema.html
    # cat("close input\n")
    # print(.close)
    # stop()
    m <- length(.close)
    ema <- c()
    ema[1:(n-1)] <- NA
    ema[n]<- base::mean(.close[1:n], na.omit=TRUE)
    beta <- 2 / (n + 1)
    for (i in (n+1):m)
        ema[i] <- beta * .close[i] + (1 - beta) * ema[i-1]
    
    cat("ema", "\n")
    print(ema)

    # Offset
    if (is.integer(offset) && offset != 0L)
        ema <- shift(ema, offset)

    # Fill
    ema <- vec_fill(ema, ...)

    # Name and Category
    attr(ema, "name") <- paste("ema", n, sep="_")
    attr(ema, "category") <- "overlap"

    return (ema)
}
