# Pretty Good Oscillator (PGO)

# The Pretty Good Oscillator indicator was created by Mark Johnson to
# measure the distance of the current close from its N-day SMA, expressed
# in terms of an average true range over a similar period. Johnson's
# approach was to use it as a breakout system for longer term trades.
# Long if greater than 3.0 and short if less than -3.0.

# Sources:
#     https://library.tradingtechnologies.com/trade/chrt-ti-pretty-good-oscillator.html

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 14
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
#
#' @export
pgo <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, n=14L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }


    # Validate
    .length <- 2 * n
    .high <- vector.check.minlength(.high, .length)
    .low <- vector.check.minlength(.low, .length)
    .close <- vector.check.minlength(.close, .length)

    if (is.null(.high) || is.null(.low) || is.null(.close))
        return (NULL)


    # Calculate
    pgo <- (.close - sma(.close, n=length)) / ema(atr(.high, .low, .close, n=n), n=n)

    # Offset
    if (is.integer(offset) && offset != 0L)
        pgo <- shift(pgo, offset)

    # Fill
    pgo <- vec_fill(pgo, ...)

    # Name and Category
    attr(pgo, "name") <- paste("pgo", n, sep="_")
    attr(pgo, "category") <- "momentum"

    return (pgo)
}