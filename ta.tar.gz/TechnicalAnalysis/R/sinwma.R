# """Sine Weighted Moving Average (SWMA)

# A weighted average using sine cycles. The middle term(s) of the average
# have the highest weight(s).

# Source:
#     https://www.tradingview.com/script/6MWFvnPO-Sine-Weighted-Moving-Average/
#     Author: Everget (https://www.tradingview.com/u/everget/)

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 14
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_sum
#' @export
sinwma <- function(.close=NULL, ohlc, n=14L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    sines <- empty_vector(n)
    for (i in 1:n)
        sines[i] <- sin(i * pi / (n + 1))
    weights <- sines / sum(sines)

    sinwma <- roll_sum(.close, n, weights=weights, online=FALSE)
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        sinwma <- shift(sinwma, offset)

    # Fill
    sinwma <- vec_fill(sinwma, ...)

    # Name and Category
    attr(sinwma, "name") <- paste("sinwma", n, sep="_")
    attr(sinwma, "category") <- "overlap"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (sinwma)
}
