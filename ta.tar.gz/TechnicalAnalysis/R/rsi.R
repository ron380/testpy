#' @export
rsi <- function(.close=NULL, ohlc, n=14L, drift=1L, scalar = 100, mamode="rma", offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)    

    if (is.null(.close))
        return (NULL)

    drift <- ifelse(missing(drift), 1L, as.integer(drift))
    # pick mamode
    .ma <- ma(mamode)

    negative <- diff(.close, drift)
    positive <- negative

    positive[positive < 0] <- 0  # Make negatives 0 for the positive series
    negative[negative > 0] <- 0  # Make positives 0 for the negative series

    positive_avg <- .ma(positive, n=n)
    negative_avg <- .ma(negative, n=n)

    rsi <- scalar * positive_avg / (positive_avg + abs(negative_avg))
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        rsi <- shift(rsi, offset)

    # Fill
    rsi <- vec_fill(rsi, ...)

    # Name and Category
    attr(rsi, "name") <- paste("rsi", mamode, n, sep="_")
    attr(rsi, "category") <- "momentum"

    # Prefix/Suffix
    rsi <- name_append(rsi, ...)

    # Append
    if (append && !missing(ohlc)) {
        # return (bind_cols(ohlc, !!attr(rsi, "name") := rsi))
        # mutate is another way
        ohlc[[attr(rsi, "name")]] = rsi
        return(ohlc)
    }

    return (rsi)
}
