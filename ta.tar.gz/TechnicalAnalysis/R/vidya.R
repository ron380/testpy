# """Variable Index Dynamic Average (VIDYA)

# Variable Index Dynamic Average (VIDYA) was developed by Tushar Chande.
# It is similar to an EMA but it has a dynamically adjusted lookback
# period dependent on relative price volatility as measured by CMO. When
# volatility is high, VIDYA reacts faster to price changes.
# It is often used as moving average or trend identifier.

# Sources:
#     https://www.tradingview.com/script/hdrf0fXV-Variable-Index-Dynamic-Average-VIDYA/
#     https://www.perfecttrendsystem.com/blog_mt4_2/en/vidya-indicator-for-mt4

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 14
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     adjust (bool, optional): Use adjust option for EMA calculation.
#         Default: False
#     sma (bool, optional): If True, uses SMA for initial value for EMA
#         calculation. Default: True
#     talib (bool): If True, uses TA-Libs implementation for CMO.
#         Otherwise uses EMA version. Default: True
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
vidya <- function(.close=NULL, ohlc, n=14L, drift=1L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    # what for?
    arguments <- list(...)
    # drift <- arguments$drift
    m <- length(.close)
    alpha <- 2 / (n + 1)
    abs_cmo <- abs(.cmo(close, n, drift))
    
    # vidya = Series(0, index=close.index)
    vidya <- c()
    # this is done automatically 
    # sma[1:(n)] <- NA
    for (i in seq(n+1, m)) {
        vidya[i] <- alpha * abs_cmo[i] * .close[i] + vidya[i - 1] * (1 - alpha * abs_cmo[i])
    }
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        vidya <- shift(vidya, offset)

    # Fill
    vidya <- vec_fill(vidya, ...)

    # Name and Category
    attr(vidya, "name") <- paste("vidya", n, sep="_")
    attr(vidya, "category") <- "momentum"

    # Append
    # if (append)
    #    bind_cols(ohlc, vidya)

    return (vidya)
}


# """Chande Momentum Oscillator (CMO) Patch
# For some reason: from pandas_ta.momentum import cmo causes
# pandas_ta.momentum.coppock to not be able to import it's
# wma like from pandas_ta.overlap import wma?
# Weird Circular TypeError!?
# """
.cmo <- function(source, n, d) {
    mom <- diff(source, d)
    positive <- clip(mom, lower=0)
    negative <- abs(clip(mom, upper=0))
    pos_sum <- roll_sum(positive, n)
    neg_sum <- roll_sum(negative, n)
    return ((pos_sum - neg_sum) / (pos_sum + neg_sum))
}