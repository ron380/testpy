# """Weighted Moving Average (WMA)

# The Weighted Moving Average where the weights are linearly increasing
# and the most recent data has the heaviest weight.

# Sources:
#     https://en.wikipedia.org/wiki/Moving_average#Weighted_moving_average

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     asc (bool): Recent values weigh more. Default: True
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_sum
#' @export
wma <- function(.close=NULL, ohlc, n=10L, asc=TRUE, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }
    
    # Validate    
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    .ma <- ma(mamode)

    # Calculate
    total_weight <- 0.5 * n * (n + 1)   # total weights using formula
    weights_ <- seq(n)
    weights <- ifelse(asc, weights_ , rev(weights_))
    weights <- weights / total_weight

    wma <- roll_sum(.close, n, weights=weights, online=FALSE)


    # Offset
    if (is.integer(offset) && offset != 0L)
        wma <- shift(wma, offset)

    # Fill
    wma <- vec_fill(wma, ...)


    # Name and Category
    wma.name <- paste("wma", mamode, n, sep="_")
    wma.category <- "overlap"

    return (wma)
}
