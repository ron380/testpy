# """ pivot support/resistance formula """
# """
#     Pivot Points are significant support and resistance levels that can be used to determine potential trades.
#     The pivot points come as a technical analysis indicator calculated using a financial instrument’s high, low, and close value.
#     The pivot point’s parameters are usually taken from the previous day’s trading range.
#     This means you’ll have to use the previous day’s range for today’s pivot points.
#     Or, last week’s range if you want to calculate weekly pivot points or, last month’s range for monthly pivot points and so on.

# """

# # suppress - allow supp/resistance in the pivot formula
#' @export
pivot_lines <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }

    # Validate
    if (is.null(.high) || is.null(.low) || is.null(.close))
        return (NULL)

    arguments <- list(...)

    # Calculate
    .pivot <- (.high + .low + .close) / 3
    pivot.name <- "pp"  # pivot is basically a lagging hlc3

    hl <- .high - .low
    hl.name <- "hl_range"
    h_pivot <- .high - .pivot
    h_pivot.name <- "h_pivot_range"
    l_pivot <- .pivot - .low
    l_pivot.name <- "l_pivot_range"

    # using list with dynamic key names
    pivot_lines <- list(.pivot, hl, h_pivot, l_pivot)
    pivot_lines <- setNames(pivot_lines, c(pivot.name, hl.name, h_pivot.name, l_pivot.name))
    # pivot_lines <- bind_cols(!!.pivot.name := .pivot, !!hl.name := hl, !!h_pivot.name := h_pivot, !!l_pivot.name := l_pivot)
    
    if ("suppress" %in% names(arguments) && arguments$suppress) {        
        # support
        s1 <- (.pivot * 2) - .high
        s1.name <- "s1"
        s2 <- .pivot - hl
        s2.name <- "s2"
        s3 <- .low - (2 * h_pivot)
        s3.name <- "s3"
        s4 <- .low - (3 * h_pivot)
        s4.name <- "s4"
        # resistance
        r1 <- (.pivot * 2) - .low
        r1.name <- "r1"
        r2 <- .pivot + hl
        r2.name <- "r2"
        r3 <- .high + (2 * l_pivot)
        r3.name <- "r3"
        r4 <- .high + (3 * l_pivot)
        r4.name <- "r4"

        # pivot_lines <- bind_cols(pivot_lines, !!r1.name := r1, !!r2.name := r2, !!r3.name := r3, !!r4.name := r4)
        # pivot_lines <- bind_cols(pivot_lines, !!s1.name := s1, !!s2.name := s2, !!s3.name := s3, !!s4.name := s4)
        pivot_line_r <- list(r1, r2, r3, r4)
        pivot_line_r <- setNames(pivot_line_r, c(r1.name, r2.name, r3.name, r4.name))
        pivot_line_s <- list(s1, s2, s3, s4)
        pivot_line_s <- setNames(pivot_line_s, c(s1.name, s2.name, s3.name, s4.name))

        # concatenate
        pivot_lines <- c(pivot_lines, pivot_line_r, pivot_lines_s)
    }

    # Offset
    if (is.integer(offset) && offset != 0L)
        pivot_lines <- shift(pivot_lines, offset)


    # Fill
    pivot_lines <- vec_fill(pivot_lines, ...)

    # Name and Category
    attr(pivot_lines, "name") <- "pivot_lines"
    attr(pivot_lines, "category") <- "pivot"

    return (pivot_lines)
}
