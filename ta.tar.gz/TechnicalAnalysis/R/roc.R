#' Rate of Change (ROC)
#' Rate of Change is an indicator is also referred to as Momentum
#' (yeah, confusingly). It is a pure momentum oscillator that measures the
#' percent change in price with the previous price 'n' (or length)
#' periods ago.
#' Sources:
#'     https://www.tradingview.com/wiki/Rate_of_Change_(ROC)
#' Args:
#'     close (pd.Series): Series of 'close's
#'     length (int): It's period. Default: 1
#'     scalar (float): How much to magnify. Default: 100
#'     talib (bool): If TA Lib is installed and talib is True, Returns
#'         the TA Lib version. Default: True
#'     offset (int): How many periods to offset the result. Default: 0
#' Kwargs:
#'     fillna (value, optional): pd.DataFrame.fillna(value)
#'     fill_method (value, optional): Type of fill method
#' Returns:
#'     pd.Series: New feature generated.
#' @export
roc <- function(.close=NULL, ohlc, n = 10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    # scalar = v_scalar(scalar, 100)

    roc <- 100 * mom(.close, n=n) / shift(.close, n)

    # Offset
    if (is.integer(offset) && offset != 0L)
        roc <- shift(roc, offset)

    # Fill
    roc <- vec_fill(roc, ...)

    # Name and Category
    attr(roc, "name") <- paste("ROC", n, sep="_")
    attr(roc, "category") <- "momentum"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (roc)
}