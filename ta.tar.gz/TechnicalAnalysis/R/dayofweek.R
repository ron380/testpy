# """Day of week 
#  Mon=1
#' @importFrom lubridate wday
#' @export
dayofweek <- function(.date=NULL, ohlc, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("date" %in% names(ohlc))
        .date <- ohlc$date
    }

    # Validate
    if (is.null(.date) || !is.Date(.date))
        return (NULL)


    # Calculate
    dayofweek <- wday(.date, week_start =1)

    # Offset
    if (is.integer(offset) && offset != 0L)
        dayofweek <- shift(dayofweek, offset)

    # Fill
    dayofweek <- vec_fill(dayofweek, ...)

    # Name and Category
    attr(dayofweek, "name") <- paste("dayofweek")
    attr(dayofweek, "category") <- "datetime"



    return (dayofweek)
}
