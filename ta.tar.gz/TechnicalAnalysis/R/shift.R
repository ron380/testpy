# references: 
# https://stackoverflow.com/questions/26997586/shifting-a-vector

# there is a C implementation from data.table::shift with the same behavior
#' function that shifts vector values to right or left
#'
#' @param x Vector for which to shift values
#' @param n Number of places to be shifted.
#'    Positive numbers will shift to the right by default.
#'    Negative numbers will shift to the left by default.
#'    The direction can be inverted by the invert parameter.
#' @param invert Whether or not the default shift directions
#'    should be inverted.
#' @param default The value that should be inserted by default.
#' @export
shift <- function(x, n, invert=FALSE, default_value=NA){
    stopifnot(length(x) >= n)

    if (n==0) {
        return(x)
    }
    n <- ifelse(invert, n*(-1), n)
    if (n < 0) {
        n <- abs(n)
        forward=FALSE
    } else {
        forward=TRUE
    }

    if (forward) {
        return (c(rep(default_value, n), x[seq_len(length(x)-n)]))
    }
    else {
    # if (!forward){
        return (c(x[seq_len(length(x)-n)+n], rep(default_value, n)))
    }
}



shift.dataframe <- function(df, n=1L, default_value=NA) {
    nrows <- nrow(df)
    shifted_df <- df

    if (n == 0)
        return (df)
    else if (n > 0) {
        shifted_df[seq_len(nrows - n), ] <- df[seq_len(nrows -n) +n, ]
        shifted_df[(nrows - n + 1):nrows, ] <- default_value
    }
    else if (n < 0) {
        shifted_df[seq_len(-n) + 1, ] <- default_value        
        shifted_df[-seq_len(-n), ] <- df[-seq_len(-n) - n, ]
    }

    return (shift_df)

}



shift_dataframe <- function(df, n) {
    nrows <- nrow(df)
    
    if (n == 0) {
        return(df)
    } else if (n > 0) {
        # Shifting down (positive shift)
        new_df <- df[1:(nrows - n), ]
        new_df[(n + 1):nrows, ] <- df[1:(nrows - n), ]
    } else {
        # Shifting up (negative shift)
        new_df <- df[abs(n) + 1:nrows, ]
        new_df[1:abs(n), ] <- df[(abs(n) + 1):nrows, ]
    }
    
    return(new_df)
}
