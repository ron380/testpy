# """HL2

# HL2 is the midpoint/average of high and low.

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value). Only works if
#         result is offset.
#     fill_method (value, optional): Type of fill method. Only works if
#         result is offset.

# Returns:
#     pd.Series: New feature generated.
# """
#' @export 
hl2 <- function(.high=NULL, .low=NULL, ohlc, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        .high = ohlc$high
        .low = ohlc$low
    }

    # Validate
    .high <- vector.check.minlength(.high)
    .low <- vector.check.minlength(.low)

    if (is.null(.high) || is.null(.low))
        return (NULL)

    # Calculate
    hl2 <- 0.5 * (.high + .low)

    # Offset
    if (is.integer(offset) && offset != 0L)
        hl2 <- shift(hl2, offset)

    # Fill
    hl2 <- vec_fill(hl2, ...)

    # Name and Category
    attr(hl2, "name") <- paste("hl2", n, sep="_")
    attr(hl2, "category") <- "overlap"

    return (hl2)
}