
# ema code from package TTR
ema_ttr <- function(x, n, ratio, wilder) {
  # Ensure that 'x' is double
  if (!is.double(x)) {
    x <- as.double(x)
  }
  
  if (ncol(x) > 1) {
    stop("ncol(x) > 1; EMA only supports univariate 'x'")
  }
  
  i_n <- as.integer(n)
  d_ratio <- as.numeric(ratio)
  
  if (is.null(n) || i_n <= 0) {
    if (is.null(ratio) || d_ratio <= 0.0) {
      stop("either 'n' or 'ratio' must be specified and > 0\n",
           "'n' is ", n, " 'ratio' is ", ratio)
    } else {
      # If ratio is specified, and n is not, set n to approx 'correct' value backed out from ratio
      i_n <- as.integer(2.0 / d_ratio - 1.0)
    }
  } else {
    if (is.null(ratio)) {
      isWilder <- as.integer(wilder)
      d_ratio <- ifelse(isWilder, 1.0 / i_n, 2.0 / (i_n + 1))
    } else {
      # ratio != NULL -> warn that 'n' will be used instead
      warning("both 'n' and 'ratio' are specified; using 'n'")
    }
  }
  
  # Input object length
  nr <- length(x)
  
  # Initialize result R object
  result <- numeric(nr)
  
  # Check for non-leading NAs and get first non-NA location
  first <- which(!is.na(x))[1]
  if (i_n + first > nr) {
    stop("not enough non-NA values")
  }
  
  # Set leading NAs in output
  result[1:first] <- NA_real_
  
  # Raw mean to start EMA
  seed <- 0.0
  for (i in first:(first + i_n - 1)) {
    result[i] <- NA_real_
    seed <- seed + x[i] / i_n
  }
  result[first + i_n - 1] <- seed
  
  # Loop over non-NA input values
  for (i in (first + i_n):nr) {
    result[i] <- x[i] * d_ratio + result[i - 1] * (1 - d_ratio)
  }
  
  return(result)
}

# Example usage:
# x <- c(23, 25, 27, 30, 28, 32, 34, 35, 37, 36)
# n <- NULL
# ratio <- 0.2
# wilder <- NULL
# ema_result <- ema_ttr(x, n, ratio, wilder)
# print(ema_result)
