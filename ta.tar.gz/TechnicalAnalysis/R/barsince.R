# Bars Since True Events (BARSINCE)

# Bar Since is an indicator that count the number of bars after every true event in te array
#' @export
barsince <- function(boolseries, offset=0L, ..., append=FALSE) {

    
    # Validate Arguments
    if (!is.logical(boolseries))
        return (NULL)


    # the trick of series minus cumsum
    # cs <- cumsum(bs)
    # barsince <- cs - cs[boolseries]
    barsince <- countsince(boolseries)

    # Offset
    if (is.integer(offset) && offset != 0L)
        barsince <- shift(barsince, offset)

    # Fill
    barsince <- vec_fill(barsince, ...)

    # Name and Category
    attr(barsince, "name") <- paste("barsince", n, sep="_")
    attr(barsince, "category") <- "transform"

    return (barsince)
}

