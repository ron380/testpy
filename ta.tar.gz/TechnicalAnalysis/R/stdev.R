# """Rolling Standard Deviation

# Calculates the Standard Deviation over a rolling period.

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 30
#     ddof (int): Delta Degrees of Freedom.
#                 The divisor used in calculations is N - ddof,
#                 where N represents the number of elements. The 'talib'
#                 argument must be false for 'ddof' to work. Default: 1
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. TA Lib does not have a 'ddof' argument.
#         Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_sd
#' @export
stdev <- function(.close=NULL, ohlc, n = 30L, ddof = 1L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    stdev <- roll_sd(.close, n)    
    if (ddof == 0L)
        stdev <- stdev * sqrt((n-1) / n)

    # Offset
    if (is.integer(offset) && offset != 0L)
        stdev <- shift(stdev, offset)

    # Fill
    stdev <- vec_fill(stdev, ...)

    # Name and Category
    attr(stdev, "name") <- paste("stdev", n, sep="_")
    attr(stdev, "category") <- "statistics"

    return (stdev)
}
