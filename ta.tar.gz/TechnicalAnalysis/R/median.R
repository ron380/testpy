# """Rolling Median

# Calculates the Median over a rolling period.
# Sources:
#     https://www.incrediblecharts.com/indicators/median_price.php
# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 30
#     offset (int): How many periods to offset the result. Default: 0
# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method
# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_median
#' @export
median <- function(.close=NULL, ohlc, n = 30L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    median <-  roll_median(.close, n)
    
        
    # Offset
    if (is.integer(offset) && offset != 0L)
        median <- shift(median, offset)

    # Fill
    median <- vec_fill(median, ...)

    # Name and Category
    attr(median, "name") <- paste("median", n, sep="_")
    attr(median, "category") <- "statistics"

    return (median)
}
