# """Tim Tillson's T3 Moving Average (T3)

# Tim Tillson's T3 Moving Average is considered a smoother and more
# responsive moving average relative to other moving averages.

# Sources:
#     http://www.binarytribune.com/forex-trading-indicators/t3-moving-average-indicator/

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     a (float): 0 < a < 1. Default: 0.7
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     adjust (bool): Default: True
#     presma (bool, optional): If True, uses SMA for initial value.
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export 
t3 <- function(.close=NULL, ohlc, n=10L, a=0.7, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, 5 * (n + 1))

    if (is.null(.close))
        return (NULL)


    # a <- ifelse(is.double(a)) float(a) if isinstance(a, float) and 0 < a < 1 else 0.7
    # Calculate
    c1 = -a * a**2
    c2 = 3 * a**2 + 3 * a**3
    c3 = -6 * a**2 - 3 * a - 3 * a**3
    c4 = a**3 + 3 * a**2 + 3 * a + 1

    e1 = ema(close=.close, n=n)
    e2 = ema(close=e1, n=n)
    e3 = ema(close=e2, n=n)
    e4 = ema(close=e3, n=n)
    e5 = ema(close=e4, n=n)
    e6 = ema(close=e5, n=n)
    t3 = c1 * e6 + c2 * e5 + c3 * e4 + c4 * e3


    # Offset
    if (is.integer(offset) && offset != 0L)
        t3 <- shift(t3, offset)

    # Fill
    t3 <- vec_fill(t3, ...)

    # Name and Category
    attr(t3, "name") <- paste("t3", n, sep="_")
    attr(t3, "category") <- "overlap"

    # Append
    # if (append)
    #    bind_cols(ohlc, t3)

    return (t3)
}
