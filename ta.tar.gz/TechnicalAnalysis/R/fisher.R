# """Fisher Transform (FISHT)

# Attempts to identify significant price reversals by normalizing prices
# over a user-specified number of periods. A reversal signal is suggested
# when the the two lines cross.

# Sources:
#     TradingView (Correlation >99%)

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     length (int): Fisher period. Default: 9
#     signal (int): Fisher Signal period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.DataFrame: fisher and signal columns
# """
#' @importFrom roll roll_max roll_min
#' @export
fisher <- function(.high=NULL, .low=NULL, ohlc, n=9L, signal=3L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
    }
    
    # Validate    
    .length <- max(n, signal)
    .high <- vector.check.minlength(.high, .length)
    .low <- vector.check.minlength(.low, .length)

    if (is.null(.high) || is.null(.low))
        return (NULL)

 
    # Calculate
    hl2_ <- 0.5 * (.high + .low)
    highest_hl2 <- roll_max(hl2_, n)
    lowest_hl2 <- roll_min(hl2_, n)

    hlr <- high_low_range(highest_hl2, lowest_hl2)
    hlr[hlr < 0.001] = 0.001

    position <- ((hl2_ - lowest_hl2) / hlr) - 0.5

    v <- 0
    N <- length(.high)
    result <- empty_vector_NA(N)
    result[n-1] <- 0
    # result = [nan for _ in range(0, length - 1)] + [0]
    for (i in n:N) {
        v <- 0.66 * position[i] + 0.67 * v
        if (v < -0.99) v = -0.999
        if (v > 0.99)  v = 0.999
        result[i] <- (0.5 * (log((1 + v) / (1 - v)) + result[i - 1]))
    }

    signalma <- shift(fisher, signal)
    # Offset
    if (is.integer(offset) && offset != 0L) {
        fisher <- shift(fisher, offset)
        signalma <- shift(signalma, offset)
    }
    # Fill
    fisher <- vec_fill(fisher, ...)
    signalma <- vec_fill(signalma, ...)
    

    # Name and Category
    data <- list(fisher, signalma)
    data <- setNames(data, c(paste("fishert", n, signal, sep="_"), paste("fisherts", n, signal, sep="_")))
    
    attr(data, "name") <- paste("fisher", fast, slow, sep="_")
    attr(data, "category") <- "momentum"

    return (data)
}
