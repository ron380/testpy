# """Drawdown (DD)

# Drawdown is a peak-to-trough decline during a specific period for an
# investment, trading account, or fund. It is usually quoted as the
# percentage between the peak and the subsequent trough.

# Sources:
#     https://www.investopedia.com/terms/d/drawdown.asp

# Args:
#     close (pd.Series): Series of 'close's.
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.DataFrame: drawdown, drawdown percent, drawdown log columns
# """

#' @export 
drawdown <- function(.close=NULL, ohlc, cumulative=FALSE, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    max_close <- cummax(.close)
    dd <- max_close - .close
    dd_pct <- 1 - (.close / max_close)
    dd_log <- log(max_close) - log(close)
    

    # Offset
    if (is.integer(offset) && offset != 0L)
        drawdown <- shift(drawdown, offset)

    # Fill
    drawdown <- vec_fill(roc, ...)

    # Name and Category
    props <- ifelse(cumulative, "cum", "") 
    attr(drawdown, "name") <- paste(paste0(props, "logtret"), n, sep="_")
    attr(drawdown, "category") <- "performance"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (drawdown)
}
