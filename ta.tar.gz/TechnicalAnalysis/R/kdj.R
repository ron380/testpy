# """KDJ (KDJ)

# The KDJ indicator is actually a derived form of the Slow
# Stochastic with the only difference being an extra line
# called the J line. The J line represents the divergence
# of the %D value from the %K. The value of J can go
# beyond [0, 100] for %K and %D lines on the chart.

# Sources:
#     https://www.prorealcode.com/prorealtime-indicators/kdj/
#     https://docs.anychart.com/Stock_Charts/Technical_Indicators/Mathematical_Description#kdj

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     length (int): Default: 9
#     signal (int): Default: 3
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.DataFrame: k, d, and j columns
# """
#' @export
fisher <- function(.close=NULL, .high=NULL, .low=NULL, ohlc, n=9L, signal=3L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        .close <- ohlc$close
        .high <- ohlc$high
        .low <- ohlc$low
    }
    
    # Validate    
    .length <- n + signal + 1
    .high <- vector.check.minlength(.high, .length)
    .low <- vector.check.minlength(.low, .length)
    .close <- vector.check.minlength(.close, .length)

    if (is.null(.high) || is.null(.low) || is.null(.close))
        return (NULL)

 
    # Calculate
    highest_high <- roll_max(.high, n)
    lowest_low <- roll_min(.low, n)

    hlr <- high_low_range(highest_hl2, lowest_hl2)
    hlr[hlr < 0.001] = 0.001


    fastk <- 100 * (.close - lowest_low) / non_zero_range(highest_high, lowest_low)

    k <- rma(fastk, n=signal)
    d <- rma(k, n=signal)
    j = 3 * k - 2 * d

    # Offset
    if (is.integer(offset) && offset != 0L) {
        k <- shift(k, offset)
        d <- shift(d, offset)
        j <- shift(j, offset)
    }
    # Fill
    k <- vec_fill(k, ...)
    d <- vec_fill(d, ...)
    j <- vec_fill(j, ...)
    

    # Name and Category
    data <- list(k, d, j)
    data <- setNames(data, c(paste("k", n, signal, sep="_"), paste("d", n, signal, sep="_"), paste("j", n, signal, sep="_")))
    
    attr(data, "name") <- paste("kdj", n, signal, sep="_")
    attr(data, "category") <- "momentum"

    return (data)
}
