# """Supertrend (supertrend)

# Supertrend is an overlap indicator. It is used to help identify trend
# direction, setting stop loss, identify support and resistance, and/or
# generate buy & sell signals.

# Sources:
#     http://www.freebsensetips.com/blog/detail/7/What-is-supertrend-indicator-its-calculation

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     length (int) : Length for ATR calculation. Default: 7
#     atr_length (int) : If None, defaults to length otherwise, provides
#         variable of control. Default: length
#     multiplier (float): Coefficient for upper and lower band distance to
#         midrange. Default: 3.0
#     atr_mamode (str) : MA type to be used for ATR calculation.
#         See ``help(ta.ma)``. Default: 'rma'
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.DataFrame: SUPERT (trend), SUPERTd (direction),
#         SUPERTl (long), SUPERTs (short) columns.
# """

#' @importFrom roll roll_idxmin roll_idxmax
#' @export
supertrend <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, n=7L, atr_length=NULL, atr_mamode=NULL, multiplier=1, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }
    
    # Validate    
    .high <- vector.check.minlength(.high, n+1)
    .low <- vector.check.minlength(.low, n+1)
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.high) || is.null(.low) || is.null(.close))
        return (NULL)

    atr_length <- ifelse(!is.null(atr_length) && is.scalar(atr_length), atr_length, n)
    atr_mamode <- ifelse(!is.null(atr_mamode) && is.character(atr_mamode), atr_mamode, "rma")


    # Calculate
    N <- length(.close)
    
    # allocate
    long_ <- empty_vector_NA(N)
    short_ <- empty_vector_NA(N)

    # allocate with zero initializer
    dir_ <- empty_vector("integer", N)
    trend_ <- empty_vector("integer", N)
    dir_[] <- 1

    hl2_ <- hl2(.high, .low)
    atr_ <- atr(.high, .low, .close, atr_length, mamode=atr_mamode)

    periods_from_hh <- (n+1) - roll_idxmax(.high, width = n+1) 
    periods_from_ll <- (n+1) - roll_idxmin(.low, width = n+1)  

    supertrend_up <- supertrend_down = scalar
    supertrend_up <- supertrend_up * (1 - (periods_from_hh / length))
    supertrend_down <- supertrend_down * (1 - (periods_from_ll / length))
    supertrend_osc <- supertrend_up - supertrend_down

    # Offset
    if (is.integer(offset) && offset != 0L) {
        supertrend_up <- shift(supertrend_up, offset)
        supertrend_dn <- shift(supertrend_dn, offset)
        supertrend_osc <- shift(supertrend_osc, offset)
    }

    # Fill
    supertrend_up <- vec_fill(supertrend, ...)
    supertrend_dn <- vec_fill(supertrend_dn, ...)
    supertrend_osc <- vec_fill(supertrend_osc, ...)

 
    # Name and Category
    supertrend_up.name <- paste("supertrendu", n, sep="_")
    supertrend_down.name <- paste("supertrendd", n, sep="_")
    supertrend_osc.name <- paste("supertrendosc", n, sep="_")

    arron <- bind_cols(!!supertrend_up.name := arron_up, !!supertrend_down.name := arron_down, !!supertrend_osc.name := supertrend_osc)
    attr(supertrend, "name") <- paste("supertrend", n, sep="_")
    attr(supertrend, "category") <- "trend"

    return (supertrend)
}

