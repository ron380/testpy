# """Balance of Power (BOP)

# Balance of Power measure the market strength of buyers against sellers.

# Sources:
#     http://www.worden.com/TeleChartHelp/Content/Indicators/Balance_of_Power.htm

# Args:
#     open (pd.Series): Series of 'open's
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     scalar (float): How much to magnify. Default: 1
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """

#' @export
bop <- function(.open=NULL, .high=NULL, .low=NULL, .close=NULL, ohlc, scalar=1L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("open" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))

        .open <- ohlc$open
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }
    
    # Validate
    if (is.null(.high) || is.null(.low) || is.null(.open) || is.null(.close)  )
        return (NULL)

 
    # Calculate
    high_low_range <- non_zero_range(.high, .low)
    close_open_range <- non_zero_range(.close, .open)
    bop = scalar * close_open_range / high_low_range


    # Offset
    if (is.integer(offset) && offset != 0L)
        bop <- shift(bop, offset)

    # Fill
    bop <- vec_fill(bop, ...)

 
    # Name and Category
    bop.name <- paste("bop", fast, slow, sep="_")
    bop.category <- "momentum"

    return (bop)
}
