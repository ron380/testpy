

#' @export
pivot_hi <- function(.low=NULL, ohlc, leftstrength=3L, rightstrength=1L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("low" %in% names(ohlc))
        .high <- ohlc$high
    }
    
    # Validate
    .length <- leftstrength + rightstrength + 1
    .low <- vector.check.minlength(.low, .length)

    if (is.null(.low))
        return (NULL)

    # Calculate
    N <- length(.close)
    
    # instead of roll_idx* which doesn't pass from right to left within the raw window array
    window_idx <- rollapplyr(x, .length, FUN=function(x) { which.max(rev(x)) }, fill=NA)
    # the location of the confirmed pivots
    pivot_idx <- window_idx == rightstrength+1
    # similar to 1:N and adding 1 to all the vector
    period_idx <- 2:(N+1) - window_idx
    period_val <- .low[period_idx]
    pos <- which(pivot_idx == TRUE)
    pivot_val <- empty_vector_NA(N)
    pivot_val[pos] <- period_val[pos]


    # Offset
    if (is.integer(offset) && offset != 0L) {
        pivot_idx <- shift(pivot_idx, offset)
        pivot_val <- shift(pivot_val, offset)
    }

    # Fill
    pivot_idx <- vec_fill(pivot_idx, ...)
    pivot_val <- vec_fill(pivot_val, ...)

 
    # Name and Category
    data <- list(pivot_idx, pivot_val)

    return (supertrend)
}

