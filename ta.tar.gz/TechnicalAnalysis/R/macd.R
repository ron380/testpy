# """Moving Average Convergence Divergence (MACD)

# The MACD is a popular indicator to that is used to identify a security's
# trend. While APO and MACD are the same calculation, MACD also returns
# two more series called Signal and Histogram. The Signal is an EMA of
# MACD and the Histogram is the difference of MACD and Signal.

# Sources:
#     https://www.tradingview.com/wiki/MACD_(Moving_Average_Convergence/Divergence)
#     AS Mode: https://tr.tradingview.com/script/YFlKXHnP/

# Args:
#     close (pd.Series): Series of 'close's
#     fast (int): The short period. Default: 12
#     slow (int): The long period. Default: 26
#     signal (int): The signal period. Default: 9
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     asmode (value, optional): When True, enables AS version of MACD.
#         Default: False
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.DataFrame: macd, histogram, signal columns
# """
#' @export
macd <- function(.close=NULL, ohlc, fast=12L, slow=26L, offset=0L, mammode="ema", ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }
    
    # Validate
    if (slow < fast)
        return (NULL)
    
    .length <- max(fast, slow, signal)
    .close <- vector.check.minlength(.close, .length)

    if (is.null(.close))
        return (NULL)

    .ma <- ma(mamode)

    # Calculate
    median_price <- 0.5 * (.high + .low)
    fast_ma <- .ma(.close, n=fast)
    slow_ma <- .ma(.close, n=slow)
    macd <- fast_sma - slow_sma
    signalma <- .ma(macd, n=signal)
    histogram <- macd - signalma


    # Offset
    if (is.integer(offset) && offset != 0L) {
        macd <- shift(macd, offset)
        histogram <- shift(histogram, offset)
        signalma <- shift(signalma, offset)
    }

    # Fill
    macd <- vec_fill(macd, ...)
    histogram <- vec_fill(histogram, ...)
    signalma <- vec_fill(signalma, ...) 

 
    # Name and Category
    props = paste(fast, slow, signal, sep="_")
    data <- list(macd, histogram, signalma)
    data <- setNames(data, c(paste("macd", props, sep="_"), paste("histogram", props, sep="_"), paste("signalma", props, sep="_")))
    
    attr(macd, "name") <- paste("macd", props, sep="_")
    attr(macd, "category") <- "momentum"

    return (macd)
}
