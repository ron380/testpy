
# EXTRA methods

# https://stackoverflow.com/questions/13594021/calculate-derivative-diff-and-keep-length-add-na
#' @export 
pad <- function(x, n) {
    len <- n - length(x)
    c(rep(NA, len), x) 
}

# using internal pad above
#' @export
diff <- function(x, n) pad(base::diff(x, lag=1), length(x)) 

# https://stackoverflow.com/questions/7735647/replacing-nas-with-latest-non-na-value
# tidyr::fill requires dataframe but
# the code runs vctrs::vec_fill_missing

#' @importFrom vctrs vec_fill_missing
fill.vector <- function(x, fill.value = NULL, fill.method=NULL, ...) {
    # simple replace
    if (!is.null(fill.value))
        x <- replace_na(x, fill.value)
    # forward filling
    if (!is.null(fill.method))
        x <- vctrs::vec_fill_missing(x, direction=fill.method)
    x
}

#' @importFrom vctrs vec_fill_missing
vec_fill <- function(x, fill.value = NULL, fill.method=NULL, ...) {
    # simple replace
    if (!is.null(fill.value))
        x <- replace_na(x, fill.value)
    # forward filling
    if (!is.null(fill.method))
        x <- vctrs::vec_fill_missing(x, direction=fill.method)
    x
}


ffill <- function(x) vctrs::vec_fill_missing(x, direction="up")

countsince <- function(x) x - ffill(ifelse(!x, x, NA))

# append perfix/suffux to x.name
#' @export
name_append <- function(x, prefix=NULL, suffix=NULL, ...) {
    # access to x.name
    # stopifnot(attr(x, "name"))

    name <- attr(x, "name")
    if (is.null(name)) stop("missing .name for x")

    args <- list(...)
    if (is.character(args$prefix))
        name <-paste0(args$prefix, name)
    if (is.character(args$suffix))
        name <-paste0(name, args$suffix)
    attr(x, "name") <- name
    return (x)
}
    

#' @export
interval_scaler <- function(x, a=-1, b=1) {
    result <- (x - a) / (b - a)
    attr(result, "a") <- a
    attr(result, "b") <- b
    return (result)
}


#' @export 
min_max_scaler <- function(x, min_x=min(x), max_x=max(x)) {
    # min_x <- min(x)
    # max_x <- max(x)
    result <- (x - min_x) /(max_x - min_x)
    attr(result, "min") <- min_x
    attr(result, "max") <- max_x
    return (result)
}

#' @export
zscore_scaler <- function(x) {
    .mean <- stats::mean(x)
    .sd <- stats::sd(x)
    result <- (x - .mean) / .sd
    attr(result, "mean") <- mean
    attr(result, "sd") <- .sd
    return (result)
}



# create a unit test
# Calculate EWMA with span = n
#' @importFrom zoo rollapply
#' @export
ewma <- function(x, n) {
    m <- length(x)
    rollapplyr(x, width = n, FUN = function(x) sum(x * 0.5^(1:m)), fill = NA)
}


# ref: https://stackoverflow.com/questions/54585015/vectorized-implementation-of-exponentially-weighted-moving-standard-deviation-us
# ref gist: https://gist.github.com/assuncaolfi/5581528021ac75247a4a1f1c0c3fe12f
#' @export
ewmsd <- function(x, alpha) {
    n <- length(x)
    sapply(
    1:n,
    function(i, x, alpha) {
        y <- x[1:i]
        m <- length(y)
        weights <- (1 - alpha)^((m - 1):0)
        ewma <- sum(weights * y) / sum(weights)
        bias <- sum(weights)^2 / (sum(weights)^2 - sum(weights^2))
        ewmsd <- sqrt(bias * sum(weights * (y - ewma)^2) / sum(weights))
    },
    x = x,
    alpha = alpha
    )
}


fff <- function(y, m, alpha) {
    weights <- (1 - alpha)^((m - 1):0)
    ewma <- sum(weights * y) / sum(weights)
    bias <- sum(weights)^2 / (sum(weights)^2 - sum(weights^2))
    ewmsd <- sqrt(bias * sum(weights * (y - ewma)^2) / sum(weights))
    ewmsd
} 
# test <- frollapply(df0, 1000, function(x) f(x, 1000, alpha))

swap <- function(x, y) return (NULL)

# vector operations
# change to double?
vector.is.empty <- function(x) length(x) == 0
vector.is.empty2  <- function(x) !any(x)


is.empty.vector <- function(x) length(x) == 0

# ref: https://stackoverflow.com/questions/22104774/how-to-initialize-a-vector-with-fixed-length-in-r
# ref: https://www.geeksforgeeks.org/how-to-create-a-vector-of-specific-type-and-length-in-r/
empty_vector_like <- function(x, mode = NULL) as.vector(character(length(x)), mode = ifelse(is.null(mode), storage.mode(x), mode))
# ref: 
# this vector initialized by NA
# the coerceion need memory allocation and initialization
empty.vector <- function(n, mode="double") as.vector(character(n), mode=mode)

# faster directly using atomic modes logical,integer, numeric, synonym double
# this vector initialized by 0
empty_vector <- function(n, mode="double") vector(mode=mode, length=n)

empty_vector_like <- function(x, mode=NULL) vector(mode=ifelse(is.null(mode), storage.mode(x), mode), length=length(x))


# best allocate vector of double with initialization value
empty_vector_NA <- function(n, mode="double") {
    v <- empty_vector(n, mode)
    v[] <- NA
    return(v)
}
# problem with rep(NA, n) is that the type of logical

is.scalar <- function(x) is.numeric(x) && length(x) == 1

vector.check.minlength <- function(x, n=0L) {
    # Returns None if the Pandas Series does not meet the minimum length required for the indicator.
    # is.vector more restrictive use is.atomic
    if (is.atomic(x) && !is.empty.vector(x) && (n >= 0L))
    {
        if (length(x) >= n)
            return (x)
    }
    return (NULL)
}

# def non_zero_range(high: Series, low: Series) -> Series:
#     """Returns the difference of two series and adds epsilon to any zero values.
#     This occurs commonly in crypto data when 'high' = 'low'."""
#     diff = high - low
#     if diff.eq(0).any().any():
#         diff += sflt.epsilon
#     return diff

non_zero_range <- function(.high, .low) {
    # Returns the difference of two series and adds epsilon to any zero values.
    # This occurs commonly in crypto data when 'high' = 'low'.
    
    diff <- .high - .low
    
    # is.empty.vector / which(diff == 0)
    if (any(diff == 0)) {
        diff <- diff + .Machine$double.eps
    }
    
    return(diff)
}

# """If the value is close to zero, then return zero.
# Otherwise return itself."""
is.zero <- function(x, threshold=.Machine$double.eps) abs(x) < threshold

# when we have different implementation for the method
# zero <- function(x,y) UseMethod("zero")
zero <- function(x, threshold=.Machine$double.eps) ifelse(abs(x) < threshold, 0, x)

# https://stackoverflow.com/questions/13868963/clip-values-between-a-minimum-and-maximum-allowed-value-in-r
# or use from library(raster) the code clamp(x, lower=-Inf, upper=Inf, ...)
clip <- function(x, lower=-Inf, upper=Inf) ifelse(x <= lower,  lower, ifelse(x >= upper, upper, x))


weighted_func <- function(x, FUN, weights=rep(1, length(x)), p = -1) {
    # Args:
    #   func: Callable
    #   x: Series
    #   weights:
    #   p: power
    #
    # Returns:
    #   SUM f(x, length) (1/w**p) /  SUM (1/w**p)
    #
    #   length depends on weight for example the weight is length
    #   the longer the length the less weight, i.e. w=1/length we want

    denominator <- sum(1/(weights^p))
    numerator <- sum(sapply(weights, function(w) FUN(x, n = w) / w^p))

    return(numerator / denominator)
}


# pad series of TRUE/FALSE at each TRUE location with [p-strength, p+rightstrength]
pad_pivot_mask <- function(series, leftstrength = NULL, rightstrength = NULL) {
    
    # only accept a logical vector
    stopifnot(is.logical(series))

    # Validate arguments
    leftstrength <- ifelse(is.null(leftstrength), 3, leftstrength)
    rightstrength <- ifelse(is.null(rightstrength), 1, rightstrength)

    # Calculate Results
    # important that the idxmax or idxmin are evaluated from right to left!
    N <- length(series)
    nz <- which(series)
    

    # iterate over all nonzero elements
    for (i in nz) {
        for (j in seq(i + rightstrength, i - leftstrength, by = -1)) {
            if (j >= 1 && j <= N && !series[j]) 
                series[j] <- TRUE            
        }
    }

    return(series)
}
