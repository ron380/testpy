# """Short Run

# Short Run was developed by Kevin Johnson that returns a binary Series
# where '1' is a trend and '0' is not a trend given 'fast' and 'slow' signal
# over a certain period length.

# It is recommended to use 'smooth' signals for 'fast' and 'slow' for the
# comparison to reduce unnecessary noise. For indicators using short_run, see
# Archer Moving Average Trend (``help(ta.amat)``) and Archer On Balance
# Volume (``help(ta.aobv)``). Both use Moving Averages for 'fast' and 'slow'
# signals.

# Sources:
#     It is part of the Converging and Diverging Conditional logic in:
#     https://www.tradingview.com/script/Z2mq63fE-Trade-Archer-Moving-Averages-v1-4F/

# Args:
#     fast (pd.Series): Series of 'fast' values.
#     slow (pd.Series): Series of 'slow' values.
#     length (int): The period length. Default: 2
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
short_run <- function(.fast=NULL, .slow=NULL, n=2L, offset=0L, ...) {
    
    # Validate
    .fast <- vector.check.minlength(.fast, n)
    .slow <- vector.check.minlength(.slow, n)
    
    
    if (is.null(.fast) || .is.null(.slow))
        return (NULL)


    offset = v_offset(offset)

    # Calculate
    # potential bottom or bottom
    pt <- decreasing(.fast, n) & decreasing(.slow, n)
    # fast and slow are decreasing
    bd <- decreasing(.fast, n) & increasing(.slow, n)
    short_run <- pb | bd

    # Offset
    if (is.integer(offset) && offset != 0L)
        short_run <- shift(short_run, offset)

    # Fill
    short_run <- vec_fill(short_run, ...)


    # Name and Category
    attr(short_run, "name") = paste("sr", n, sep="_")
    attr(short_run, "category") <- "trend"

    return (short_run)
}