# modify.args function from quantstrat

modify.args <- function(formals, arglist, ..., dots=FALSE)
{

    # avoid evaluating '...' to make things faster
    dots.names <- eval(substitute(alist(...)))

    if(missing(arglist))
    arglist <- NULL
    arglist <- c(arglist, dots.names)

    # see 'S Programming' p. 67 for this matching

    # nothing to do if arglist is empty; return formals
    if(!length(arglist))
        return(formals)

    argnames <- names(arglist)
    if(!is.list(arglist) && !is.null(argnames) && !any(argnames == ""))
        stop("'arglist' must be a *named* list, with no names == \"\"")

    .formals  <- formals
    onames <- names(.formals)

    pm <- pmatch(argnames, onames, nomatch = 0L)
    #if(any(pm == 0L))
    #    message(paste("some arguments stored for", fun, "do not match"))
    names(arglist[pm > 0L]) <- onames[pm]
    .formals[pm] <- arglist[pm > 0L]

    # include all elements from arglist if function formals contain '...'
    if(dots && !is.null(.formals$...)) {
        dotnames <- names(arglist[pm == 0L])
        .formals[dotnames] <- arglist[dotnames]
        #.formals$... <- NULL  # should we assume we matched them all?
    }
    .formals
}

# fibonacci <- function(n= 2L, weighted=False, zero=False) {
   
#     n <- ifelse(missing(n), 2L, as.integer(n))

#     if (zero) {
#         a <- 0 
#         b <- 1
#     }
#     else {
#         n <- n - 1
#         a <- 1 
#         b <- 1
#     }

#     result <- c(a)
#     for _ in range(0, n):
#         a <- b 
#         b <- a + b
#         result = append(result, a)

#     if (weighted) {
#         fib_sum = sum(result)
#         if (fib_sum > 0)
#             result <- result / fib_sum
#     }
    
#     return (result)
# }


# split a vector based on condition
# ref: https://stackoverflow.com/questions/16357962/r-split-numeric-vector-at-position
# https://search.r-project.org/CRAN/refmans/DescTools/html/SplitAt.html
splitAt2 <- function(x, pos) {
    ret <- list()

    # add the enpoints assuming 1 and length(x)+1 are not given
    if (pos[1] != 1) pos_ep <- c(1, pos)
    if (last())
    pos_ep <- c(1, pos, length(x)+1)    
    for (i in seq_along(pos_ep[-1])) {
        ret[[i]] <- x[pos_ep[i]:(pos_ep[i+1]-1)]
    }
    return(ret)
}

splitAtCond <- function(x, cond) splitAt2(x, which(cond))

# numerics
is.percent <- function(x) is.numeric(x) && 0L <=x && x <= 100L


create_symmetric_triangle <- function(n) {
    # Create the initial vector from 1 to n
    initial_vector <- 1:n
    
    # Append the reverse of the initial vector to itself
    symmetric_triangle <- c(initial_vector, rev(initial_vector[-1]))
    
    return(symmetric_triangle)
}

# delegate for numeric (integer and double)
dot <- function(x,y) UseMethod("dot")

# from pracma code
#' @export
dot.numeric <- function(x, y) 
{
    if (length(x) == 0 && length(y) == 0) 
        return(0)
    
    if (length(x) != length(y))
        stop("vector 'x' and 'y' must be of same size")
     
    # if (!(is.numeric(x) || is.complex(x)) || !(is.numeric(y) || 
    #     is.complex(y))) 
    #     stop("Arguments 'x' and 'y' must be real or complex.")
    # x <- drop(x)
    # y <- drop(y)
    # if (any(dim(x) != dim(y))) 
    #     stop("Matrices 'x' and 'y' must be of same size")
    # if (is.vector(x) && is.vector(y)) {
    #     dim(x) <- c(length(x), 1)
    #     dim(y) <- c(length(y), 1)
    # }

    x.y <- sum(x * y)
    return(x.y)
}


# instead of @import purrr partial
# define a partial function without using purrr import package
partial <- function(func, ...) {
    fixed_args <- list(...)
    
    # Define a new function with fixed arguments
    partial_function <- function(...) {
        # concatenate args
        args <- c(fixed_args, list(...))
        do.call(func, args)
    }
    
    return(partial_function)
}


# """Calculates the dot product of weights with values x"""
weights <- function(w) {
    return (partial(dot, y=w))
}


# Function to return the nth row of Pascal's triangle
pascals_triangle_row <- function(n) {
    if(n <= 0) {
        stop("n must be a positive integer.")
    }
    
    row <- numeric(n)  # Initialize a vector to store the row
    
    for (i in 1:n) {
        row[i] <- choose(n - 1, i - 1)  # Calculate binomial coefficient
    }
    
    return(row)
}


# faster directly using atomic modes logical, integer, numeric (synonym double)
# this vector initialized by 0
empty_vector <- function(n, mode="double") vector(mode=mode, length=n)
# best allocate vector of double with initialization value
empty_vector_NA <- function(n, mode="double") {
    v <- empty_vector(n, mode)
    v[] <- NA
    return(v)
}
