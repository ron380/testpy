# """Entropy (ENTP)

# Introduced by Claude Shannon in 1948, entropy measures the
# unpredictability of the data, or equivalently, of its average
# information. A die has higher entropy (p=1/6) versus a coin (p=1/2).

# Sources:
#     https://en.wikipedia.org/wiki/Entropy_(information_theory)

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     base (float): Logarithmic Base. Default: 2
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_sum
#' @export
entropy <- function(.close=NULL, ohlc, n = 10L, base=2, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)


    # Calculate
    p <- .close / roll_sum(.close, n)
    entropy <- roll_sum(-p * log2(p) / log2(base), n)
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        entropy <- shift(entropy, offset)

    # Fill
    entropy <- vec_fill(entropy, ...)

    # Name and Category
    attr(entropy, "name") <- paste("ENTROPY", n, sep="_")
    attr(entropy, "category") <- "statistics"

    return (entropy)
}

