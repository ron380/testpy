# """Bill Williams Alligator (ALLIGATOR)

# The Alligator Indicator was developed by Bill Williams and combines
# moving averages with fractal geometry and the lines are meant to
# resemble an alligator opening and closing his mouth.. It attempts to
# identify if an asset is trending. It consists of 3 lines: the
# Alligator's Jaw, Teeth, and Lips. Each have different lookback periods
# and but require the user to offset the results; this is avoid data leaks
# by Pandas TA. See help(ta.ichimoku) or help(ta.dpo) to offset the
# resultant lines.

# Sources:
#     https://www.tradingview.com/scripts/alligator/
#     https://www.sierrachart.com/index.php?page=doc/StudiesReference.php&ID=175&Name=Bill_Williams_Alligator

# Args:
#     close (pd.Series): Series of 'close's
#     jaw (int): The Jaw period. Default: 13
#     teeth (int): The Teeth period. Default: 8
#     lips (int): The Lips period. Default: 5
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.DataFrame: JAW, TEETH, LIPS columns.
# """
#' @export
alligator <- function(.close=NULL, ohlc, jaw = 13L, teeth = 8L, lips = 5L, offset=0L, ..., append=FALSE) {


    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, max(jaw, teeth, lips))

    if (is.null(.close))
        return (NULL)

    # Calculate
    gator_jaw <- smma(.close, n=jaw)
    gator_teeth <- smma(.close, n=teeth)
    gator_lips <- smma(.close, n=lips)

    # Offset
    if (is.integer(offset) && offset != 0L) {
        gator_jaw <- shift(gator_jaw, offset)
        gator_teeth <- shift(gator_teeth, offset)
        gator_lips <- shift(gator_lips, offset)

    }
    
    # Fill
    gator_jaw <- vec_fill(gator_jaw, ...)
    gator_teeth <- vec_fill(gator_teeth, ...)
    gator_lips <- vec_fill(gator_lips, ...)


    # Name and Category
    .props <- paste(jaw, teeth, lips, sep="_")
    ag <- bind_cols(!!paste("AGj", .props, sep="_") := .gator_jaw, !!paste("AGt", .props, sep="_") := gator_teeth, !!paste("AGl", .props, sep="_") := gator_lips)

    attr(ag, "name") <- paste("ag", .props, sep="_")
    attr(ag, "category") <- "overlap"

    return (ag)
}
