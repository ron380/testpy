# """Absolute Price Oscillator (APO)

# The Absolute Price Oscillator is an indicator used to measure a
# security's momentum.  It is simply the difference of two Exponential
# Moving Averages (EMA) of two different periods. Note: APO and MACD lines
# are equivalent.

# Sources:
#     https://www.tradingtechnologies.com/xtrader-help/x-study/technical-indicator-definitions/absolute-price-oscillator-apo/

# Args:
#     close (pd.Series): Series of 'close's
#     fast (int): The short period. Default: 12
#     slow (int): The long period. Default: 26
#     mamode (str): See ``help(ta.ma)``. Default: 'sma'
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
apo <- function(.close=NULL, ohlc, fast=12L, slow=26L, mamode="sma", offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    if (slow < fast)
        return (NULL)
    
    .length <- max(fast, slow)
    .close <- vector.check.minlength(.close, .length)

    if (is.null(.close))
        return (NULL)

    .ma <- ma(mamode)

    
    # Calculate
    fastma <- .ma(.close, n=fast)
    slowma <- .ma(.close, n=slow)
    apo <- fastma - slowma

    # Offset
    if (is.integer(offset) && offset != 0L)
        ao <- shift(ao, offset)
 
    # Fill
    apo <- vec_fill(apo, ...)

 
    # Name and Category
    attr(ao, "name") <- paste("apo", fast, slow, sep="_")
    attr(ao, "category") <- "momentum"

    return (apo)
}
