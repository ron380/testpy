# """Correlation Trend Indicator (linreg)

# The Correlation Trend Indicator is an oscillator created
# by John Ehler in 2020. It assigns a value depending on how close prices
# in that range are to following a positively- or negatively-sloping
# straight line. Values range from -1 to 1. This is a wrapper
# for ta.linreg(close, r=True).

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 12
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: Series of the linreg values for the given period.
# """
#' @importFrom roll roll_lm
#' @importFrom zoo rollapplyr
#' @export
linreg <- function(.close=NULL, ohlc, n=14L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    arguments <- list(...)
    # extract arguments from 
    angle <- ifelse(is.null(arguments$angle), FALSE, arguments$angle)
    intercept <- ifelse(is.null(arguments$intercept), FALSE, arguments$intercept)
    degrees <- ifelse(is.null(arguments$degrees), FALSE, arguments$degrees) 
    r <- ifelse(is.null(arguments$r), FALSE, arguments$r)
    slope <- ifelse(is.null(arguments$slope), FALSE, arguments$slope)
    tsf <- ifelse(arguments$tsf, FALSE, arguments$tsf)

    
    # x <- 0:(length(.close)-1)
    

    # Custom linear regression
    x <- 1:n
    x_sum <- 0.5 * n * (n + 1)
    x2_sum <- x_sum * (2 * n + 1) / 3
    divisor <- n * x2_sum - x_sum * x_sum

    # Needs to be reworked outside the method
    linear_regression <- function(series) {
        y_sum <- sum(series)
        xy_sum <- sum(x * series)

        m <- (n * xy_sum - x_sum * y_sum) / divisor
        if (slope)
            return (m)
        b <- (y_sum * x2_sum - x_sum * xy_sum) / divisor
        if (intercept)
            return (b)

        if (angle)
            theta <- arctan(m)
            if (degrees)
                theta <- theta * 180 / pi
            return (theta)

        if (r)
            y2_sum <- sum(series * series)
            rn <- n * xy_sum - x_sum * y_sum
            rd <- (divisor * (n * y2_sum - y_sum * y_sum)) ** 0.5
            if (is.zero(rd) == 0)
                rd <- 1e-6
            return (rn / rd)

        if (tsf)
            return (m * (n - 1) + b)
        else
            return (m * n + b)
        # change to return list of values
    }

    linreg_result <- rollapplyr(.close, width = n, FUN=linear_regression, fill=NA)
    
    print(head(linreg_result, 25))
    # linreg_result <- roll_lm(x=x, y=.close, n, online=FALSE)
    # [1] "coefficients" "r.squared"    "std.error"  

    print(slope)
    print(intercept)
    # cat("linreg_result coefficients")
    # print(linreg_result$coefficients |> head(20))
    
    linreg_list <- list(
        slope = if (slope) linreg_result$coefficients[, 2] else NULL,
        intercept = if (intercept) linreg_result$coefficients[, 1] else NULL
    )
    # print(linreg_result$coefficients[, 2])
    
    # bind cols using the list if list > 1
    # print(length(linreg_list))
    # print(names(linreg_list))
    linreg_list <- linreg_list[!sapply(linreg_list, is.null)]
    
    # more than one value we create dataframe
    if (length(linreg_list) == 1) {
        linreg <- linreg_list[[1]]
        linreg_key <- names(linreg_list)[1]
    }
    else
        linreg <- do.call(cbind, linreg_list)
    # print(linreg)
    # stop()
    # print(head(linreg, 15))
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        linreg <- shift(linreg, offset)

    # Fill
    linreg <- vec_fill(linreg, ...)

    # Name and Category
    if (is.vector(linreg))
        attr(linreg, "name") <- paste("linreg", linreg_key, n, sep="_")
    else
        attr(linreg, "name") <- paste("linreg", n, sep="_")
    
    attr(linreg, "category") <- "momentum"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (linreg)
}


