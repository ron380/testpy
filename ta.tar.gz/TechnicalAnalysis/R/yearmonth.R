# """Day of week 
#  Mon=1
#' @importFrom lubridate year month
#' @export
yearmonth <- function(.date=NULL, ohlc, sep="", offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("date" %in% names(ohlc))
        .date <- ohlc$date
    }

    # Validate
    if (is.null(.date) || !is.Date(.date))
        return (NULL)


    # Calculate
    # create string for year-month
    yearmonth <- paste(year(.date), sprintf("%02d", month(.date)), sep=sep)

    # Offset
    if (is.integer(offset) && offset != 0L)
        yearmonth <- shift(yearmonth, offset)

    # Fill
    yearmonth <- vec_fill(yearmonth, ...)

    # Name and Category
    attr(yearmonth, "name") <- paste("yearmonth")
    attr(yearmonth, "category") <- "datetime"

    # Prefix/Suffix
    yearmonth <- name_append(yearmonth, ...)


    # Append
    if (append && !missing(ohlc)) {
        ohlc[[attr(yearmonth, "name")]] = yearmonth
        return(ohlc)
    }


    return (yearmonth)
}
