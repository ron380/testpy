test.fun <- function(a = 1, ...) {
    arguments <- list(...)
    if (arguments$c) {
        print(arguments$c)
    }
    print(arguments)
}

# library TTR