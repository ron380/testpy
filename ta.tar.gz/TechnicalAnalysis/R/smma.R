# """SMoothed Moving Average (SMMA)

# The SMoothed Moving Average (SMMA) is bootstrapped by default with a
# Simple Moving Average (SMA). It tries to reduce noise rather than reduce
# lag. The SMMA takes all prices into account and uses a long lookback
# period. Old prices are never removed from the calculation, but they have
# only a minimal impact on the Moving Average due to a low assigned
# weight. By reducing the noise it removes fluctuations and plots the
# prevailing trend. The SMMA can be used to confirm trends and define
# areas of support and resistance.
# A core component of Bill Williams Alligator indicator.

# Sources:
#     https://www.tradingview.com/scripts/smma/
#     https://www.sierrachart.com/index.php?page=doc/StudiesReference.php&ID=173&Name=Moving_Average_-_Smoothed

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     mamode (str): See ``help(ta.ma)``. Default: 'sma'
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
smma <- function(.close=NULL, ohlc, n=7L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    # print(.close)
    # Calculation
    # https://bookdown.org/kochiuyu/technical-analysis-with-r-second-edition/simple-moving-average-sma.html
    smma <- c()
    # this is done automatically 
    smma[1:(n-1)] <- NA
    for (i in n:length(.close)) {
        smma[i] <- ((n - 1) * smma[i-1] + smma.iat[i]) / n
    }
    # use roll_mean
  
    # Offset
    if (is.integer(offset) && offset != 0L)
        smma <- shift(smma, offset)

    # Fill
    smma <- vec_fill(smma, ...)

    # Name and Category
    attr(smma, "name") <- paste("smma", n, sep="_")
    attr(smma, "category") <- "overlap"

    return (smma)
}
