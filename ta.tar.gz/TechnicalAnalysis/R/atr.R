# """Average True Range (ATR)

# Average True Range is used to measure volatility, especially volatility
# caused by gaps or limit moves.

# Sources:
#     https://www.tradingview.com/wiki/Average_True_Range_(ATR)

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 14
#     mamode (str): See ``help(ta.ma)``. Default: 'rma'
#     talib (bool): If TA Lib is installed and talib is True, Returns the
#         TA Lib version. Default: True
#     prenan (bool): If True, behave like TA Lib with some initial nan
#         based on drift (typically 1). Default: False
#     drift (int): The difference period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     percent (bool, optional): Return as percentage. Default: False
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.Series: New feature generated.
# """

#' @export
atr <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, n=14L, prenan=TRUE, mamode=NULL, percent=FALSE, drift=1L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))

        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }

        
    # Validate
    if (is.null(.high) || is.null(.low) || is.null(.close)  )
        return (NULL)

    arguments <- list(...)
    # extract arguments from 
    presma <- ifelse(is.null(arguments$presma), TRUE, arguments$presma)

    atr_mamode <- ifelse(!is.null(atr_mamode) && is.character(atr_mamode), atr_mamode, "rma")
 
    # Calculate
    tr_ <- true_range(
            .high=.high, .low=.low, .close=.close,
            prenan=prenan, drift=drift
        )
    
    if (presma) {
        sma_nth <- mean(tr[1:n])
        tr[1:(n - 1)] <- NA
        tr[n] <- sma_nth
    }
    .ma <- ma(mamode)
    atr <- .ma(tr, n=n)
    
    if (percent)
        atr <- 100 * atr / .close


    # Offset
    if (is.integer(offset) && offset != 0L)
        atr <- shift(atr, offset)

    # Fill
    atr <- vec_fill(atr, ...)

 
    # Name and Category
    atr.name <- paste("atr", mamode, ifelse(percent, "p", ""), n)
    atr.category <- "volatility"

    return (atr)
}
