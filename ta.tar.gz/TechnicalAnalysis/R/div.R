# Divergence (DIV)

# Momentum is an indicator used to measure a security's speed
# (or strength) of movement or simply the change in price.

# Sources: 
#     http://www.onlinetradingconcepts.com/TechnicalAnalysis/Momentum.html

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 1
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
#
#' @export
div <- function(.close=NULL, .high=NULL, .low=NULL, ohlc, n=14L, offset=0L, ..., append=FALSE) {
    # close is used as a series for checking divergence
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }

    # Validate
    
    .high <- vector.check.minlength(.high, n)
    .low <- vector.check.minlength(.low, n)
    .close <- vector.check.minlength(.close, n)

    if (is.null(.high) || is.null(.low) || is.null(.close))
        return (NULL)


    # Calculate
    low_diff <- diff(.low, n)
    high_diff <- diff(.high, n)
    signal_diff <- diff(.close, n)

    # close (signal line)
    div_up <- signal_diff > 0 & low_diff < 0   # about to turn up
    div_dn <- signal_diff < 0 & high_diff > 0  # about to turn dn

    # Offset
    if (is.integer(offset) && offset != 0L) {
        div_up <- shift(div_up, offset)
        div_dn <- shift(div_dn, offset)
    }

    # Fill
    div_up <- vec_fill(div_up, ...)
    div_dn <- vec_fill(div_dn, ...)

    data <- list(div_up, div_dn)
    data <- setNames(data, c(paste("divup", n, sep="_"), paste("divdn", n, sep="_")))

    # Name and Category
    attr(data, "name") <- paste("div", n, sep="_")
    attr(data, "category") <- "momentum"

    return (mom)
}
