
# use tidyverse to resample dataframe
# end of the bar must be end of the month!
#' @importFrom timetk summarise_by_time
#' @export
resample_timeframe <- function(ohlc, .by=c("month", "week"), .type="ceiling", offset=0L) {

    # match.arg
    
    ohlc <- ohlc |> summarise_by_time(.date_var="date", .by=.by, .type=.type, 
                       open = first(open),
                       high = max(high),
                       low = min(low),
                       close = last(close), 
                       volume = sum(volume),
                       .week_start = 1)

    # Offset
    if (is.integer(offset) && offset != 0L)
        ohlc <- shift_tibble(ohlc, offset)


    return (ohlc)
}