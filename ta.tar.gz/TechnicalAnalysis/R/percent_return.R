# """Percent Return

# Calculates the percent return of a Series.
# See also: help(df.ta.percent_return) for additional **kwargs a valid 'df'.

# Sources:
#     https://stackoverflow.com/questions/31287552/logarithmic-returns-in-pandas-dataframe

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): Its period. Default: 1
#     cumulative (bool): If True, returns the cumulative returns.
#         Default: False
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.Series: New feature generated.
# """

#' @export 
percent_return <- function(.close=NULL, ohlc, n = 1L, cumulative=FALSE, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)


    close_ <- .close
    if (cumulative)
        percent_return <- (close_ / close_[1]) - 1
    else
        percent_return <- (close_ / shift(close_, n)) - 1
        
    # Offset
    if (is.integer(offset) && offset != 0L)
        percent_return <- shift(percent_return, offset)

    # Fill
    percent_return <- vec_fill(percent_return, ...)

    # Name and Category
    props <- ifelse(cumulative, "cum", "") 
    attr(percent_return, "name") <- paste(paste0(props, "pctret"), n, sep="_")
    attr(percent_return, "category") <- "performance"

    # Prefix/Suffix
    percent_return <- name_append(percent_return, ...)


    # Append
    if (append && !missing(ohlc)) {
        ohlc[[attr(percent_return, "name")]] = percent_return
        return(ohlc)
    }


    return (percent_return)
}
