# """Inertia (INERTIA)

# Inertia was developed by Donald Dorsey and was introduced his article
# in September, 1995. It is the Relative Vigor Index smoothed by the Least
# Squares Moving Average. Positive Inertia when values are greater than 50,
# Negative Inertia otherwise.

# Sources:
#     https://www.sierrachart.com/index.php?page=doc/StudiesReference.php&ID=285&Name=Inertia
#     https://www.tradingview.com/script/mLZJqxKn-Relative-Volatility-Index/

# Args:
#     open_ (pd.Series): Series of 'open's
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 20
#     rvi_length (int): RVI period. Default: 14
#     refined (bool): Use 'refined' calculation. Default: False
#     thirds (bool): Use 'thirds' calculation. Default: False
#     mamode (str): See ``help(ta.ma)``. Default: 'ema'
#     drift (int): The difference period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
intertia <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, n=20L, rvi_length=14L, scalar=100, prenan=TRUE, mamode=NULL, percent=FALSE, drift=1L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))

        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }

    
    # Validate
    .close <- vector.check.minlength(.close, .length)
    .high <- vector.check.minlength(.high, .length)
    .low <- vector.check.minlength(.low, .length)
    
    .length <- 2 * max(n, rvi_length) - floor(min(length, rvi_length) / 2) - 1

    if (is.null(.high) || is.null(.low) || is.null(.close)  )
        return (NULL)


    # Calculate
    if (refined)
        rvi_ <- rvi(.close, .high, .low, n=rvi_length,
                    scalar=scalar, refined="r", mamode=mamode)
    else if (thirds)
        rvi_ <- rvi(.close, .high, .low, n=rvi_length,
                    scalar=scalar, thirds=thirds, mamode=mamode)
    else
        rvi_ <- rvi(.close, n=rvi_length, scalar=scalar, mamode=mamode)

    inertia <- linreg(rvi_, n=n)

    # Offset
    if (is.integer(offset) && offset != 0L)
        intertia <- shift(intertia, offset)

    # Fill
    intertia <- vec_fill(intertia, ...)

 
    # Name and Category
    intertia.name <- paste("intertia", mamode, n, rvi_length, sep="_")
    intertia.category <- "momentum"

    return (intertia)
}
