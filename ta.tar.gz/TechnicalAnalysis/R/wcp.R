# """Weighted Closing Price (WCP)

# Weighted Closing Price is the weighted price given: high, low
# and double the close.

# Sources:
#     https://www.fmlabs.com/reference/default.htm?url=WeightedCloses.htm

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# 
#' @export 
wcp <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))
        .high = ohlc$high
        .low = ohlc$low
        .close = ophlc$close
    }

    # Validate
    .high <- vector.check.minlength(.high)
    .low <- vector.check.minlength(.low)
    .close <- vector.check.minlength(.close)
    
    # Calculate
    weight = .high + .low + 2 * .close

    # Offset
    if (is.integer(offset) && offset != 0L)
        wcp <- shift(wcp, offset)

    # Fill
    wcp <- vec_fill(wcp, ...)

    # Name and Category
    attr(wcp, "name") <- paste("wcp")
    attr(wcp, "category") <- "overlap"

    return (wcp)
}