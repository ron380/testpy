# """Zero Lag Moving Average (ZLMA)

# The Zero Lag Moving Average attempts to eliminate the lag associated
# with moving averages. This is an adaption created by John Ehler
# and Ric Way.

# Sources:
#     https://en.wikipedia.org/wiki/Zero_lag_exponential_moving_average

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     mamode (str): Options: 'ema', 'hma', 'sma', 'wma'. Default: 'ema'
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
zlma <- function(.close=NULL, ohlc, n=10L, mamode="ema", offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    .ma <- ma(mamode)
    # print(deparse(substitute(.ma)))

    # Calculate
    lag <- as.integer(0.5 * (n - 1))
    close_ <- 2 * .close - shift(.close, lag)

    print(head(close_, 25))
    # kwargs.update({"close": close_})
    # kwargs.update({"length": length})
    # fn = getattr(sys_modules[__name__], mamode)
    cat("zmla\n")
    cat("n = ", n)
    zlma <- ema(.close=close_, n=n)
  
    print(head(zlma, 50))
    stop()

    # Offset
    if (is.integer(offset) && offset != 0L)
        zlma <- shift(zlma, offset)

    # Fill
    zlma <- vec_fill(zlma, ...)

    # Name and Category
    attr(zlma, "name") <- paste("zl", mamode, n, sep="_")
    attr(zlma, "category") <- "overlap"

    return (zlma)
}
