# """Day of week 
#  Mon=1
#' @importFrom lubridate week month quarter
#' @export
yearindex <- function(.date=NULL, ohlc, ind=c("week", "month", "quarter"), sep="", offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("date" %in% names(ohlc))
        .date <- ohlc$date
    }

    # Validate
    if (is.null(.date) || !is.Date(.date))
        return (NULL)

    # use `week` as defualt value for ind
    ind <- ifelse(missing(ind), "week", ind)    
    ind <- match.arg(ind)


    # Calculate
    # mutate_function <- get(paste0(package_prefix, "::", function_name))
    yearindex <- paste(year(.date), sprintf("%02d", get(ind)(.date)), sep=sep)

    # Offset
    if (is.integer(offset) && offset != 0L)
        yearindex <- shift(yearindex, offset)

    # Fill
    yearindex <- vec_fill(yearindex, ...)

    # Name and Category
    attr(yearindex, "name") <- paste("year", ind, sep="_")
    attr(yearindex, "category") <- "datetime"

    # Prefix/Suffix
    yearindex <- name_append(yearindex, ...)


    # Append
    if (append && !missing(ohlc)) {
        ohlc[[attr(yearindex, "name")]] = yearindex
        return(ohlc)
    }


    return (yearindex)
}
