# math and series operarations

#' @export
normalize_by_pclose <- function(series, .clsoe=NULL, ohlc, drift=1L, offset=0L) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    if (length(series) != length(.clsoe))
        stop("length series does match.")

    # Compute - normalize by previous close
    normalize_series <- (series / close.shift(drift))

    # Offset
    if (is.integer(offset) && offset != 0L)
        normalize_series <- shift(normalize_series, offset)
    
    return (normalize_series)
}

#' @export
normalize_by_levels <- function(series, levels=10L) {
    
    split <- 100 / levels
    return (as.integer(round(series / split) * split))
}

#' @export
iff <- ifelse


# Returns the value of the ARRAY when the EXPRESSION was true on the n -th most recent occurrence. Note: this function allows also 0 and negative values for n - this enables referencing future
# EXAMPLE	
#    valuewhen( cross( close, ma(close,5) ) ,macd(), 1)
# https://forum.amibroker.com/t/valuewhen-statement-n-0/17984/3
#' @export
valuewhen <- function(cond, series, n=0L) {
    # the condition is characterized by cond > 0
    # pick the places where cond is True
    # the array expression is x[cond] is the value as at n = 0 and the ffill forward
    # n is the shift operator we need to do in order to move from the exact match

    if (length(cond) != length(series))
        stop("valuewhen: length does not match.")

    N <- length(series)
    result <- empty_vector_NA(N)
    result[cond > 0] <- series[cond > 0]
    result <- shift(result, n)
    # vectrs
    # y.name = f"VALUEWHEN_{n}"
    return (result)
}