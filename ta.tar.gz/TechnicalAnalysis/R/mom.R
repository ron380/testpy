# Momentum (MOM)

# Momentum is an indicator used to measure a security's speed
# (or strength) of movement or simply the change in price.

# Sources: 
#     http://www.onlinetradingconcepts.com/TechnicalAnalysis/Momentum.html

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 1
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
#
#' @export
mom <- function(.close=NULL, ohlc, n=10L, offset=0L, ..., append=FALSE) {
    
    # Validate
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }
    if (is.null(.close))
        return (NULL)

    # Calculate
    mom = diff(.close, n)

    # Offset
    if (is.integer(offset) && offset != 0L)
        mon <- shift(mom, offset)

    # Fill
    mom <- vec_fill(mom, ...)

    # Name and Category
    attr(mom, "name") <- paste("MOM", n, sep="_")
    attr(mom, "category") <- "momentum"

    return (mom)
}
