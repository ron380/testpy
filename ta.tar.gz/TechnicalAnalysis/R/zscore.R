# """Rolling Z Score

# Calculates the Z Score over a rolling period.

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 30
#     std (float): It's period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_sd
#' @export
zscore <- function(.close=NULL, ohlc, n = 30L, std = 1, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    zscore <- roll_sd(.close, n)
    std <- std * roll_sd(.close, n)
    mean <- roll_mean(.close, n)
    zscore <- (.close - mean) / std


    # Offset
    if (is.integer(offset) && offset != 0L)
        zscore <- shift(zscore, offset)

    # Fill
    zscore <- vec_fill(zscore, ...)

    # Name and Category
    attr(zscore, "name") <- paste("zscore", n, sep="_")
    attr(zscore, "category") <- "statistics"


    # Prefix/Suffix
    zscore <- name_append(zscore, ...)


    # Append
    if (append && !missing(ohlc)) {
        ohlc[[attr(zscore, "name")]] = zscore
        return(ohlc)
    }

    return (zscore)
}

