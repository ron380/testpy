# """Day of week 
#  Mon=1
#' @importFrom lubridate year week
#' @export
yearweek <- function(.date=NULL, ohlc, sep="", offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("date" %in% names(ohlc))
        .date <- ohlc$date
    }

    # Validate
    if (is.null(.date) || !is.Date(.date))
        return (NULL)


    # Calculate
    # create string for year-week
    yearweek <- paste(year(.date), sprintf("%02d", week(.date)), sep=sep)

    # Offset
    if (is.integer(offset) && offset != 0L)
        yearweek <- shift(yearweek, offset)

    # Fill
    yearweek <- vec_fill(yearweek, ...)

    # Name and Category
    attr(yearweek, "name") <- paste("yearweek")
    attr(yearweek, "category") <- "datetime"

    # Prefix/Suffix
    yearweek <- name_append(yearweek, ...)


    # Append
    if (append && !missing(ohlc)) {
        ohlc[[attr(yearweek, "name")]] = yearweek
        return(ohlc)
    }

    return (yearweek)
}
