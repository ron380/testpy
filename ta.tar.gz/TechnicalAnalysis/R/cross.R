
#' @export 
above_below <- function(series_a, series_b, above=TRUE, asint=FALSE, offset=0L) {

    # Validate
    series_a <- vector.check.minlength(series_a)
    # allow also for numeric (double/integer )below and above
    if (!is.scalar(series_b))
        series_b <- vector.check.minlength(series_b)

    if (is.null(series_a) || is.null(series_b))
        return (NULL)

    # offset = v_offset(offset)

    # correct epsilon on series
    # series_a.apply(zero)
    # series_b.apply(zero)

    # Calculate
    if (above) {
        current <- series_a >= series_b
    }
    else {
        current <- series_a <= series_b
    }

    if (asint)
        cross <- as.integer(cross)

    # Offset
    if (is.integer(offset) && offset != 0L)
        cross <- shift(cross, offset)

    # Name and Category
    series_a.name <- attr(series_a, "name")
    series_b.name <- attr(series_b, "name")
    # numeric scalar for series b
    if (is.scalar(series_b) && is.null(series_b.name))
        series_b.name <- series_b
    
    
    attr(cross, "name") <- if (above) paste(series_a.name, "xa", series_b.name, sep="_") 
        else paste(series_a.name, "xb", series_b.name, sep="_") 
    attr(cross, "category") <- "utility"

    return (cross)
}


#' @export 
above <- function(series_a, series_b, asint=FALSE, offset=0L) 
    above_below(series_a, series_b, above=TRUE, asint=asint, offset=offset)


#' @export 
below <- function(series_a, series_b, asint=FALSE, offset=0L) 
    above_below(series_a, series_b, above=FALSE, asint=asint, offset=offset)


#' @export 
cross <- function(series_a, series_b, above=TRUE, equal=True, asint=FALSE, offset=0L) {

    # Validate
    series_a <- vector.check.minlength(series_a)
    series_b <- vector.check.minlength(series_b)

    if (is.null(series_a) || is.null(series_b))
        return (NULL)

    # offset = v_offset(offset)

    # correct epsilon on series
    # series_a.apply(zero)
    # series_b.apply(zero)

    # Calculate
    if (above) {
        current <- if (equal) series_a >= series_b else series_a > series_b
        previous <- shift(series_a, 1) < shift(series_b, 1)
    }
    else {
        current <- if (equal) series_a <= series_b else series_a < series_b
        previous <- shift(series_a, 1) > shift(series_b, 1)
    }

    cross <- current & previous
    # ensure there is no cross on the first entry
    cross[0] <- F

    if (asint)
        cross <- as.integer(cross)

    # Offset
    if (offset != 0L)
        cross <- shift(cross, offset)

    # Name and Category
    series_a.name <- attr(series_a, "name")
    series_b.name <- attr(series_b, "name")

    attr(cross, "name") <- if (above) paste(series_a.name, "xa", series_b.name, sep="_") 
        else paste(series_a.name, "xb", series_b.name, sep="_") 

    attr(cross, "category") <- "utility"

    return (cross)
}


#' @export 
cross_value <- function(series_a, series_b, above=TRUE, equal=TRUE, asint=FALSE, offset=0L) {
    
    # Check Scalar Variable
    stopifnot(is.scalar(series_b))    
    attr(series_b, "name") <- series_b

    # Validate
    series_a <- vector.check.minlength(series_a)

    if (is.null(series_a))
        return (NULL)

    # offset = v_offset(offset)

    # correct epsilon on series
    # series_a.apply(zero)
    # series_b.apply(zero)

    # Calculate
    if (above) {
        current <- if (equal) series_a >= series_b else series_a > series_b
        previous <- shift(series_a, 1) < series_b
        # cat(current)
        # cat(previous)
    }
    else {
        current <- if (equal) series_a <= series_b else series_a < series_b
        previous <- shift(series_a, 1) > series_b
    }

    cross <- current & previous
    # ensure there is no cross on the first entry
    cross[0] <- F

    if (asint)
        cross <- as.integer(cross)

    # Offset
    if (is.integer(offset) && offset != 0L)
        cross <- shift(cross, offset)

    # Name and Category
    series_a.name <- attr(series_a, "name")
    series_b.name <- attr(series_b, "name")

    attr(cross, "name") <- if (above) paste(series_a.name, "xa", series_b.name, sep="_") 
        else paste(series_a.name, "xb", series_b.name, sep="_") 

    attr(cross, "category") <- "utility"
    return (cross)
    
}


#  Moving Correlation between two serieses (COR)
#' @importFrom roll roll_cor
#' @export 
corr <- function(series_a, series_b, n=14L, scalar=100, asint=FALSE, offset=0L) {
    

    # Validate
    series_a <- vector.check.minlength(series_a, n)
    series_b <- vector.check.minlength(series_b, n)

    if (is.null(series_a) || is.null(series_b))
        return (NULL)


    # Calculate
    corr <- roll_cor(series_a, series_b, n)
    corr <- 100 * corr


    # Offset
    if (is.integer(offset) && offset != 0L)
        cor <- shift(cor, offset)

    # Name and Category
    series_a.name <- attr(series_a, "name")
    series_b.name <- attr(series_b, "name")

    attr(cor, "name") <- paste(series_a.name, "x", series_b.name, "cor", sep="_")    
    attr(cor, "category") <- "math"

    return (cor)
    
}


