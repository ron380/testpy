# Awesome Oscillator (AO)

# The Awesome Oscillator is an indicator used to measure a security's
# momentum. AO is generally used to affirm trends or to anticipate
# possible reversals.

# Sources:
#     https://www.tradingview.com/wiki/Awesome_Oscillator_(AO)
#     https://www.ifcm.co.uk/ntx-indicators/awesome-oscillator

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     fast (int): The short period. Default: 5
#     slow (int): The long period. Default: 34
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
#' @export
ao <- function(.high=NULL, .low=NULL, ohlc, fast=5L, slow=34L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
    }
    
    # Validate
    if (slow < fast)
        return (NULL)
    
    .length <- max(fast, slow)
    .high <- vector.check.minlength(.high, .length)
    .low <- vector.check.minlength(.low, .length)

    if (is.null(.high) || is.null(.low))
        return (NULL)

 
    # Calculate
    median_price <- 0.5 * (.high + .low)
    fast_sma <- sma(median_price, fast)
    slow_sma <- sma(median_price, slow)
    ao <- fast_sma - slow_sma

    # Offset
    if (is.integer(offset) && offset != 0L)
        ao <- shift(ao, offset)

    # Fill
    ao <- vec_fill(ao, ...)

 
    # Name and Category
    attr(ao, "name") <- paste("ao", fast, slow, sep="_")
    attr(ao, "category") <- "momentum"

    return (ao)
}
