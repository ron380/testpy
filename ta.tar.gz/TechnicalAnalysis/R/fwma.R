# """Fibonacci's Weighted Moving Average (FWMA)

# Fibonacci's Weighted Moving Average is similar to a Weighted Moving
# Average (WMA) where the weights are based on the Fibonacci Sequence.

# Source: Kevin Johnson

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     asc (bool): Recent values weigh more. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """

#' @export 
fwma <- function(.close=NULL, ohlc, n = 10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)


    fwma <- roll_sum(.close, n, weights=weights, online=FALSE)
                    

    # Offset
    if (is.integer(offset) && offset != 0L)
        fwma <- shift(fwma, offset)

    # Fill
    fwma <- vec_fill(roc, ...)

    # Name and Category
    attr(fwma, "name") <- paste("fwma", n, sep="_")
    attr(fwma, "category") <- "overlap"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (fwma)
}
