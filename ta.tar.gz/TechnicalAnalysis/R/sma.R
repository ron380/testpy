# """Simple Moving Average (SMA)

# The Simple Moving Average is the classic moving average that is the
# equally weighted average over its length.

# Sources:
#     https://www.tradingtechnologies.com/help/x-study/technical-indicator-definitions/simple-moving-average-sma/

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     adjust (bool): Default: True
#     presma (bool, optional): If True, uses SMA for initial value.
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
sma <- function(.close=NULL, ohlc, n=10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    # print(.close)
    # Calculation
    # https://bookdown.org/kochiuyu/technical-analysis-with-r-second-edition/simple-moving-average-sma.html
    # better to preallocate vector
    sma <- empty_vector(length(.close))
    # this is done automatically 
    sma[1:(n-1)] <- NA
    for (i in n:length(.close)) {
        sma[i] <- base::mean(.close[(i-n+1):i])
    }

    # check: sma <- rollapplyr(vector, width = window_size, FUN = base::mean, fill = NA)
    # with right alignment of elemets

    # print(sma)
    # use roll_mean
  
    # Offset
    if (is.integer(offset) && offset != 0L)
        sma <- shift(sma, offset)

    # Fill
    sma <- vec_fill(sma, ...)

    # Name and Category
    attr(sma, "name") <- paste("sma", n, sep="_")
    attr(sma, "category") <- "overlap"

    return (sma)
}
