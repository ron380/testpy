# """Rolling Variance

# Calculates the Variance over a rolling period.

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 30
#     ddof (int): Delta Degrees of Freedom.
#                 The divisor used in calculations is N - ddof,
#                 where N represents the number of elements.
#                 The 'talib' argument must be false for 'ddof' to work.
#                 Default: 1
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Note: TA Lib does not have a 'ddof' argument.
#         Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom roll roll_var
#' @export
variance <- function(.close=NULL, ohlc, n = 30L, ddof = 1L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    variance <- roll_var(.close, n)    
    if (ddof == 0L)
        variance <- variance * ((n-1) / n)

    # Offset
    if (is.integer(offset) && offset != 0L)
        variance <- shift(variance, offset)

    # Fill
    variance <- vec_fill(variance, ...)

    # Name and Category
    attr(variance, "name") <- paste("variance", n, sep="_")
    attr(variance, "category") <- "statistics"

    return (variance)
}
