# """Double Exponential Moving Average (DEMA)

# The Double Exponential Moving Average attempts to a smoother average
# with less lag than the normal Exponential Moving Average (EMA).

# Sources:
#     https://www.tradingtechnologies.com/help/x-study/technical-indicator-definitions/double-exponential-moving-average-dema/

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
dema <- function(.close=NULL, ohlc, n=10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    # when using ema careful to use n=n
    ema1 <- ema(.close, n=n)
    ema2 <- ema(ema1, n=n)
    dema <- 2 * ema1 - ema2
 
    # Offset
    if (is.integer(offset) && offset != 0L)
        dema <- shift(dema, offset)

    # Fill
    roc <- vec_fill(roc, ...)

    # Name and Category
    attr(dema, "name") <- paste("dema", n, sep="_")
    attr(dema, "category") <- "overlap"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (dema)
}
