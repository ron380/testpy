

# """cfo (cfo)

# Rate of change between the source and a moving average.

# Sources:
#     Few internet resources on definitive definition.
#     Request by Github user homily, issue #46

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): The period. Default: 26
#     mamode (str): See ``help(ta.ma)``. Default: 'sma'
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """



# Awesome Oscillator (cfo)

# The Awesome Oscillator is an indicator used to measure a security's
# momentum. cfo is generally used to affirm trends or to anticipate
# possible reversals.

# Sources:
#     https://www.tradingview.com/wiki/Awesome_Oscillator_(cfo)
#     https://www.ifcm.co.uk/ntx-indicators/awesome-oscillator

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     fast (int): The short period. Default: 5
#     slow (int): The long period. Default: 34
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
#' @export
cfo <- function(.close=NULL, ohlc, n=26L, mamode="sma", offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }
    
    # Validate    
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)


    # Calculate
    cfo <- scalar * (.close - linreg(.close, n=n, tsf=TRUE)) / .close


    # Offset
    if (is.integer(offset) && offset != 0L)
        cfo <- shift(cfo, offset)

    # Fill
    cfo <- vec_fill(cfo, ...)


    # Name and Category
    attr(cfo, "name") <- paste("cfo", mamode, n, sep="_")
    attr(cfo, "category") <- "momentum"

    return (cfo)
}
