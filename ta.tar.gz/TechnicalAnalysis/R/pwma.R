# """Pascal's Weighted Moving Average (PWMA)

# Pascal's Weighted Moving Average is similar to a symmetric triangular
# window except PWMA's weights are based on Pascal's Triangle.

# Source: Kevin Johnson

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period.  Default: 10
#     asc (bool): Recent values weigh more. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
pwma <- function(.close=NULL, ohlc, n=10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    # write using
    # asc = v_ascending(asc)
    # offset = v_offset(offset)

    # # Calculate
    # triangle = pascals_triangle(n=length - 1, weighted=True)
    # pwma = close.rolling(length, min_periods=length) \
    #     .apply(weights(triangle), raw=True)

    # print(.close)
    # Calculation
    # https://bookdown.org/kochiuyu/technical-analysis-with-r-second-edition/simple-moving-average-pwma.html
    pwma <- c()
    # this is done automatically 
    pwma[1:(n-1)] <- NA
    for (i in n:length(.close)) {
        pwma[i] <- base::mean(.close[(i-n+1):i])
    }
    # print(pwma)
    # use roll_mean
  
    # Offset
    if (is.integer(offset) && offset != 0L)
        pwma <- shift(pwma, offset)

    # Fill
    pwma <- vec_fill(pwma, ...)

    # Name and Category
    attr(pwma, "name") <- paste("pwma", n, sep="_")
    attr(pwma, "category") <- "overlap"

    return (pwma)
}
