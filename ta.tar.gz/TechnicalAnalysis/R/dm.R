# """Directional Movement (DM)

# The Directional Movement was developed by J. Welles Wilder in 1978
# attempts to determine which direction the price of an asset is moving.
# It compares prior highs and lows to yield to two series +DM and -DM.

# Sources:
#     https://www.tradingview.com/pine-script-reference/#fun_dmi
#     https://www.sierrachart.com/index.php?page=doc/StudiesReference.php&ID=24&Name=Directional_Movement_Index

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     mamode (str): See ``help(ta.ma)``.  Default: 'rma'
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib vedmon. Default: True
#     drift (int): The difference period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.DataFrame: DMP (+DM) and DMN (-DM) columns.
# """
#' @export
dm <- function(.high=NULL, .low=NULL, ohlc, n=14L, drift=1L, scalar=100, mamode="rma", offset=0L, ..., append=FALSE) {


    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        .high = ohlc$high
        .low = ohlc$low
    }


    # Validate
    .high <- vector.check.minlength(.high, n)
    .low <- vector.check.minlength(.low, n)

    if (is.null(.high) || is.null(.low))
        return (NULL)


    drift <- ifelse(missing(drift), 1L, as.integer(drift))
    # pick mamode
    .ma <- ma(mamode)

    up <- .high - shift(.high, drift)
    dn <- shift(.low, drift) - .low

    pos_ <- ((up > dn) & (up > 0)) * up
    neg_ <- ((dn > up) & (dn > 0)) * dn

    pos_ <- zero(pos_)
    neg_ <- zero(neg_)

    # Not the same values as TA Lib's -+DM (Good First Issue)
    pos <- .ma(pos_, n=n)
    neg <- .ma(neg_, n=n)

    
    # Offset
    if (is.integer(offset) && offset != 0L) {
        pos <- shift(pos, offset)
        neg <- shift(neg, offset)
    }

    # Fill
    pos <- vec_fill(pos, ...)
    neg <- vec_fill(neg, ...)

    # Name and Category
    attr(dm, "name") <- paste("dm", mamode, n, sep="_")
    attr(dm, "category") <- "momentum"

    data <- list(pos, neg)
    setNames(data, c(paste("dmp", n, sep="_"), paste("dmn", n, sep="_")))

    # Append
    if (append && !missing(ohlc))
        return (bind_cols(ohlc, !!attr(dm, "name") := dm))

    return (dm)
}
