# """Triangular Moving Average (TRIMA)

# A weighted moving average where the shape of the weights are triangular
# and the greatest weight is in the middle of the period.

# Sources:
#     https://www.tradingtechnologies.com/help/x-study/technical-indicator-definitions/triangular-moving-average-trima/
#     tma = sma(sma(src, ceil(length / 2)), floor(length / 2) + 1)  # Tradingview
#     trima = sma(sma(x, n), n)  # Tradingview

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 10
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     adjust (bool): Default: True
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# 
#' @export 
trima <- function(.close=NULL, ohlc, n=10L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)


    half_length <- round(0.5 * (n + 1))
    sma1 <- sma(.close, n=half_length)
    trima <- sma(sma1, n=half_length)


    # Offset
    if (is.integer(offset) && offset != 0L)
        trima <- shift(trima, offset)

    # Fill
    trima <- vec_fill(trima, ...)

    # Name and Category
    attr(trima, "name") <- paste("trima", n, sep="_")
    attr(trima, "category") <- "overlap"

    # Append
    # if (append)
    #    bind_cols(ohlc, trima)

    return (trima)
}
