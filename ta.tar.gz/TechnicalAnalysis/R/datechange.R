# """Day of week 
#  Mon=1
#' @importFrom xts endpoints
#' @export
datechange <- function(.date=NULL, ohlc, period=c("halfyearly", "quarterly", "monthly", "weekly", "biweekly"), boundary="begin", offset=0L, ..., append=FALSE) {
    
    # period handling
    period <- match.arg(period)
    period_tab.e <- list(halfyearly = "quarters", quaterly = "quarters", monthly = "months", weekly = "weeks", biweekly = "weeks")
    period_tab.k <- list(halfyearly = 2, quaterly = 1, monthly = 1, weekly = 1, biweekly = 2)
    period.e <- period_tab.e[[period]]
    period.k <- period_tab.k[[period]]


    # boundary indicator (boi)
    boi_validate <- c("begin", "end")
    boi <- match.arg(boundary, boi_validate)


    if (!missing(ohlc)) {
        stopifnot("date" %in% names(ohlc))
        .date <- ohlc$date
    }

    # Validate
    if (is.null(.date) || !is.Date(.date))
        return (NULL)


    # Calculate
    # compute endpoints and remove the first element
    ep <- endpoints(.date, on=period.e, k=period.k)[-1]
    datechange <- logical(length(.date))
    if (boi == "end")
        datechange[ep] <- TRUE 
    else if (boi == "begin")
        datechange[ep + 1] <- TRUE


    # Offset
    if (is.integer(offset) && offset != 0L)
        datechange <- shift(datechange, offset)

    # Fill
    datechange <- vec_fill(datechange, ...)

    # Name and Category
    attr(datechange, "name") <- paste("datechange")
    attr(datechange, "category") <- "datetime"


    # Prefix/Suffix
    datechange <- name_append(datechange, ...)


    # Append
    if (append && !missing(ohlc)) {
        ohlc[[attr(datechange, "name")]] = datechange
        return(ohlc)
    }

    return (datechange)
}
