# """Exhaustion Count (EXHC)

# Inspired by Tom DeMark's Sequential indicator which attempts
# to identify where an uptrend or a downtrend exhausts and reverses.

# Sources:
#     https://demark.com
#     http://practicaltechnicalanalysis.blogspot.com/2013/01/tom-demark-sequential.html

# Args:
#     close (pd.Series): Series of close's
#     length (int): Difference for the sequences. Default: 4
#     cap (int): Maximum sequence number to cap at. Set to zero for
#         no max. Default: 13
#     show_all (bool): Show 1 - 13. If set to False, show 6 - 9.
#         Default: True
#     asint (bool): If True, fillna's with 0 and change type to int.
#         Default: False
#     nozeros (bool): If True, replaces zeros with nan. Default: False
#     offset (int): How many periods to offset the result. Default: 0

# Returns:
#     pd.DataFrame: Down count, Up count
# """
#' @export
exhc <- function(.close=NULL, ohlc, n=4L, lb=6L, ub=9L, cap=13L, as.int=FALSE, show.all=TRUE, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    # Calculate
    close_diff <- diff(.close, n)
    neg_diff <- close_diff < 0
    pos_diff <- close_diff > 0

    dn_csum <- cumsum(neg_diff)
    up_csum <- cumsum(pos_diff)

    dn <- dn_csum - ffill(ifelse(!neg_diff, dn_csum, NA))
    up <- up_csum - ffill(ifelse(!pos_diff, up_csum, NA))

    if (cap > 0)
        dn <- clip(dn, 0, cap)
        up <- clip(up, 0, cap)

    # if (show_all) {
    #     dn <- where(dn == 0, 0, dn)
    #     up <- where(up == 0, 0, up)
    # }
    if (!show.all) {
        between_lu <- (dn >= lb) & (dn <= ub)
        dn <- ifelse(between_lu, dn, 0)
        up <- ifelse(between_lu, up, 0)
    }

    if (as.int) {
        dn <- as.integer(dn)
        up <- as.integer(up)
    }
    
    # Offset
    if (is.integer(offset) && offset != 0L) {
        dn <- shift(dn, offset)
        up <- shift(up, offset)
    }

    # Fill
    # exhc <- vec_fill(exhc, ...)


    # Name and Category
    exhc <- list(dn, up)
    setNames(exhc, c(paste("exhc_dn", n, sep="_"), paste("exhc_up", n, sep="_")))

    attr(exhc, "name") <- paste("exhc", n, sep="_")
    attr(exhc, "category") <- "momentum"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (exhc)
}
