# """Datenum 
#  Mon=1
#' @importFrom lubridate year month day
#' @export
datenum <- function(.date=NULL, ohlc, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("date" %in% names(ohlc))
        .date <- ohlc$date
    }

    # Validate
    if (is.null(.date) || !is.Date(.date))
        return (NULL)

    # Calculate
    # check week start
    datenum <- 10000 * (year(.date) - 1900) + 100 * month(.date) + day(.date)

    # Offset
    if (is.integer(offset) && offset != 0L)
        datenum <- shift(datenum, offset)

    # Fill
    datenum <- vec_fill(datenum, ...)

    # Name and Category
    attr(datenum, "name") <- paste("datenum")
    attr(datenum, "category") <- "datetime"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (datenum)
}
