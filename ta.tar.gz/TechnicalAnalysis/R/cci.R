# """Commodity Channel Index (CCI)

# Commodity Channel Index is a momentum oscillator used to primarily
# identify overbought and oversold levels relative to a mean.

# Sources:
#     https://www.tradingview.com/wiki/Commodity_Channel_Index_(CCI)

# Args:
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 14
#     c (float): Scaling Constant. Default: 0.015
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @export
cci <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, n=14L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }

    # Validate
    .length <- 2 * n
    .high <- vector.check.minlength(.high, .length)
    .low <- vector.check.minlength(.low, .length)
    .close <- vector.check.minlength(.close, .length)

    if (is.null(.high) || is.null(.low) || is.null(.close))
        return (NULL)

    # Calculate
    typical_price <- hlc3(.high=.high, .low=.low, .close=.close)
    mean_typical_price <- sma(typical_price, n=n)
    mad_typical_price <- mad(typical_price, n=n)

    cci <- typical_price - mean_typical_price / (c * mad_typical_price)


    # Offset
    if (is.integer(offset) && offset != 0L)
        cci <- shift(cci, offset)


    # Fill
    cci <- vec_fill(cci, ...)

    # Name and Category
    attr(cci, "name") <- paste("cci", n, sep="_")
    attr(cci, "category") <- "momentum"

    return (cci)
}

