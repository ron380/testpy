# """Log Return

# Calculates the logarithmic return of a Series.
# See also: help(df.ta.log_return) for additional **kwargs a valid 'df'.

# Sources:
#     https://stackoverflow.com/questions/31287552/logarithmic-returns-in-pandas-dataframe

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 20
#     cumulative (bool): If True, returns the cumulative returns.
#         Default: False
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)

# Returns:
#     pd.Series: New feature generated.
# """

#' @export 
log_return <- function(.close=NULL, ohlc, n = 1L, cumulative=FALSE, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close <- ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n+1)

    if (is.null(.close))
        return (NULL)

    close_ <- .close
    if (cumulative)
        log_return <- (close_ / close_[1])
    else
        log_return <- (close_ / shift(close_, n))
    
    # using diff diff(log(close_, n), length(close_)
    log_return <- log(log_return)

    # Offset
    if (is.integer(offset) && offset != 0L)
        log_return <- shift(log_return, offset)

    # Fill
    log_return <- vec_fill(roc, ...)

    # Name and Category
    props <- ifelse(cumulative, "cum", "") 
    attr(log_return, "name") <- paste(paste0(props, "logtret"), n, sep="_")
    attr(log_return, "category") <- "performance"

    # Prefix/Suffix
    log_return <- name_append(log_return, ...)


    # Append
    if (append && !missing(ohlc)) {
        ohlc[[attr(log_return, "name")]] = log_return
        return(ohlc)
    }

    return (log_return)
}
