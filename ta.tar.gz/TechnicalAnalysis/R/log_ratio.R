# """Price Ratio

# Calculates the price ratio of a Series compared the previous Close.
# See also: help(df.ta.ratio) for additional **kwargs a valid 'df'.

# Sources:
#     https://stackoverflow.com/questions/31287552/logarithmic-returns-in-pandas-dataframe

# Calculation:
#     Default Inputs:
#         length=1, cumulative=False
#     PCTRET = series.1/shift(series.2, n)
#     or
#     PCTRET = (open - close)/close.shift(length)
#     CUMPCTRET = PCTRET.cumsum() if cumulative

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period.  Default: 20
#     cumulative (bool): If True, returns the cumulative returns.  Default: False
#     offset (int): How many periods to offset the result.  Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """


#' @export 
ratio <- function(series.1, series.2=NULL, ohlc, n = 1L, cumulative=FALSE, percent=FALSE, scalar=100, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        series.2 <- .close
    }

    stopifnot(missing(ohlc) && is.null(series.2))

    # Validate
    series.2 <- vector.check.minlength(series.2, n+1)

    if (is.null(series.2))
        return (NULL)
    
    f <- ifelse(percent, 1, 0)
    ratio <- scalar * (series.1 / shift(series.2, n) - f)
        
    # Offset
    if (is.integer(offset) && offset != 0L)
        ratio <- shift(ratio, offset)

    # Fill
    ratio <- vec_fill(roc, ...)

    # Name and Category
    props <- ifelse(cumulative, "cum", "") 
    attr(ratio, "name") <- paste(paste0(props, "pctret"), n, sep="_")
    attr(ratio, "category") <- "performance"

    # Append
    # if (append)
    #    bind_cols(ohlc, roc)

    return (ratio)
}

# def ratio(
#     open_: Series, close: Series, length: Int = None, scalar: IntFloat = None, pct: bool = None,
#     cumulative: bool = None,
#     offset: Int = None, **kwargs: DictLike
# ) -> Series:


#     # Validate Arguments
#     close = v_series(close)
#     open_ = v_series(open_)
#     length = v_pos_default(length, 1)
#     offset = v_offset(offset)
#     scalar = v_scalar(scalar, 100)
#     pct = v_bool(pct, False)

#     # Calculate Result
#     fff = 1 if pct else 0
#     pct = scalar * (open_/close.shift(periods=length) - fff)

#     if cumulative:
#         pct = pct.cumsum()

#     # Offset
#     if offset != 0:
#         pct = pct.shift(offset)

#     # Name and Category
#     pct.name = f"{'CUM' if cumulative else ''}RATIO_{length}"
#     pct.category = 'transform'

#     return pct