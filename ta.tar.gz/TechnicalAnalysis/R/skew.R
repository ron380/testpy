# """Rolling Skew

# Calculates the Skew over a rolling period.

# WARNING: This function may leak future data when used for machine learning.
#     Setting lookahead=False does not currently prevent leakage.
#     See https://github.com/twopirllc/pandas-ta/issues/667.

# Args:
#     close (pd.Series): Series of 'close's
#     length (int): It's period. Default: 30
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """
#' @importFrom zoo rollapplyr
#' @importFrom moments skewness
#' @export
skew <- function(.close=NULL, ohlc, n = 30L, offset=0L, ..., append=FALSE) {

    if (!missing(ohlc)) {
        stopifnot("close" %in% names(ohlc))
        .close = ohlc$close
    }

    # Validate
    .close <- vector.check.minlength(.close, n)

    if (is.null(.close))
        return (NULL)

    # Calculate
    skew <- rollapplyr(.close, width = n, FUN=function(x) { skewness(x) }, fill=NA)
    
    
    # Offset
    if (is.integer(offset) && offset != 0L)
        skew <- shift(skew, offset)

    # Fill
    skew <- vec_fill(skew, ...)

    # Name and Category
    attr(skew, "name") <- paste("skew", n, sep="_")
    attr(skew, "category") <- "statistics"

    return (skew)
}
