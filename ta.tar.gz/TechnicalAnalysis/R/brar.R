# """BRAR (BRAR)

# BR and AR

# Sources:
#     No internet resources on definitive definition.
#     Request by Github user homily, issue #46

# Args:
#     open_ (pd.Series): Series of 'open's
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     length (int): The period. Default: 26
#     scalar (float): How much to magnify. Default: 100
#     drift (int): The difference period. Default: 1
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.DataFrame: ar, br columns.
# """
#' @importFrom roll roll_sum
#' @export
brar <- function(.open=NULL, .high=NULL, .low=NULL, .close=NULL, ohlc, n=26, scalar=1L, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("open" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))
        .open <- ohlc$open
        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }
    
    # Validate
    .open <- vector.check.minlength(.open, n)
    .close <- vector.check.minlength(.close, n)
    .high <- vector.check.minlength(.high, n)
    .low <- vector.check.minlength(.low, n)

    if (is.null(.high) || is.null(.low) || is.null(.open) || is.null(.close))
        return (NULL)

 
    # Calculate
    high_open_range <- non_zero_range(.high, .open)
    open_low_range <- non_zero_range(.open, .low)
    hcy <- non_zero_range(.high, shift(.close, drift))
    cyl <- non_zero_range(shift(.close, drift), low)

    hcy[hcy < 0] <- 0  # Zero negative values
    cyl[cyl < 0] <- 0  # ""

    ar <- scalar * roll_sum(high_open_range, n) / roll_sum(open_low_range, n)
    br <- scalar * roll_sum(hcy, n) / roll_sum(cyl, n)
    
    # Offset
    if (is.integer(offset) && offset != 0L) {        
        ar <- shift(ar, offset)
        br <- shift(br, offset)
    }


    # Fill
    ar <- vec_fill(ar, ...)
    br <- vec_fill(br, ...)

    # Name and Category
    ar.name <- paste("ar", n, sep="_")
    br.name <- paste("br", n, sep="_")    
    brar <- bind_cols(!!ar.name := ar, !!br.name :=br)

    
    attr(brar, "name") <- paste("brar", n, sep="_")
    attr(brar, "category") <- "momentum"

    return (brar)
}
