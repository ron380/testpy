# """Balance of Power (hlc3)

# Balance of Power measure the market strength of buyers against sellers.

# Sources:
#     http://www.worden.com/TeleChartHelp/Content/Indicators/Balance_of_Power.htm

# Args:
#     open (pd.Series): Series of 'open's
#     high (pd.Series): Series of 'high's
#     low (pd.Series): Series of 'low's
#     close (pd.Series): Series of 'close's
#     scalar (float): How much to magnify. Default: 1
#     talib (bool): If TA Lib is installed and talib is True, Returns
#         the TA Lib version. Default: True
#     offset (int): How many periods to offset the result. Default: 0

# Kwargs:
#     fillna (value, optional): pd.DataFrame.fillna(value)
#     fill_method (value, optional): Type of fill method

# Returns:
#     pd.Series: New feature generated.
# """

#' @export
hlc3 <- function(.high=NULL, .low=NULL, .close=NULL, ohlc, offset=0L, ..., append=FALSE) {
    
    if (!missing(ohlc)) {
        stopifnot("high" %in% names(ohlc))
        stopifnot("low" %in% names(ohlc))
        stopifnot("close" %in% names(ohlc))

        .high <- ohlc$high
        .low <- ohlc$low
        .close <- ohlc$close
    }
    
    # Validate
    if (is.null(.high) || is.null(.low) || is.null(.close)  )
        return (NULL)

 
    # Calculate
    hlc3 <- (.high + .low + .close) / 3.0


    # Offset
    if (is.integer(offset) && offset != 0L)
        hlc3 <- shift(hlc3, offset)

    # Fill
    hlc3 <- vec_fill(hlc3, ...)

 
    # Name and Category
    hlc3.name <- "hlc3"
    hlc3.category <- "overlap"

    return (hlc3)
}
