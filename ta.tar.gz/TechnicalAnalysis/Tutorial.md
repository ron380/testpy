In this tutorial we will elaborate on installing and running the package


> R
roll_sum(df$AAPL.us\$close)
roll_sum(df$AAPL.US\$close, l0)
tk_xts (df\$AAPL. US\$close)
tk_xts (df$$AAPL.US)$
tk_xts (df\$AAPL.uS)
roll_sum(tk_xts(df\$AAPL.US)\$close, l0)

# installation
devtools::install_local ("c:/Users/ronsh/code/R-devel/TechnicalAnalysis")

calling the function TechnicalAnalaysis::roc

two options with force=T:
R 
devtools::install_local ("c:/Users/ronsh/code/R-devel/TechnicalAnalysis", force=T)
devtools::install_local (".", force=T)

sometimes we need to detach the package
detach(package:TechnicalAnalysis)
or better unload
detach("package:TechnicalAnalysis", unload = TRUE)
detach("package:ta", unload = TRUE)

# generate NAMESPACE exports
from ~/code/R-devel/TechnicalAnalysis 
run R
> devtools::document()

# Running the examples

take from run_strategy.R

```R
library(tidyverse, warn.conflicts = FALSE)
# add TTR, quant
library (tidyquant, warn.conflicts = FALSE)
# function composition https://search.r-project.org/CRAN/refmans/gestalt/html/compose.htm
# function operators
library(gestalt)
base_path <- file.path("C:/Users/ronsh/eoddata")
symbol_universe_metadata <- read_csv(file.path(base_path, "list", "US_marketcap_1B_symbols.csv"), show_col_types = FALSE)
sectors <- symbol_universe_metadata |> pull (sector) |> unique()
cat ("sectors: ", paste(sectors, sep=", "), "\n")
symbols <- c('AAPL.US', 'MSFT.US', 'NVDA.US', 'NFLX.US', 'AMZN.US')
# concatenate symbols to path and apply read_csv function
# df is a list of tibbles and we want it to be indexed indexed using setNames
df <- map(file.path(base_path, "us", "daily", paste0(symbols, ".csv")), ~read_csv(., col_types = cols(date = col_date()), show_col_types=FALSE)) |> setNames(symbols)
TechnicalAnalaysis::roc(df$AAPL.US)
TechnicalAnalaysis::roc(df$AAPL.US$close)
```

# search within the package list
> grep("roll", .packages(all.available = T), ignore.case = T, value = T)
[1] "RcppRoll" "roll"
[2] grep("http", rownames(installed_packages), value = TRUE)

# some experiments with zoo.rollapply
in this example we use rank over the window
rollapplyr is the version with alignment to the right
rollapplyr(x, width = 5, FUN=function(x) { order(x)[1] }, fill=NA)


for finding the index of min, but it's calculationg within the array from left to right
roll_idxmin



use apply to return array of list/structures and then combine to dataframe for better readibility
# Create a matrix
mat <- matrix(1:12, nrow = 3)

# Define a function that returns two values
my_function <- function(x) {
  sum_val <- sum(x)
  mean_val <- mean(x)
  return(list(sum_val = sum_val, mean_val = mean_val))
}

# Apply the function to each row (MARGIN = 1)
result <- apply(mat, MARGIN = 1, my_function)

# Convert the result to a data frame for better readability
result_df <- do.call(rbind, result)

# Print the result
print(result_df)


# loading a package for debuging

devtools::load_all()
devtools::load_all(".")

## generate tests
from devtools run:
use_testthat()

# install package

# python check pandas_ta
reference: QBacktester 



# remark on append 
we don't want to override the dataframe as it's the source downloaded ohlc
