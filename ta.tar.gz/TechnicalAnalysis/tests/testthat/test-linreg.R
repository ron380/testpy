
test_that("test linreg functions CSV", {
    data <- read_csv("compdir/AAPL.US.csv", show_col_types=FALSE)
    max_print <- 20
    attr_list <- c("slope", "intercept")
    func <- "linreg"
    for (attr in attr_list) {
        col <- paste(func, attr, sep="_")
        cat("\n", glue("checking {func} ..."), "\n")
        # load the python results
        data_check <- read_csv(glue("compdir/check-{func}-{attr}.csv"), show_col_types=FALSE)
        # print(head(data_check), max_print)
        # apply the function with attribute
        params <- list(ohlc=data)
        params[[attr]] <- TRUE        
        result <- do.call(func, params)
        cat("result of func\n")
        print(head(result, max_print))
        cat("loaded check\n")
        print(head(data_check[[col]], max_print))
        # equal with tolerance
        expect_equal(as.vector(result), data_check[[col]])
    }
})
