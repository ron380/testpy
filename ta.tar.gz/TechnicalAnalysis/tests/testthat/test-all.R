

test_that("all test scalar functions CSV", {
    data <- read_csv("compdir/AAPL.US.csv", show_col_types=FALSE)
    max_print <- 20
    func_list <- c("ema", "rma", "zlma")
    
    for (func in func_list) {
        cat("\n", glue("checking {func} ..."), "\n")
        data_check <- read_csv(glue("compdir/check-{func}.csv"), show_col_types=FALSE)
        
        # print(head(data_check), max_print)
        result <- get(func)(ohlc=data)
        cat("result of func\n")
        print(head(result, max_print))
        cat("loaded check\n")
        print(head(data_check[[func]], max_print))
        # equal with tolerance
        expect_equal(as.vector(result), data_check[[func]])
    }
})


