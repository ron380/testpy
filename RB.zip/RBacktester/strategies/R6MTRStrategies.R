
library(ta)


# class MTRSStrategy56(QVStrategy):
#     """
#         Idea:
#         RSI(5) cross over the zero line (tesing)
#     """
#     # class attributes
#     copy = False
#     deep = False

#     # derived class
#     # see https://stackoverflow.com/questions/28399131/how-can-i-simply-pass-arguments-to-parent-constructor-in-child-class


# the strategy grid search parameters
# https://www.r-bloggers.com/2016/12/grid-search-in-the-tidyverse/
params_grid <- list(
    ProfitTargetPercent = seq(2, 5, 0.5),
    HoldDays = seq(3, 5)
    # "OffsetBuyPercent": pybt.npFloatRange(0.05, 0.1, 0.01)
)
# grid is created by cross product
params_grid |> tidyr::expand_grid() 


# create a strategy give its name and inherit the package
MTRSStrategy56 <- R6Class("MTRSStrategy56", 
    inherit = RBacktester::R6Strategy,
    public = list(
        preprocess = function(ohlcv, ...) {
            ta::rsi(ohlc=ohlcv, n=5, append=TRUE)
            
        },
        fit = function(ohlcv, 
                    ProfitTargetPercent = 3,
                    HoldDays = 3,
                    OffsetBuyPercent = 0.2,
                    ...) {
                        
            rsi <- ohlcv[["rsi_rma_5"]]  # get as vector (while single bracket gives tibble column)
            # rsi <- get_series(ohlcv, "rsi_rma_5")
            # print(rsi)
            x <- ta::cross_value(rsi, 50, above=TRUE)
            print(x)
            
            self$Buy <- ta::cross_value(rsi, 50, above=TRUE)
            
            self$set_tradeordermode(ohlcv, mode=OrderMode$orderThisBarClose)
            self$set_tradedirection(TradeDirection$tradeDirectionLong)

            self$apply_stop(ohlcv, StopType$stopTypeProfit, StopMode$stopModePercent, ProfitTargetPercent)
            self$apply_stop(ohlcv, StopType$stopTypeNBar, StopMode$stopModeBars, HoldDays)
            cat(self$Buy)
            invisible(self)
        }
    )
)
