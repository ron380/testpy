library(rlang)

# Define a function that takes an expression and evaluates it
my_function <- function(myexpr) {
  result <- {{ myexpr }}
  print(result)
}

# Call the function with an unevaluated expression
my_function(quo(x + 1))
