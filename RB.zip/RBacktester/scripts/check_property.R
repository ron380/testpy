library(R6)

# Define an R6 class with a property
MyClass <- R6Class(
  "MyClass",
  public = list(
    # Define a property named 'x'
    xx = NULL,
    
    # Getter method for the property 'x'
    get_x = function() {
      private$x
    },
    
    # Setter method for the property 'x'
    set_x = function(value) {
      private$x <- value
    }
  ),
  
  private = list(
    # Private field to store the value of the property 'x'
    x = NULL
  )
)

# Instantiate the class
my_object <- MyClass$new()

# Set the value of the property 'x'
my_object$set_x(10)

# Get the value of the property 'x'
print(my_object$get_x())  # Output: 10
