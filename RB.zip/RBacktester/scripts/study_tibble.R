library(TTR)
data(ttrc)
tibble(ttrc) %>% column_to_rownames("Date") %>% head


library(timetk)
roll_sum(tk_xts(ttrc)$Close, 5)
