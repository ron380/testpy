library(tidyverse, warn.conflicts = FALSE)
library(zoo) # use as.yearmon
# add TTR, quant, do we need this?
# library(tidyquant, warn.conflicts = FALSE)
# function composition https://search.r-project.org/CRAN/refmans/gestalt/html/compose.html
library(gestalt)

base_path <- file.path("C:/Users/ronsh/eoddata")

symbol_universe_metadata <- read_csv(file.path(base_path, "list", "US_marketcap_1B_symbols.csv"), show_col_types = FALSE)

sectors <- symbol_universe_metadata |> pull(sector)|> unique()
cat("sectors: ", paste(sectors, sep=","), "\n")
symbols <- c('AAPL.US', 'MSFT.US', 'NVDA.US', 'NFLX.US', 'AMZN.US', 'META.US')


# concatenate symbols to path and apply read_csv function
# df is a list of tibbles and we want it to be indexed indexed using setNames
df <- map(file.path(base_path, "us", "daily", paste0(symbols, ".csv")), ~read_csv(., show_col_types=FALSE)) |> setNames(symbols)


# subset by date (require library zoo)
start_date <- as.Date(as.yearmon("2002-01"))
end_date <- as.Date(as.yearmon("2003-01"))
df$AAPL.US |> filter(date >= start_date & date < end_date) |> print(n=Inf)

# filter over a list of dates the requested dates and keep only non-NULL elements
train_df <- map(df,  ~ filter(., date >= start_date & date < end_date)) |> keep(~ nrow(.) > 0)
# filter over a list of stocks the requested dates and keep only non-NULL elements
train_df <- map(df,  ~ filter(., between(date, start_date, end_date))) |> keep(~ nrow(.) > 0)
# list_of_tibbles %>% keep(~ nrow(.) > 0)


# learn how to pivot for close on list of dataframes
# first concatenate all rows
all_rows <- bind_rows(df)
all_rows |> pivot_wider(id_cols=c("date"), names_from = c("ticker"), values_from = "close")
# for open, close
all_rows |> pivot_wider(id_cols=c("date"), names_from = c("ticker"), values_from=c("open", "close"), names_sep = ".")


# create multiple columns of different RSI values
map_dfc (c(3,4,5), ~df[[1]] |>  transmute("rsi_{{.}}" := RSI(close, .) ))

# define functions
fun <- RSI(4) %>>>% runMax(5)
# since we are using a matrix we need to subsert it
fu1 <- BBands(3) %>>>% subset(select=2)  %>>>% runMax(3)



# using timetk with great reference
# https://nicholasrjenkins.science/post/tidy_time_series/tts_r/
# for aggregate by week
df$AAPL.US |> summarise_by_time(.by="weeks", open = first(open),
                                high = max(high),
                                low = min(low),
                                close = last(close), .week_start = 1)

# bi weekly aggregation
o_xts |> to.period(OHLC=T, k=2, period="w", indexAt="firstof")

# tsibble aggregate by week

library(tsibble)
library(dplyr)

# Example tsibble data
data <- tibble::tibble(
  time = seq(as.Date("2022-01-01"), as.Date("2022-01-31"), by = "day"),
  value = rnorm(31, mean = 100, sd = 10)
) %>% as_tsibble(index = time)

# Aggregate OHLC values by week
ohlc_weekly <- data %>%
  group_by(week = yearweek(time)) %>%
  summarise(
    Open = first(value),
    High = max(value),
    Low = min(value),
    Close = last(value)
  )

# Print the result
print(ohlc_weekly)


<https://tsibble.tidyverts.org/reference/index-by.html>
gives only year week notation 
tsibble(df$AAPL.US, index=date) %>% index_by(week= ~ yearweek(.)) %>% summarise(open=first(open), high=max(high), low=min(low), close=last(close))
# A tsibble: 1,211 x 5 [1W]
       week  open  high   low close
     <week> <dbl> <dbl> <dbl> <dbl>
 1 2000 W01  105.  113.  95.0  99.5
 2 2000 W02  102.  102.  86.5 100. 
 3 2000 W03  101.  121. 100.  111. 
 4 2000 W04  108.  114. 101.  102. 
 5 2000 W05  101.  110.  94.5 108. 
 6 2000 W06  108.  117. 106.  109. 
 7 2000 W07  109.  120. 109.  111. 
 8 2000 W08  110.  119. 107.  110. 
 9 2000 W09  110.  132. 108.  128. 
10 2000 W10  126   129. 118.  126. 



doing asof join

https://robotwealth.com/more-intuitive-joins-in-dplyr-1-1-0/
