
#' @ImportFrom ooplah AbstractClass
NULL