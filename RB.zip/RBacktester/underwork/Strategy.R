# borrow ideas from package quantstrat (strategy.R )

#' test to see if object is of type 'strategy'
#' @param x object to be tested
#' @export
is.strategy <- function(x) {
    inherits( x, "strategy" )
}


#' retrieve strategy from the container environment
#' @param x string name of object to be retrieved
#' @param envir the environment to retrieve the strategy object from, defaults to .strategy
#' @rdname get.strategy
#' @aliases
#' get.strategy
#' getStrategy
#' @export get.strategy
#' @export getStrategy
get.strategy <- getStrategy <- function(x, envir=.strategy){
    tmp_strat<-get(as.character(x), pos=envir, inherits=TRUE)
    if( inherits(tmp_strat,"try-error") | !is.strategy(tmp_strat) ) {
        warning(paste("Strategy", x, " not found, please create it first."))
        return(FALSE)
    } else {
        if(is.strategy(tmp_strat)) return(tmp_strat) else return(NULL)
    }
}


#' put a strategy object in .strategy env
#' @param strategy object; name will be extracted as strategy$name
#' @param envir the environment to store the strategy in, defaults to .strategy
#' @seealso getStrategy
#' @export
put.strategy <- function(strategy, envir = .strategy)
{
    assign(strategy$name, strategy, envir=as.environment(envir))
}

#' load a strategy object from disk into memory
#' @param strategy_name a string specifying the name of the strategy object; may also be used to create a file name
#' @param file string specifying the filename to use, if NULL, a default will be created
#' @export
load.strategy <- function(strategy_name, file = NULL)
{
    if (is.null(file)) 
        file <- paste(strategy_name, 'RData', sep = ".")

    load(file=file, envir = .strategy)
    assign(strategy_name, .strategy$strategy, envir = .strategy)
    rm("strategy", envir = .strategy)
    invisible(strategy)
}

#' save a strategy object from memory onto disk
#' @param strategy_name a string specifying the name of the strategy object; may also be used to create a file name
#' @param file string specifying the filename to use, if NULL, a default will be created
#' @export
save.strategy <- function(strategy_name, file = NULL)
{
    strategy <- getStrategy(as.character(strategy_name))
    if (is.null(file))
        file <- paste(strategy_name, 'RData', sep=".")

    save(strategy, file=file)
}


# will return a class
strategy <- function(
                 # initialequity: float = 0,
                 drawdownmode= DrawDownMode$drawdownAtClose,
                 tradedirection =  TradeDirection.tradeDirectionBoth,
                 tradefraction = False,
                 maxtrades = NULL,
                 copy = False,
                 ticksize = TickSize$STOCK) {

    # ticksize = ticksize
    # drawdownmode = drawdownmode
    # tradefraction = tradefraction
    # tradedirection = tradedirection
    # maxtrades = NULL,

    # internal attributes
    # bttable = list("buyintent" = NULL,
    # "buyintentprice" = NULL,
    # "shortintent" = NULL,
    # "shortintentprice" = NULL,
    # "buy" = NULL,
    # "buyprice" = NULL,
    # "sell" = NULL,
    # "sellprice" = NULL,
    # "short" = NULL,
    # "shortprice" = NULL,
    # "cover" = NULL,
    # "coverprice" = NULL,
    # "equity" = NULL,
    # "backtrade" = NULL,
    # "barsbackintent" = NULL,
    # "backnbars" = NULL)

    # stores classes of the vectors: orders, prices, tracks
    orders = list(buyintent = NA, buy = NA, sell = NA, shortintent = NA, short = NA, cover = NA)
    prices = list(buyintentprice = NA, buyprice = NA, sellprice = NA, shortintentprice = NA, shortprice = NA, coverprice = NA)
    tracks = list(backtrade = NA,  barsbackintent = NA, backnbars = NA)

    # create the column names of:
    # buyintent, buyintentprice, shortintent, shortintentprice,
    # buy, buyprice, sell, sellprice, ....
    #KEYS = ['buyintent', 'shortintent', 'buy', 'sell', 'short', 'cover']
    # generate for each key its price array
    #KEYS = list(itertools.chain.from_iterable([[f'{o}', f'{o}price'] for o in KEYS]))

    # return out the structure class with the following ordering
    # - the working data usually given as list
    # - attributes
    # - class name
    structure(list(orders=orders, prices=prices, tracks=tracks), 
        # more attributes to be accessed using attr(x, which)
        ticksize = ticksize,
        drawdownmode = drawdownmode,
        tradefraction = tradefraction,
        tradedirection = tradedirection,
        maxtrades = NULL,
        class="Strategy")
}


as_tibble.strategy(strategy, ohlcv) {

    as_tibble(ohlcv, strategy$orders)

}

# Sets trade delays applied by the backtester.
# This function allows you to override trade delays from the "Settings" page.
# It is important do understand what trade delays really do. They in fact internally apply the
# following:

# Buy = Ref( Buy, -buydelay );
# Sell = Ref( Sell, -selldelay );
# Short = Ref( Short, -shortdelay );
# Cover = Ref( Cover, -coverdelay );
# inside backtester after your formula is executed but before backtester starts trade simulation.
# It is functionally equivalent to having above 4 lines at the end of your formula. Note that NO OTHER variables are affected by trade delays, therefore for example if your position sizing depends on values found in buy/sell/short/cover variables *and* if you are using non-zero trade delays you need to account for that in your code.
# EXAMPLE	settradedelays( 1, 1, 1, 1 )

# :param selldelay:
# :param shortdelay:
# :param coverdelay:
# :return:    
set_tradedelays.strategy <- function(strategy, buydelay = 0L, selldelay = 0L, shortdelay = 0L, coverdelay = 0L) {
    
    if (buydelay && is.vector(strategy$orders$buy))
        strategy$orders$buy <- shift(strategy$orders$buy, buydelay, FALSE)
    if (selldelay && is.vector(strategy$orders$sell))
        strategy$orders$sell <- shift(strategy$orders$sell, selldelay, FALSE)
    if (shortdelay && is.vector(strategy$orders$short))
        strategy$orders$short <- shift(strategy$orders$short, shortdelay, FALSE)
    if (coverdelay && is.vector(strategy$orders$cover))
        strategy$orders$cover <- shift(strategy$orders$cover, coverdelay, FALSE)
    
    strategy
}

# methods applied on object
applyIntent <- function(strategy, ohlc, mode=OrderMode$orderBarPrice, ...) {
    
    if (!is.strategy(strategy)) {
        # try get strategy by name
        strategy <- try(getStrategy(strategy))
        # standard way to validate the right object
        if (inherits(strategy, "try-error"))
            stop("You must supply an object or the name of an object of type 'strategy'.")
        store <- TRUE
    }

    # handle the default 
    valid_to <- 3L
    parms=list(...)
    for (name in names(parms) ) {
        assign(name, parms[[name]])
    }

    # internal func
    apply_intent_signal <- function(
                        # function(strategy, we have access from the parent function
                        # ohlc
                        mode,
                        buyshort=c("buy", "short"),
                        validFrom=0L, validTo=-1L) {
    
        # transform buy sell intent arrays to buy arrays

        # ValidFrom -
        #     defines first bar since intent entry when order can generate an exit.
        #     0 means from the very beginning

        # ValidTo -
        #     defines last bar since intent entry when orde can generate an exit.
        #     -1 means "infinite". By default stops are valid all the time (0/-1).


        # :return:
        
        stopifnot(is.integer(validFrom), is.integer(validTo))
        stopifnot(validTo > validFrom || validTo == -1, paste("validFrom {validFrom}, validTo: {validTo}")
        match.arg(buyshort)
        # stopbuyshort == 'buy' | buyshort == 'short', f"buy/short {buyshort}"


        # based on buy sell indicator in the function (string)
        # o <- buyshort
        order_str <- buyshort
        # using quantmod standards
        if (order_str == 'buy') {
            cmp <- operator.ge
            epr <- hlc$high
        }
        else {
            cmp <- operator.le
            epr <- ohlc$low
        }

        # order_str <- o
        orderprice_str <- paste0(o, "price")
        orderintent_str <- paste0(o, "intent")
        orderpriceintent_str <- paste0(o, "price", "intent")

        # handle for the setters since we want full series constructor
        # order_setter = _bttable_setter[f'{o}']
        # orderprice_setter = _bttable_setter[f'{o}price']

        # # set the pointers (not working)
        # order <- strategy$orders[order_str]
        # orderprice <- strategy$prices[orderprice_str]

        # use the getter to obtain the series buy/short intent
        orderintent <- strategy$order[[orderintent_str]]
        orderpriceintent <- strategy$prices[[orderpriceintent_str]]


        N = length(orderintent)
        # validTo = validTo if validTo != -1 else N
        validTo <- ifelse(validTo != -1L, validTo, N)

        switch(mode) {
            OrderMode$orderDisable = {
                return
            },
            OrderMode$orderThisBarClose = {
                
                # copy orderintent to order
                strategy$orders[order_str] <- c(orderintent)

                # bttable[f'{o}price'][bttable[f'{o}'] == 1] = ohlc['close'][bttable[f'{o}'] == 1]
                ### bttable_setter[f'{o}price'](ohlc.close.copy())

                # orderprice_setter(ohlc.close.copy())
                strategy$prices[orderprice_str] <- ohlc$close
                # NEW: write the intent location (bars back from the order taken place)
                strategy$tracks$barsbackintent <- 0L  # Series(0, index=orderintent.index, dtype='Int8')
            },
            OrderMode$orderNextBarOpen = {
                ### bttable_setter[f'{o}'](
                ###     bttable[f'{o}intent'].shift(1, fill_value=False))  # for each bttable['intentbuy].shift()
                strategy$order[order_str] = shift(orderintent, 1, fill_value=F)
                strategy$prices[orderprice_str] <- ohlc$open
                strategy$tracks$barsbackintent = 1L # Series(1, index=orderintent.index, dtype='Int8')
            }
            OrderMode$orderBarPrice = {
                # allocate 
                strategy$tracks$barsbackintent <- empty.vector.as(orderintent)
                for (i in 1:N):
                    if (orderintent[i]):
                        # find from next bar the entry for example in [i+1, i+2)

                        for ( j in (i + 1 + validFrom):(max(i + 1 + validTo, N)) ):
                            if ( cmp(epr[j], orderpriceintent[j]) ):
                                # _bttable[f'{o}']()[j] = True
                                # _bttable[f'{o}price']()[j] = orderpriceintent[j]
                                strategy$order[order_str][j] <- TRUE
                                strategy$prices[orderprice_str][j] <- orderpriceintent[i]
                                # distance from order to intent
                                strategy$tracks$barsbackintent[j] <- j - i
            }
        }
        strategy
    }

    # execute the internal functions
    strategy <- apply_intent_signal(strategy, ohlc, mode, "buy", validTo=valid_to)
    strategy <- apply_intent_signal(strategy, ohlc, mode, "short", validTo=valid_to)

    strategy
}


stop_and_reverse <- function(strategy) {

    if (TradeDirection$tradeDirectionBoth %in% strategy$tradedirection) {
    if TradeDirection.tradeDirectionBoth in self.tradedirection and \
            (self.Cover is None or not self.Cover.any()):

        print("copying Short and Cover")
     
        # sophisticated sapplystop must be applied in postproessing since
        # we cannot copy the sell->short and cover->buy
        strategy$orders$cover = c(strategy$orders$buy)
        # self.strategy.CoverPrice = self.strategy.BuyPrice.copy()
        strategy$orders$short = c(strategy$orders$sell)
        # self.strategy.ShortPrice = self.strategy.SellPrice.copy()

        # what to do with copying shortprice and coverprice?

        
        # first fix the first trade issued by finding the first valid index
        # we will clear the exits sell and cover for the stop and reverse method
        idx_buy = first_nz(strategy$orders$buy)
        idx_short = first_nz(strategy$orders$short)
        print(idx_buy, idx_short)
        if (idx_buy < idx_short)
            strategy$orders$cover[idx_buy] <- FALSE
        else if (idx_short < idx_buy)
            strategy$orders$sell[idx_short] <- FALSE
    }
}


applystop <- function(strategy, ohlc, type, mode, amount, *, exitatstop=NA, volatile=FALSE,
                validFrom= 0, validTo= -1) {
    # type - StopType
    # mode - StopMode

    # enable stop and reverse, we copy the sell->short for reverse
    if (strategy.tradedirection == TradeDirection.tradeDirectionBoth:
        print(">> tradedirection = ", self.tradedirection)
        print(">> add stop and reverse")
        # fix the Short/Cover
        self._stop_and_reverse()

    # activate each _applystop seprately for the buy mode and for the sell mode
    if (TradeDirection$tradeDirectionLong %in% strategy$tradedirection) {
        # check we have sell array
        
        if is.null(strategy$orders$sell)
            self.Sell = c(False, index=self.Buy.index)

        self._applystop(ohlc, type, mode, "buy", amount, exitatstop=exitatstop, volatile=volatile,
                        validFrom=validFrom, validTo=validTo)

    if TradeDirection.tradeDirectionShort in self.tradedirection:
        # check we have sell array
        if self.Cover is None:
            self.Cover = Series(False, index=self.Buy.index)

        self._applystop(ohlc, type, mode, "short", amount, exitatstop=exitatstop, volatile=volatile,
                        validFrom=validFrom, validTo=validTo)

def _applystop(self, ohlc: DataFrame, type: StopType, mode: StopMode, buyshort: str, amount: Union[float, int], exitatstop, volatile,
                validFrom, validTo):

    assert buyshort == 'buy' or buyshort == 'short', f"buy/short {buyshort}"

    ticksize = self.ticksize

    # handle operation for a given price point p dollar or percentage
    # l is a direction +1 for long, -1 for short
    # p - current price,
    # a - amount increase in dollars or percent,
    # l - direction (long/short)
    op_point = lambda p, a, l: p - l * a * ticksize
    op_percent = lambda p, a, l: p * (1 - l * a / 100.)

    # set the operandmode using the above lambdas: op_point or op_percent
    if mode == StopMode.stopModeDisable:
        return
    elif mode == StopMode.stopModePoint:
        operandmode = op_point
    elif mode == StopMode.stopModePercent:
        operandmode = op_percent

    # based on buysell string we get control of the
    # entry and the exit array
    o = buyshort
    e = 'sell' if o == 'buy' else 'cover'

    # l - long/short,
    # exitprice - exitprice,
    # mopen - operator for open (in case there is a gap)
    if (type == StopType.stopTypeLoss and o == 'buy') or (type == StopType.stopTypeProfit and o == 'short'):
        cmp = operator.ge
        l = 1
        exitohlcseries = ohlc.low.values
        maxmin_with_open = min
    elif (type == StopType.stopTypeLoss and o == 'short') or (type == StopType.stopTypeProfit and o == 'buy'):
        cmp = operator.le
        l = -1
        exitohlcseries = ohlc.high.values
        maxmin_with_open = max
    # handle trailing stop for buy and short
    elif (type in (StopType.stopTypeTrailing | StopType.stopTypeTrailingHL) and o == 'buy'):
        entryprice = ohlc.high if type == StopType.stopTypeTrailingHL else ohlc.close
        cmp = operator.ge
        l = 1
        exitohlcseries = ohlc.low.values
        maxmin_with_open = min
    elif (type in (StopType.stopTypeTrailing | StopType.stopTypeTrailingHL) and o == 'short'):
        entryprice = ohlc.low if type == StopType.stopTypeTrailingHL else ohlc.close
        cmp = operator.le
        l = -1
        exitohlcseries = ohlc.high.values
        maxmin_with_open = max

    # main:
    # entry order/price and exit order/price
    entryorderseries = self._bttable[o]()
    exitorderseries = self._bttable[e]()
    entrypriceseries = self._bttable[f'{o}price']()
    exitpriceseries = self._bttable[f'{e}price']()

    N = len(entryorderseries)


    # backtrade - stores the origin of the trade (where the buy was found) once an exit occurs
    # then we know from different exits attached to a trade which occurs first
    # first check if not initialized and then get the data from the series
    if self.BackTrade is None:
        # self.log.debug("initialize backtrade and set to point by self.backtrade")
        # some ways tried to init backtrade:
        # self.backtrade = Series(None, index=entryorderseries.index)
        # backtrade_ = np.array([None] * N)
        # backtrade_ = [None] * N
        # incorrect way:
        # backtrade_ = [[]] * N # not working as it the same list in the array

        # this is the current correct way since we initialize a new list for every row
        # backtrade = [[] for i in range(N)]
        backtrade_ = [None] * N
        # backtrade will create list on the fly, but we need a new list at each slot
        # for i in range(N):
        #     backtrade_[i] = list()
        # copy=False is not working

        # wrapup by Series
        self.BackTrade = Series(backtrade_, index=entryorderseries.index, copy=False)

    # access by ref to the numpy array pointed by backtrade series
    backtrade_ = self.BackTrade.values

    # stores the number of bars back for the originator/intent of the trade
    if self.BackNBars is None:
        backnbars_ = [None] * N
        self.BackNBars = Series(backnbars_, index=entryorderseries.index)

    backnbars_ = self.BackNBars.values


    # cdef:
    #     SSIZE_t i, j, None

    NN = N
    # project: use std.vector as list
    if type in (StopType.stopTypeTrailing | StopType.stopTypeTrailingHL):
        # trailing stop
        for i in range(N):
            if entryorderseries[i]:
                for j in range(i + 1 + validFrom, max(i + 1 + validTo, N)):
                    targetprice = operandmode(entryprice[j - 1], amount, l)
                    if cmp(targetprice, exitohlcseries[j]):
                        exitorderseries[j] = True
                        exitpriceseries[j] = targetprice
                        # update the origin of the trades
                        if not backtrade_[j]:
                            backtrade_[j] = [i]
                        else:
                            backtrade_[j].append(i)

                        break # th j loop
    # nbars exit at close ( enable a feature for open of next bar? )
    elif type == StopType.stopTypeNBar:
        for i in range(N - amount):
            if entryorderseries[i]:
                # use j = i + amount
                j = i + amount
                exitorderseries[j] = True
                exitpriceseries[j] = ohlc.close[j]

                # backtrade indicator
                if not backtrade_[j]:
                    backtrade_[j] = [i]
                else:
                    backtrade_[j].append(i)

                # nbars indicator
                if not backnbars_[j]:
                    backnbars_[j] = [i]
                else:
                    backnbars_[j].append(i)

    # default behavior
    else:
        self.log.debug("default loop exit")
        for i in range(N):
            if entryorderseries[i]:
                targetprice = operandmode(entrypriceseries[i], amount, l)
                # print("enter trade at ", i, entrypriceseries[i])
                for j in range(i + 1 + validFrom, max(i + 1 + validTo, N)):
                    if cmp(targetprice, exitohlcseries[j]):
                        exitorderseries[j] = True
                        exitpriceseries[j] = maxmin_with_open(targetprice, ohlc.open[j])
                        # print("close trade at ", j, targetprice)
                        # enable backtrade for multi orders
                        #
                        if not backtrade_[j]:
                            backtrade_[j] = [i]
                        else:
                            backtrade_[j].append(i)

                        break
}