.onUnload <- function(libpath) {
  library.dynam.unload("rbacktester", libpath)
}

.onLoad <- function(lib, pkg) {
    if(!exists('.strategy'))
      .strategy <<- new.env()
}