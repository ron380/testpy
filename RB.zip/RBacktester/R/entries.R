# function returning two vectors

#' @export 
EntriesMethods <- new.env()

EntriesMethods$pullback_signal1 <- function(ohlcv, ...) {

    BuySignal <- ohlcv$high < shift(ohlcv$high)
    ShortSignal <- ohlcv$low > shift(ohlcv$low)

    list(BuySignal=BuySignal, ShortSignal=ShortSignal)
}


EntriesMethods$pullback_signal2 <-function(ohlcv, ...) {

    BuySignal = ohlcv$high < shift(ohlcv$high) & shift(ohlcv$close) < shift(ohlcv$open)
    ShortSignal = ohlcv$low > shift(ohlcv$low) & shift(ohlcv$close) > shift(ohlcv$open)

    list(BuySignal=BuySignal, ShortSignal=ShortSignal)
}


# EntriesMethods$pullback_signal3 <- function(ohlcv, ...) {

#     extra_params <- list(...)
#     NBars <- ifelse(is.null(extra_params$NBars), 3, extra_params$NBars)

#     extract.named(EntriesMethods$pullback_signal2(ohlcv))
#     BuySignal <- ta.barsince(BuySignal).between(1, NBars)
#     ShortSignal <- ta.barsince(ShortSignal).between(1, NBars)
#     # clear it to the first signal

#     list(BuySignal=BuySignal, ShortSignal=ShortSignal)
# }
    
momentum_signal1 <- function(ohlcv, ...) {
    dir_attr <- "dir"
    # tibble allows acces using double brackets
    BuySignal <- ohlcv[[dir_attr]] > 0 & shift(ohlcv[[dir_attr]], 2) > 0 & 
                ohlcv$high > shift(ohlcv$high, 2) & ohlcv$close > shift(ohlcv$open, 2) & ohlcv$low > shift(ohlcv$low, 2)
    ShortSignal <- ohlcv[[dir_attr]] < 0 & shift(ohlcv[[dir_attr]], 2) < 0 & 
                ohlcv$high < shift(ohlcv$high, 2) & ohlcv$close < shift(ohlcv$open, 2) & ohlcv$low < shift(ohlcv$low, 2)

    list(BuySignal=BuySignal, ShortSignal=ShortSignal)
}


EntriesMethods$pullback_signal4 <- function(ohlcv, ...) {

    BuySignal = ohlcv$low < shift(ohlcv$low) & ohlcv$close > ohlcv$open
    ShortSignal = ohlcv$high > shift(ohlcv$high) & ohlcv$close < ohlcv$open

    list(BuySignal=BuySignal, ShortSignal=ShortSignal)
}

EntriesMethods$pivot_signal0 <- function(ohlcv, ...) {

    BuySignal <- ohlcv$low < shift(ohlcv$low, 1) & ohlcv$low < shift(ohlcv$low, 2) & ohlcv$low < shift(ohlcv$low, 3)
    ShortSignal <- ohlcv$high > shift(ohlcv$high, 1) & ohlcv$high > shift(ohlcv$low$high, 2) & ohlcv$high > shift(ohlcv$high, 3)

    list(BuySignal=BuySignal, ShortSignal=ShortSignal)
}


    # @classmethod
    # def pivot_signal1(cls, ohlcv: DataFrame, **fit_params):
    #     BuySignal, ShortSignal = EntryMethods.pivot_signal0(ohlcv)
    #     BuySignal &= ohlcv$close > ohlcv$open
    #     ShortSignal &= ohlcv$close < ohlcv$open

    #     return BuySignal, ShortSignal

    # @classmethod
    # def pivot_signal2(cls, ohlcv: DataFrame, **fit_params):
    #     BuySignal, ShortSignal = EntryMethods.pivot_signal0(ohlcv)
    #     BuySignal &= (ohlcv$close < ohlcv$open) & (ohlcv$low < ohlcv$low.shift(-1))
    #     ShortSignal &= (ohlcv$close > ohlcv$open) & (ohlcv$high < ohlcv$low.shift(-1))

    #     return BuySignal, ShortSignal

    # @classmethod
    # def pivot_signal3(cls, ohlcv: DataFrame, **fit_params):
    #     BuySignal, ShortSignal = EntryMethods.pivot_signal0(ohlcv)
    #     BuySignal1 = BuySignal & (ohlcv$close > ohlcv$open)
    #     ShortSignal1 = ShortSignal & (ohlcv$close < ohlcv$open)

    #     BuySignal2 = BuySignal & (ohlcv$close < ohlcv$open) & (ohlcv$low < ohlcv$low.shift(-1))
    #     ShortSignal2 = ShortSignal & (ohlcv$close > ohlcv$open) & (ohlcv$high < ohlcv$low.shift(-1))

    #     BuySignal = BuySignal1 & BuySignal2
    #     ShortSignal = ShortSignal1 & ShortSignal2
    #     return BuySignal, ShortSignal
