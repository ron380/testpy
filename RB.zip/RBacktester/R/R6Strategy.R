
# borrow ideas from package quantstrat (strategy.R )

#' test to see if object is of type 'strategy'
#' @param x object to be tested
#' @export
is.strategy <- function(x) {
    inherits( x, "strategy" )
}


#' retrieve strategy from the container environment
#' @param x string name of object to be retrieved
#' @param envir the environment to retrieve the strategy object from, defaults to .strategy
#' @rdname get.strategy
#' @aliases
#' get.strategy
#' getStrategy
#' @export get.strategy
#' @export getStrategy
get.strategy <- getStrategy <- function(x, envir=.strategy){
    tmp_strat<-get(as.character(x), pos=envir, inherits=TRUE)
    if( inherits(tmp_strat,"try-error") | !is.strategy(tmp_strat) ) {
        warning(paste("Strategy", x, " not found, please create it first."))
        return(FALSE)
    } else {
        if(is.strategy(tmp_strat)) return(tmp_strat) else return(NULL)
    }
}


#' put a strategy object in .strategy env
#' @param strategy object; name will be extracted as strategy$name
#' @param envir the environment to store the strategy in, defaults to .strategy
#' @seealso getStrategy
#' @export
put.strategy <- function(strategy, envir = .strategy)
{
    assign(strategy$name, strategy, envir=as.environment(envir))
}

#' load a strategy object from disk into memory
#' @param strategy_name a string specifying the name of the strategy object; may also be used to create a file name
#' @param file string specifying the filename to use, if NULL, a default will be created
#' @export
load.strategy <- function(strategy_name, file = NULL)
{
    if (is.null(file)) 
        file <- paste(strategy_name, 'RData', sep = ".")

    load(file=file, envir = .strategy)
    assign(strategy_name, .strategy$strategy, envir = .strategy)
    rm("strategy", envir = .strategy)
    invisible(strategy)
}

#' save a strategy object from memory onto disk
#' @param strategy_name a string specifying the name of the strategy object; may also be used to create a file name
#' @param file string specifying the filename to use, if NULL, a default will be created
#' @export
save.strategy <- function(strategy_name, file = NULL)
{
    strategy <- getStrategy(as.character(strategy_name))
    if (is.null(file))
        file <- paste(strategy_name, 'RData', sep=".")

    save(strategy, file=file)
}


#' R6Strategy  R6 class
#'
#' A simple R6 class for demonstration purposes.
#'
# will return an abstract class since fit is not given and preprocess postprocess do nothing
# @importFrom ooplah AbstractClass
#' @export
R6Strategy <- R6Class("R6Strategy",
    # stores classes of the vectors: orders, prices, tracks
    private = list(
        orders = list(buy = NA, sell = NA, short = NA, cover = NA, buyintent = NA, shortintent = NA),
        prices = list(buyprice = NA, sellprice = NA, shortprice = NA, coverprice = NA, buyintentprice = NA, shortintentprice = NA),
        tracks = list(backtrade = NA,  barsbackintent = NA, backnbars = NA),
        trades = list(equity = NA, trade = NA, tradepct = NA, tradetarget = NA, tradetargetpct = NA),
        # for length checks move to active method
        len_ = NULL        
    ),
    active = list(

        len = function() {
            self$log_entry("len")
            if (is.null(private$len_)) {                
                if (!allNA(private$orders$buy))
                    private$len_ <- length(private$orders$buy)
                else if (!allNA(private$orders$short))
                    private$len_ <- length(private$orders$short)
                else {
                   stop("invaliid buy/short arrays.")
                }
            }
            self$log_exit("len")
            return (private$len_)
        },
        # handlers to the container
        Buy = function(value) {
            if (missing(value)) private$orders$buy
            else {
                private$orders$buy <- value
                # do we want to make length check?
                # if (is.na(private$len)) private$len <- length(value)
                self
            }
        },
        BuyIntent = function(value) {
            if (missing(value)) private$orders$buyintent
            else {
                private$orders$buyintent <- value
                self
            }
        },
        Sell = function(value) {
            if (missing(value)) private$orders$sell
            else {
                private$orders$sell <- value
                self
            }
        },
        Short = function(value) {
            if (missing(value)) private$orders$short
            else {
                private$orders$short <- value
                self
            }
        },
        ShortIntent = function(value) {
            if (missing(value)) private$orders$shortintent
            else {
                private$orders$shortintent <- value
                self
            }
        },
        Cover = function(value) {
            if (missing(value)) private$orders$cover
            else {
                private$orders$cover <- value
                self
            }
        },
        BuyPrice = function(value) {
            if (missing(value)) private$prices$buyprice
            else {
                private$prices$buyprice <- value                
                self
            }
        },
        BuyIntentPrice = function(value) {
            if (missing(value)) private$prices$buyintentprice
            else {
                private$prices$buyprice <- value                
                self
            }
        },
        SellPrice = function(value) {
            if (missing(value)) private$prices$sellprice
            else {
                private$prices$sellprice <- value
                self
            }
        },
        ShortPrice = function(value) {
            if (missing(value)) private$prices$shortprice
            else {
                private$prices$shortprice <- value
                self
            }
        },
        ShortIntentPrice = function(value) {
            if (missing(value)) private$prices$shortintentprice
            else {
                private$prices$shortintentprice <- value
                self
            }
        },
        CoverPrice = function(value) {
            if (missing(value)) private$prices$coverprice
            else {
                private$prices$coverprice <- value
                self
            }
        },
        BarsBackIntent = function(value) {
            if (missing(value)) private$tracks$barsbackintent
            else {
                private$tracks$barsbackintent <- value
                self
            }
        },
        BackNBars = function(value) {
            if (missing(value)) private$tracks$backnbars
            else {
                private$tracks$backnbars <- value
                self
            }
        },
        BackTrade = function(value) {
            if (missing(value)) private$tracks$backtrade
            else {
                private$tracks$backtrade <- value
                self
            }
        }


    ),
    public = list(
        # add the fields of the class definition
        drawdownmode = NULL,
        tradedirection = NULL,
        ticksize = NULL,
        debug = TRUE,
        logger = NULL,

        # getters for private fields
        get_orders = function() { private$orders },
        get_prices = function() { private$prices },
        get_tracks = function() { private$tracks },
        
        log_entry = function(method_name) {
            self$logger$info(paste0("Entering ", method_name, "()..."))
        },
        log_exit = function(method_name) {
            self$logger$info(paste0("Exiting ", method_name, "()..."))
        },

        # constructor with properties and defaults
        initialize = function(
            drawdownmode = DrawDownMode$drawdownAtClose,
            tradedirection = TradeDirection$tradeDirectionBoth,
            tradefraction = FALSE,
            maxtrades = NULL,
            copy = FALSE,
            ticksize = TickSize$STOCK) {
                # checks
                stopifnot(drawdownmode %in% DrawDownMode)
                stopifnot(tradedirection %in% TradeDirection)
                stopifnot(ticksize %in% TickSize)

                self$drawdownmode <- drawdownmode
                self$tradedirection <- tradedirection
                self$ticksize <- ticksize

                # logger                
                self$logger <- lgr::get_logger_glue("glue/logger")
                self$logger$set_threshold("debug")
                # self$logger$add_appender(lgr::appender_console(linenums = TRUE))
                # self$logger$add_appender(appender_console())
                invisible(self)
        },
        # Sets trade delays applied by the backtester.
        # This function allows you to override trade delays from the "Settings" page.
        # It is important do understand what trade delays really do. They in fact internally apply the
        # following:

        # Buy = Ref( Buy, -buydelay );
        # Sell = Ref( Sell, -selldelay );
        # Short = Ref( Short, -shortdelay );
        # Cover = Ref( Cover, -coverdelay );
        # inside backtester after your formula is executed but before backtester starts trade simulation.
        # It is functionally equivalent to having above 4 lines at the end of your formula. Note that NO OTHER variables are affected by trade delays, therefore for example if your position sizing depends on values found in buy/sell/short/cover variables *and* if you are using non-zero trade delays you need to account for that in your code.
        # EXAMPLE	settradedelays( 1, 1, 1, 1 )

        # :param selldelay:
        # :param shortdelay:
        # :param coverdelay:
        # :return:    
        set_tradedelays = function(buydelay = 0L, selldelay = 0L, shortdelay = 0L, coverdelay = 0L) {
        
            self$log_entry("set_tradedelays")
            stopifnot(is.integer(buydelay), is.integer(selldelay), is.integer(shortdelay), is.integer(coverdelay))

            # is.vector is TRUE for list() and and c() ?
            # is.atomic is check for vector
            if (buydelay & is.atomic(private$orders$buy))
                strategy$orders$buy <- shift(private$orders$buy, buydelay, FALSE)
            if (selldelay & is.atomic(private$orders$sell))
                private$orders$sell <- shift(private$orders$sell, selldelay, FALSE)
            if (shortdelay & is.atomic(private$orders$short))
                private$orders$short <- shift(private$orders$short, shortdelay, FALSE)
            if (coverdelay & is.atomic(private$orders$cover))
                private$orders$cover <- shift(private$orders$cover, coverdelay, FALSE)
            
            self$log_exit("set_tradedelays")
            invisible(self)
        },
        set_tradedirection = function(tradedirection) {
            stopifnot(tradedirection %in% TradeDirection) 
            self$tradedirection = tradedirection
        },
        set_tradeordermode = function(ohlc, mode = NULL, 
                            buymode = OrderMode$orderThisBarClose,
                            sellmode = OrderMode$orderThisBarClose,
                            shortmode = OrderMode$orderThisBarClose,
                            covermode = OrderMode$orderThisBarClose) {
        
            self$log_entry("set_tradeordermode")
            # this function allows you to enter all trade in market
            # thisbarclose
            # nextbaropen

            # allows individual setting as well            

            # stopifnot( !(is.na(self$Buy) && is.na(self$Short)), "`set_tradeordermode`` must be applied after buy/short orders definitions")
            
            if (!is.null(mode)) {
                if (mode %in% OrderMode) {
                    # not null mode, need to set globally all modes
                    buymode = sellmode = shortmode = covermode = mode
                }
                else {
                   stop("mode not in OrderMode enum")
                }
            }

            tabmode = list(buymode=buymode, sellmode=sellmode, shortmode=shortmode, covermode=covermode)

            # loop over tabmode is aligned with prices list 
            for (i in seq_along(tabmode)) {
                if (tabmode[[i]] == OrderMode$orderThisBarClose)
                {
                    private$prices[[i]] <- ohlc$close
                    self$BarsBackIntent <- 0
                }
                else if (tabmode[[i]] == OrderMode$orderNextBarOpen) {
                    private$prices[[i]] <- ohlc$open
                    private$orders[[i]] <- if (!is.na(private$orders[[i]])) shift(private$orders[[i]], 1)
                    self$BarsBackIntent <- 1
                }                

            }
            self$log_exit("set_tradeordermode")
        },
        # methods applied on object
        apply_intent = function(ohlc, mode=OrderMode$orderBarPrice, ...) {
        
            self$log_entry("apply_intent")
            # handle the default values
            valid_to <- 3L
            # assign the additional parameters as variables in the current function scope
            params=list(...)
            for (name in names(params) ) {
                assign(name, params[[name]])
            }

            # internal function
            apply_intent_signal <- function(buyshort=c("buy", "short"), validFrom=0L, validTo=-1L) {
        
                # transform buy sell intent arrays to buy arrays

                # ValidFrom -
                #     defines first bar since intent entry when order can generate an exit.
                #     0 means from the very beginning

                # ValidTo -
                #     defines last bar since intent entry when orde can generate an exit.
                #     -1 means "infinite". By default stops are valid all the time (0/-1).


                # :return:
            
                stopifnot(is.integer(validFrom), is.integer(validTo))
                stopifnot(validTo > validFrom || validTo == -1, glue("validFrom {validFrom}, validTo: {validTo}"))
                match.arg(buyshort)
                # stopbuyshort == 'buy' | buyshort == 'short', f"buy/short {buyshort}"


                # based on buy sell indicator in the function (string)
                # o <- buyshort
                order_str <- buyshort
                # using quantmod standards
                if (order_str == 'buy') {
                    cmp <- operator.ge
                    epr <- hlc$high
                }
                else {
                    cmp <- operator.le
                    epr <- ohlc$low
                }

                # order_str <- o
                orderprice_str <- paste0(o, "price")
                orderintent_str <- paste0(o, "intent")
                orderpriceintent_str <- paste0(o, "price", "intent")

                # handle for the setters since we want full series constructor
                # order_setter = _bttable_setter[f'{o}']
                # orderprice_setter = _bttable_setter[f'{o}price']

                # # set the pointers (not working)
                # order <- strategy$orders[order_str]
                # orderprice <- strategy$prices[orderprice_str]

                # use the getter to obtain the series buy/short intent
                orderintent <- private$orders[[orderintent_str]]
                orderpriceintent <- private$prices[[orderpriceintent_str]]


                N = length(orderintent)
                # validTo = validTo if validTo != -1 else N
                validTo <- ifelse(validTo != -1L, validTo, N)

                if (mode == OrderMode$orderDisable) {
                    return(NULL)
                }
                else if (mode == OrderMode$orderThisBarClose) {
                        
                    # copy orderintent to order
                    private$orders[[order_str]] <- c(orderintent)

                    # bttable[f'{o}price'][bttable[f'{o}'] == 1] = ohlc['close'][bttable[f'{o}'] == 1]
                    ### bttable_setter[f'{o}price'](ohlc.close.copy())

                    # orderprice_setter(ohlc.close.copy())
                    private$prices[[orderprice_str]] <- ohlc$close
                    # NEW: write the intent location (bars back from the order taken place)
                    private$tracks$barsbackintent <- 0L  # Series(0, index=orderintent.index, dtype='Int8')
                }
                else if (mode == OrderMode$orderNextBarOpen) {
                    ### bttable_setter[f'{o}'](
                    ###     bttable[f'{o}intent'].shift(1, fill_value=False))  # for each bttable['intentbuy].shift()
                    private$orders[[order_str]] <- shift(orderintent, 1, fill_value=F)
                    private$prices[[orderprice_str]] <- ohlc$open
                    private$tracks$barsbackintent <- 1L # Series(1, index=orderintent.index, dtype='Int8')
                }
                else if (mode == OrderMode$orderBarPrice) {
                    # allocate 
                    private$tracks$barsbackintent <- empty.vector_like(orderintent)
                    for (i in 1:N) {
                        if (orderintent[i]) {
                            # find from next bar the entry for example in [i+1, i+2)

                            for ( j in (i + 1 + validFrom):(max(i + 1 + validTo, N)) )
                                if ( cmp(epr[j], orderpriceintent[j]) ) {
                                    # _bttable[f'{o}']()[j] = TRUE
                                    # _bttable[f'{o}price']()[j] = orderpriceintent[j]
                                    private$orders[[order_str]][j] <- TRUE
                                    private$prices[[orderprice_str]][j] <- orderpriceintent[i]
                                    # distance from order to intent
                                    private$tracks$barsbackintent[j] <- j - i
                                }
                        }
                    }
                } 
                
            
            } # end internal function

            # execute the internal functions
            apply_intent_signal(mode, "buy", validTo=valid_to)
            apply_intent_signal(mode, "short", validTo=valid_to)
            self$log_exit("apply_intent")
            invisible(self)
        },

        # stop and reverse
        stop_and_reverse = function() {

            # if (TradeDirection$tradeDirectionBoth %in% strategy$tradedirection) {
            # if TradeDirection.tradeDirectionBoth in self.tradedirection and \
            #         (self.Cover is None or not self.Cover.any()):

            print("copying Short and Cover")
        
            # sophisticated sapplystop must be applied in postproessing since
            # we cannot copy the sell->short and cover->buy
            private$orders$cover = c(private$orders$buy)
            # self.strategy.CoverPrice = self.strategy.BuyPrice.copy()
            private$orders$short = c(private$orders$sell)
            # self.strategy.ShortPrice = self.strategy.SellPrice.copy()

            # what to do with copying shortprice and coverprice?

            
            # first fix the first trade issued by finding the first valid index
            # we will clear the exits sell and cover for the stop and reverse method
            idx_buy <- first_nz(private$orders$buy)
            idx_short <- first_nz(private$orders$short)
            print(idx_buy, idx_short)
            if (idx_buy < idx_short)
                private$orders$cover[idx_buy] <- FALSE
            else if (idx_short < idx_buy)
                private$orders$sell[idx_short] <- FALSE
            
            invisible(self)
        },
        # apply stop function
        apply_stop = function(ohlc, type, mode, amount, exitatstop=NA, volatile=FALSE, validFrom= 0, validTo= -1) {
            self$log_entry("apply_stop")
            stopifnot(type %in% StopType)
            stopifnot(mode %in% StopMode)
            # type - StopType
            # mode - StopMode

            N <- self$len
            self$logger$debug("apply_stop: N = {N}")

            #
            # internal apply stop implementation
            #
            apply_stop_ <- function(buyshort = c("buy", "short")) {
                self$log_entry("apply_stop_")
                # stopifnot(type %in% StopType, mode %in% StopMode)
                buyshort <- match.arg(buyshort)
                
                # based on buysell string we get control of the entry and the exit name arrays
                o <- buyshort  # order
                e <- ifelse(o == "buy", "sell", "cover") # exit
            
                # ticksize
                ticksize <- self$ticksize

                # handle operation for a given price point p dollar or percentage
                # l is a direction +1 for long, -1 for short
                # p - current price,
                # a - amount increase in dollars or percent,
                # l - direction (long/short)
                op_point <- function(p, a, l) p - l * a * ticksize
                op_percent <- function(p, a, l) p * (1 - l * a / 100)

                # set the operandmode using the above lambdas: op_point or op_percent
                if (mode == StopMode$stopModeDisable) {
                    return (invisible(self))
                } else if (mode == StopMode$stopModePoint) {
                    operandmode <- op_point
                }
                else if (mode == StopMode$stopModePercent) {
                    operandmode <- op_percent
                }


                # l - long/short,
                # exitprice - exitprice,
                # mopen - operator for open (in case there is a gap)
                if ((type == StopType$stopTypeLoss && o == 'buy') || (type == StopType$stopTypeProfit && o == 'short')) {
                    cmp <- operator.ge
                    l <- 1L
                    exitohlcseries <- ohlc$low
                    maxmin_with_open <- min
                }
                else if ((type == StopType$stopTypeLoss && o == 'short') || (type == StopType$stopTypeProfit && o == 'buy')) {
                    cmp <- operator.le
                    l <- -1L
                    exitohlcseries <- ohlc$high
                    maxmin_with_open <- max
                }
                # handle trailing stop for buy and short
                else if (type %in% c(StopType$stopTypeTrailing | StopType$stopTypeTrailingHL) && o == 'buy') {
                    entryprice <- ifelse(type == StopType$stopTypeTrailingHL, ohlc$high, ohlc$close)
                    cmp <- operator.ge
                    l <- 1L
                    exitohlcseries <- ohlc.low.values
                    maxmin_with_open <= min
                }
                else if (type %in% c(StopType$stopTypeTrailing, StopType$stopTypeTrailingHL) && o == 'short') {
                    # entryprice <- ohlc.low if type == StopType$stopTypeTrailingHL else ohlc.close
                    entryprice <- ifelse(type == StopType$stopTypeTrailingHL, ohlc$low, ohlc$close)
                    cmp <- operator.le
                    l <- -1L
                    exitohlcseries <- ohlc.high.values
                    maxmin_with_open <- max
                }
            
            
                # main applystop_ internal
                # entry order/price and exit order/price
                # however in R there is no update of a vector by reference
                # so we need to override in the end
                
                # copy and not references
                entryorderseries <- private$orders[[o]]
                entrypriceseries <- private$prices[[paste0(o, "price")]]
                
                self$logger$debug("entryorderseries") # = {entryorderseries}")
                # cat(entryorderseries, "\n")
                # exitorderseries <- private$orders[[e]]                
                # exitpriceseries <- private$prices[[paste0(e, "price")]]

                # N <- length(entryorderseries)

                # initialize the exit order series and price
                # then copy the result back to class
                N <- length(entryorderseries)
                # exitorderseries <- logical(N)
                # exitpriceseries <- rep(NA, N)
                # get from class
                exitorderseries <- private$orders[[e]]
                exitpriceseries <- private$prices[[paste0(e, "price")]]


                # backtrade - stores the origin of the trade (where the buy was found) once an exit occurs
                # then we know from different exits attached to a trade which occurs first
                # first check if not initialized and then get the data from the series
                # it is vector of list
                # if self$BackTrade is None:
                #     # self.log.debug("initialize backtrade and set to point by self.backtrade")
                #     # some ways tried to init backtrade:
                #     # self.backtrade = Series(None, index=entryorderseries.index)
                #     # backtrade_ = np.array([None] * N)
                #     # backtrade_ = [None] * N
                #     # incorrect way:
                #     # backtrade_ = [[]] * N # not working as it the same list in the array

                #     # this is the current correct way since we initialize a new list for every row
                #     # backtrade = [[] for i in range(N)]
                #     backtrade_ = [None] * N
                #     # backtrade will create list on the fly, but we need a new list at each slot
                #     # for i in range(N):
                #     #     backtrade_[i] = list()
                #     # copy=False is not working

                #     # wrapup by Series
                #     self.BackTrade = Series(backtrade_, index=entryorderseries.index, copy=False)

                # stores the number of bars back for the originator/intent of the trade
                # if self.BackNBars is None:
                #     backnbars_ = [None] * N
                #     self.BackNBars = Series(backnbars_, index=entryorderseries.index)

                # access by ref to the array pointed by backtrade series
                # in R no references
                backtrade_ <- self$BackTrade
                backnbars_ <- self$BackNBars

                NN <- N
                # project: use std.vector to mark the elements
                if (type %in% c(StopType$stopTypeTrailing, StopType$stopTypeTrailingHL)) {
                    self$logger$debug("trailing stop")
                    # trailing stop
                    for (i in 1:N) {
                        if (safe_true(entryorderseries[i])) {
                            for (j in (i + 1 + validFrom):(max(i + 1 + validTo, N))) {
                                targetprice <- operandmode(entryprice[j - 1], amount, l)
                                if (cmp(targetprice, exitohlcseries[j])) {
                                    exitorderseries[j] <- TRUE
                                    exitpriceseries[j] <- targetprice
                                    # update the origin of the trades
                                    backtrade_[j] <- ifelse(is.na(backtrade_[j]), c(i), c(backtrade_[j], i))

                                    break # th j loop
                                }
                            }
                        }
                    }
                }
                # nbars exit at close ( enable a feature for open of next bar? )
                else if (type == StopType$stopTypeNBar) {
                    self$logger$debug("stop nbar")
                    for (i in 1:(N - amount)) {
                        if (safe_true(entryorderseries[i])) {
                            # use j = i + amount
                            j <- i + amount
                            exitorderseries[j] <- TRUE
                            exitpriceseries[j] <- ohlc$close[j]

                            # backtrade indicator (trick is append to list)
                            backtrade_[j] <- ifelse(is.na(backtrade_[j]), c(i), c(backtrade_[j], i))

                            # nbars indicator
                            backnbars_[j] <- ifelse(is.na(backnbars_[j]), c(i), c(backnbars_[j], i))
                        }
                    }
                }
                # default behavior
                else {
                    self$logger$debug("default stop percent")
                    # self.log.debug("default loop exit")
                    for (i in 1:N) {
                        if (safe_true(entryorderseries[i])) {
                            targetprice <- operandmode(entrypriceseries[i], amount, l)
                            # print("enter trade at ", i, entrypriceseries[i])
                            for (j in (i + 1 + validFrom):max(i + 1 + validTo, N)) {
                                if (cmp(targetprice, exitohlcseries[j])) {
                                    exitorderseries[j] <- TRUE
                                    exitpriceseries[j] <- maxmin_with_open(targetprice, ohlc$open[j])
                                    # print("close trade at ", j, targetprice)
                                    # enable backtrade for multi orders
                                    #
                                    backtrade_[j] <- ifelse(backtrade_[j], c(i), c(backtrade_[j], i))
                                }
                            }
                        }
                    }
                }
            
                # override the class fields
                private$orders[[e]] <- exitorderseries
                private$prices[[paste0(e, "price")]] <- exitpriceseries
                # self$BackTrade <- backtrade_
                # self$BackNBars <- backnbars_

            }


            # enable stop and reverse, we copy the sell->short for reverse
            if (self$tradedirection == TradeDirection$tradeDirectionBoth) {
                print(">> tradedirection = ", self.tradedirection)
                print(">> add stop and reverse")
                # fix the Short/Cover
                self$stop_and_reverse()
            }

            # activate each _applystop seprately for the buy mode and for the sell mode
            if (TradeDirection$tradeDirectionLong %in% self$tradedirection) {
                # check we have allocated a sell array
                N = self$len
                self$logger$debug("N = {N}")
                cat(private$orders$sell, "\n")
                cat(private$prices$sellprice, "\n")
                if (is.na(private$orders$sell))
                    private$orders$sell <- logical(N) # which default to FALSE or rep(F, N)                                    
                if (is.na(private$prices$sellprice))
                    private$prices$sellprice <- rep(NA, N)
                
                # exitpriceseries <- rep(NA, N)

                
                # call internal apply stop
                # apply_stop_(ohlc, type, mode, "buy", amount, exitatstop=exitatstop, volatile=volatile, validFrom=validFrom, validTo=validTo)
                apply_stop_("buy")
            }
            if (TradeDirection$tradeDirectionShort %in% self$tradedirection) {
                # check we have sell array
                N = self$len

                if (is.na(self$orders$cover))
                    private$orders$cover = logical(N)
                if (is.na(private$prices$coverprice))
                    private$prices$coverprice <- rep(NA, N)
                

                # apply_stop_(ohlc, type, mode, "short", amount, exitatstop=exitatstop, volatile=volatile, validFrom=validFrom, validTo=validTo)
                apply_stop_("short")
            }
            self$log_exit("apply stop")
        }, # applystop function end
        equity = function(ohlc, initialequity=1000) {

            # drawdown_extreme controls how drawdown is interpreted at each bar
            drawdown_extreme <- ifelse(self$drawdownmode == DrawDownMode$drawdownExtremes, TRUE, FALSE)

            buy_drawdown <- function(i) ifelse(drawdown_extreme, ohlc$low[i], ohlc$close[i])
            short_drawdown <- function(i) ifelse(drawdown_extreme, ohlc$high[i], ohlc$close[i])
            buyentry_drawdown <- function(i) ifelse(drawdown_extreme && ohlc$close[i] <= ohlc$open[i], ohlc$low[i], ohlc$close[i])
            shortentry_drawdown <- function(i) ifelse(drawdown_extreme && ohlc$close[i] >= ohlc$open[i], ohlc$high[i], ohlc$close[i])

            N <- private$len

            # initialize equity_[0] with the given initial capital and is updated at each timestamp
            equity_ <- empty_vector(N)
            equity_[0] = initialequity
            # trade list (generated at the close of the trade)
            trade_ <- empty_vector_NA(N)
            tradepct_ <- empty_vector_NA(N)

            # trade list (generated at the beginning of the trade and is used in supervised ML)
            tradetarget_ <- empty_vector_NA(N)
            tradetargetpct_ <- empty_vector_NA(N)

            datetime_idx <- as.Date(ohlc$date)
            start_idx <- 1
            stop_idx <- N

            i <- start_idx

            while (i <= stop_idx) {

                # copy equity line
                if (i > 1 && equity_[i] == 0)
                    equity_[i] <- equity_[i - 1]

                if (private$orders$buy[i] && is_long_) {  # active long starts at i
                    entryprice <- private$prices$buyprice[i]
                    # lots_size <- trd_size__(buyprice_[i])
                    lots_size <- as.integer(equity_[i] / entryprice)
                    # lots_size <- 1

                    if (self$debug)
                        print(glue("{i}/{datetime_idx[i]} buy at {entryprice}, lots: {lots_size}"))

                    # evaluate the equity at the entry day with possible having a buyentry drawdown
                    equity_[i] <- equity_[i] + lots_size * (buyentry_drawdown(i) - entryprice)  # for the open position

                    # changed to j <- i .. N. what happens if we exit on the same day
                    # previously was i+1 .. N
                    for (j in (i+1):N) {
                        # what happens if sell[j] belongs to buy[i] (sellbuypos)
                        if (private$orders$sell[j]) {
                            # single trade that was closed from position open
                            tradetarget_[i] <- trade_[j] <- lots_size * (sellprice_[j] - entryprice)
                            equity_[j] <- equity_[i] + trade_[j]
                            tradetargetpct_[i] <- tradepct_[j] <- sellprice_[j] / entryprice - 1

                            ##### debug
                            if (self$debug) 
                                print(glue("  {j}/{datetime_idx[j]} sell (close buy) from {entryprice}"))
                            # reset i to j-1
                            if (j > i)
                                i <- j - 1  # can be stop-reverse on the same day
                            break  # sell[j]
                        }
                        else {
                            # for the open position (update the p&l)
                            equity_[j] <- equity_[i] + lots_size * (buy_drawdown(j) - entryprice)
                        }
                    }
                }

                if (private$orders$short[i] && is_short_)  { # active short starts at i
                    entryprice <- shortprice_[i]
                    # lots_size <- trd_size__(shortprice_[i])
                    lots_size <- as.integer(equity_[i] / entryprice)
                    # lots_size <- 1
                    # print(f"{index_[i]} short at {entryprice}, lots: {lots_size}")

                    ##### DEBUG
                    if (self$debug) 
                        print(glue("{i}/{datetime_idx[i]} buy at {entryprice}, lots: {lots_size}"))

                    # handling the short entry day
                    equity_[i] <- equity_[i] + lots_size * (entryprice - shortentry_drawdown(i))  # for the open position

                    for (j in (i + 1):N) {
                        # myequity_[j] += entry_price - ohlc.close[j]  # for the open position
                        if (private$orders$cover[j]) {
                            # single trade that was closed from position open
                            tradetarget_[i] <- trade_[j] <- lots_size * (entryprice - coverprice_[j])
                            equity_[j] <- equity_[i] + trade_[j]
                            tradetargetpct_[i] <- tradepct_[j] <- -coverprice_[j] / entryprice + 1
                            ### return_[j] <- lots_size * (short_drawdown(j-1) - coverprice_[j])
                            ### returnpct_[j] <- -coverprice_[j]/return_[j-1] + 1

                            ##### DEBUG
                            if (self$debug) 
                                print(glue("  {j}/{indexdate[j]} cover (close short) from {entryprice}"))

                            if (j > i)
                                i <- j - 1  # can be stop-reverse on the same day
                            break  # cover_[j]
                        }
                        else {
                            # for the open position (update the p&l)
                            equity_[j] <- equity_[i] + lots_size * (entryprice - short_drawdown(j))
                        }
                    }
                }

                # while (i) loop
                i <- i + 1

            }

            # equity_, trade_, tradetarget_, tradepct_, tradetargetpct_ = _jitrun()
            # check if we want to remove the last open trade?
            private$trades$equity <- equity_
            # at the end of the trade
            private$trades$trade_ <- trade_
            private$trades$tradepct <- tradepct_
            # at the beginning of the trade
            private$trades$tradetarget <- tradetarget_
            private$trades$tradetargetpct <- tradetargetpct_
        }
    ) # public methods
)


as_tibble <- function(strategy, ohlcv) {
    stopifnot(inherits(strategy, "R6Strategy"))
    # we want NA on orders to perform completion for tibble
    as_tibble(ohlcv, strategy$orders)

}