
# create enums and export these
# export this as environment Properties


makeEnum <- function(inputList) {
    myEnum <- as.list(inputList)
    enumNames <- names(myEnum)
    if (is.null(enumNames)) {
        names(myEnum) <- myEnum
    } else if ("" %in% enumNames) {
        stop("The inputList has some but not all names assigned. They must be all assigned or none assigned")
    }
    return(myEnum)
}


#' @export
SymbolType <- makeEnum(
    c(STOCK = 1L,
    INDEX = 2L,
    CONTFUTURE = 3L,
    FUTURE = 4L,
    FOREX = 5L,
    CFD = 6L,
    BOND = 7L)
)

#' @export
TickSize <- list(STOCK=0.01, FUTURE=0.25, FOREX=0.25)


# use symbol table
#' @export
PositionSizeType <- makeEnum(
    c(spsInteger = 0L,  # dollar value of size (as in previous versions)
    spsFraction = 1L  # allow fraction
    )
)

#' @export
PositionSize <- makeEnum(
    c(spsNoChange = 0L,  # don't change previously set size for given bar
    spsValue = 1L,       # dollar value of size (as in previous versions)
    spsPercentOfEquity = 2L,  # size expressed as percent of portfolio-level equity (size must be from ..100 (for
                              # regular accounts or .1000 for margin accounts)
    spsShares = 4,             # size expressed in shares/contracts (size must be > 0 )
    spsPercentOfPosition = 3  # size expressed as percent of currently open position (for SCALING IN and SCALING OUT ONLY)
    )
)

#' @export
DrawDownMode <- makeEnum(
    c(drawdownAtClose = 0L,
    drawdownExtremes = 1L  # set to low for long position and high for short poistion
    )
)

#' @export
CalculationMode <- makeEnum(
    c(calculationRelative = 0L, # stocks
    calculationAdditive = 1L    # futures
    )
)

#' @export
MathRoundingMode <- makeEnum(
    c(roundingDisable = 0L,
    roundingFloor = 1L,
    roundingCeil = 2L,
    roundingRound = 3L
    )
)

# RoundingTableFunc corresponds to position functions 1, 2, and 3
RoundingTableFunc <- c(floor, ceiling, round)

# """
# CommissionMode 
# """
# """
# CommissionAmount - amount of commission in modes 1..3
# """

#' @export
CommissionMode <- makeEnum(
    c(commissionDisable = 0L,  # (0 - use portfolio manager commission table)
    commissionPercent = 1L,    # percent of trade
    commissionValue  = 2L,     # $ per trade
    commissionShares = 3L      # $ per share/contract
    )
)

#' @export
TradeDirection <- makeEnum(
    c(tradeDirectionLong = 1L,
    tradeDirectionShort = 2L,
    tradeDirectionBoth = 3L
    )
)


#' @export
BacktestMode <- makeEnum(
    c(backtestRegular = 0,  # regular, signal-based backtest, redundant signals are removed as shown in this picture
    backtestRegularRaw = 1,  # signal-based backtest, redundant (raw) entry signals are NOT removed, only one position
    # per symbol allowed
    backtestRegularRawMulti = 2,  # signal-based backtest, redundant (raw) entry signals are NOT removed,
    # MULTIPLE positions per symbol will be open if BUY/SHORT signal is true for more than one bar and there are free
    # funds, Sell/Cover exit all open positions on given symbol, Scale-In/Out work on all open positions of given symbol at once.
    # backtestRegularRaw2  = 4    # for custom backtester users only, the same as backtestRegularRaw, but redundant exit
    # # signals are also kept. AVOID this mode - it requires lots of memory and slows everything down.
    # backtestRegularRaw2Multi = 8 # for custom backtester users only, same as backtestRegularRawMulti, but redundant
    # # exit signals are also kept. AVOID this mode - it requires lots of memory and slows everything down.
    backtestStopAndReverse = 8,
    backtestRotational = 16,      # rotational trading system see this.
    backtestLongOnly = 32
    )
)

#' @export
OrderMode <- makeEnum(
    c(orderDisable = 0L,
    orderThisBarClose = 1L,
    orderNextBarOpen = 2L,
    orderBarPrice = 4L  # as defined by intentbuyprice intentsellprice
    )
)


#' @export
IntentModeOffset <- makeEnum(
    c(intModeDisable = 0L,
    intModePercent = 1L,  # defined by intentbuyprice intentsellprice
    intModePercentRange = 2L,  # defined by intentbuyprice intentsellprice
    intModePoint = 3L  # defined by intentbuyprice intentsellprice
    )
)

# class IntentMode(IntEnum):
#     intThisBarClose = 0
#     intNextBarOpen  = 1
#     intNextBarAtPrice = 2 # defined by intentbuyprice intentsellprice


# class StopType(IntEnum):
#     """
#      type =
#         0 = stopTypeLoss - maximum loss stop,
#         1 = stopTypeProfit - profit target stop,
#         2 = stopTypeTrailing - trailing stop,
#         3 = stopTypeNBar - N-bar stop
#     """
#     stopTypeLoss       = 0
#     stopTypeProfit     = 1
#     stopTypeTrailing   = 2
#     stopTypeTrailingHL = 3
#     stopTypeNBar       = 4


# DayOfWeek = dict(Mon=1, Tue=2, Wed=3, Thu=4, Fri=5, Sat=6, Sun=7)

#' @export
DayOfWeek <- setNames(as.list(seq(1, 7)), 
                      c('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'))

#' @export
StopType <- makeEnum(
    # """
    #  type =
    #     0 = stopTypeLoss - maximum loss stop,
    #     1 = stopTypeProfit - profit target stop,
    #     2 = stopTypeTrailing - trailing stop,
    #     3 = stopTypeNBar - N-bar stop
    # """
    c(stopTypeLoss = 1L,
    stopTypeProfit = 2L,
    stopTypeTrailing = 4L,
    stopTypeTrailingHL = 8L,
    stopTypeNBar = 16L,
    stopTypeTime = 32L,
    stopTypeNextProfitableClose = 64L
    )
)

#' @export
StopMode <- makeEnum(
    # """
    # mode =
    # 0 - disable stop (stopModeDisable),
    # 1 - amount in percent (stopModePercent), or number of bars for N-bar stop (stopModeBars),
    # 2 - amount in points (stopModePoint);
    # 3 - amount in percent of profit (risk)
    # """

    c(stopModeDisable = 0L,
    stopModePercent = 1L,
    stopModePoint = 2L,
    stopModeBars = 3L
    )
)

# """
# amount =
# percent/point loss/profit trigger/risk amount.
# This could be a number (static stop level) or an array (dynamic stop level)


# ExitAtStop

# ExitAtStop = 0 - means check stops using only trade price and exit at regular trade price(1)
# (if you are trading on close it means that only close price will be checked for exits and exit will be done at close price)
# ExitAtStop = 1 - check High-Low prices and exit intraday on price equal to stop level on the same bar when stop was triggered
# ExitAtStop = 2 - check High-Low prices but exit NEXT BAR on regular trade price.

# volatile -
# decides if amount (or distance) (3rd parameter) is sampled at the trade entry and remains fixed during the trade (Volatile = FALSE - old behaviour) or if can vary during the trade (Volatile = TRUE) (allows single line Chandelier exit implementation)(2)

# ReEntryDelay -
# how many bars to wait till entering the same stock is allowed.

# ValidFrom -
# defines first bar since entry when stop can generate an exit. 0 means from the very beginning

# ValidTo -
# defines last bar since entry when stop can generate an exit. -1 means "infinite". By default stops are valid all the time (0/-1).

# ValidFrom/ValidTo can be used to create stops that get actived/deactivated in different times. This setting is independent for each stop type. It also works in conjunction with SetOption("HoldMinBars", x ). HoldMinBars affects BOTH regular exits and stops, preventing ALL kind of exits during defined period. ValidFrom/ValidTo works on each stop separately and does not affect regular exits. 

# """
