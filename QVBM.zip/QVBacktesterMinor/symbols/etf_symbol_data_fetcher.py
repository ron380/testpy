from . import symbol_fetcher_registry, BaseSymbolFetcher, Symbol, SymbolType
from typing import List, Tuple
import pandas as pd

pd.options.display.max_columns = 99


@symbol_fetcher_registry.register('spdr_etf')
class SpdrEtfSymbolFetcher(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[str]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks

        """
        data = pd.read_html("https://etfdb.com/etfs/issuers/state-street-spdr/#etfs&sort_name=three_month_average_volume&sort_order=desc")
        table = data[0]

        # save
        table.to_csv('spdr_etf.txt', index=False, sep='|')
        # remove the last row
        df = table.iloc[:-1]
        print("df = ", df)
        convert_dict = {'Avg. Daily Volume': int, 'Symbol': str}
        df = df.astype(convert_dict)
        symbols = df.loc[(df['Avg. Daily Volume'] > 500000), 'Symbol'].tolist()
        return [Symbol(x, SymbolType.STOCK, 'NYSE') for x in symbols]
        # return symbols

