from . import symbol_fetcher_registry, BaseSymbolFetcher, Symbol, SymbolType
from typing import List, Tuple


@symbol_fetcher_registry.register('indices')
class IndicesSymbolFetcher(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[Tuple[str,str]]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks and exchange

        """
        symbols = []

        symbols.append(Symbol('VIX', SymbolType.INDEX, 'CBOE', 'VIX'))
        symbols.append(Symbol('VIX3M', SymbolType.INDEX, 'CBOE', 'VIX 3 Months'))
        symbols.append(Symbol('VIX6M', SymbolType.INDEX, 'CBOE', 'VIX 6 Months'))
        symbols.append(Symbol('VIX9D', SymbolType.INDEX, 'CBOE', 'VIX 9 Days'))
        symbols.append(Symbol('VIX1Y', SymbolType.INDEX, 'CBOE', 'VIX 1 Year'))


        symbols.append(Symbol('CVF', SymbolType.INDEX, 'NYMEX', 'Crude Oil Volatility Index'))
        symbols.append(Symbol('EVZ', SymbolType.INDEX, 'CBOE', 'Euro Volatility Index'))
        symbols.append(Symbol('GVXX', SymbolType.INDEX, 'NYMEX', 'Gold Volatility Index'))
        symbols.append(Symbol('GVZ', SymbolType.INDEX, 'CBOE', 'Gold Volatility Index'))
        symbols.append(Symbol('QVX', SymbolType.INDEX, 'CBOE', 'Crude Oil Volatility Index'))
        symbols.append(Symbol('QQV', SymbolType.INDEX, 'CBOE', 'QQQ Volatility Index'))
        symbols.append(Symbol('VOLQ', SymbolType.INDEX, 'CBOE', 'Nasdaq-100 Volatility Index'))
        symbols.append(Symbol('VRO', SymbolType.INDEX, 'CBOE', 'S&P 500 Volatility Index'))

        # tick and trin
        symbols.append(Symbol('TICK-AMEX', SymbolType.INDEX, 'AMEX', 'Tick Amex'))
        symbols.append(Symbol('TICK-ARCA', SymbolType.INDEX, 'ARCA', 'Tick Arca'))
        symbols.append(Symbol('TICK-NASD', SymbolType.INDEX, 'NASDAQ', 'Tick Nasdaq'))
        symbols.append(Symbol('TICK-NYSE', SymbolType.INDEX, 'NYSE', 'Tick Nyse'))

        symbols.append(Symbol('TRIN-AMEX', SymbolType.INDEX, 'AMEX', 'Tick Amex'))
        symbols.append(Symbol('TRIN-ARCA', SymbolType.INDEX, 'ARCA', 'Tick Arca'))
        symbols.append(Symbol('TRIN-NASD', SymbolType.INDEX, 'NASDAQ', 'Tick Nasdaq'))
        symbols.append(Symbol('TRIN-NYSE', SymbolType.INDEX, 'NYSE', 'Tick Nyse'))

        # advance decline


        # # Dollar
        # symbols.append(Symbol('USD', 'GLOBEX', 'US Dollar Index'))
        #
        # # S&P
        # symbols.append(Symbol('SPX', 'CBOE', 'S^P Index'))
        # symbols.append(Symbol('VIF', 'CBOE', 'Vix Far Term Index'))
        # symbols.append(Symbol('VIN', 'CBOE', 'Vix Near Term Index'))
        #
        #
        # # Nasdaq
        # symbols.append(Symbol('NDX', 'NASDAQ'))
        #
        # # Russell
        # symbols.append(Symbol('RUA', 'RUSSELL', '')) #
        # symbols.append(Symbol('RAV', 'RUSSELL', 'Russell 3000 Value Index'))


        return symbols
