import pandas as pd

from symbols import symbol_fetcher_registry, path
from .base_symbol_fetcher import BaseSymbolFetcher, Symbol, SymbolType
from typing import List


@symbol_fetcher_registry.register('vix')
class VixSymbolFetcher(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[Symbol]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks and exchange

        """
        vxx_symbols = pd.read_csv(path + "/vxx_symbols.txt", comment="#")

        symbols = [Symbol(row.symbol, SymbolType[row.symbol_type], row.exchange, row.description)
                        for row in vxx_symbols.itertuples(index=False)]

        # old stuff moved to external table
        # # Indices
        # symbols.append(Symbol('VIX', SymbolType.INDEX, 'CBOE', 'VIX'))
        # symbols.append(Symbol('VIX3M', SymbolType.INDEX, 'CBOE', 'VIX 3 Months'))
        # symbols.append(Symbol('VIX6M', SymbolType.INDEX, 'CBOE', 'VIX 6 Months'))
        # symbols.append(Symbol('VIX9D', SymbolType.INDEX, 'CBOE', 'VIX 9 Days'))
        # symbols.append(Symbol('VIX1Y', SymbolType.INDEX, 'CBOE', 'VIX 1 Year'))
        # symbols.append(Symbol('VM', SymbolType.INDEX, 'CBOE', 'Mini VIX Index'))
        #
        # # ETF
        # symbols.append(Symbol('VXX', SymbolType.STOCK, 'SMART', 'Etf'))
        # symbols.append(Symbol('UVXY', SymbolType.STOCK, 'SMART', 'Etf Ultra'))
        # symbols.append(Symbol('SVXY', SymbolType.STOCK, 'SMART', 'Etf Ultra'))
        #
        # # Futures
        # symbols.append(Symbol('VXM', SymbolType.CONTFUTURE, 'SMART'))

        return symbols
