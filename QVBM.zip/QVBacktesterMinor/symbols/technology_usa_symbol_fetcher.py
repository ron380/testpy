# from symbols import symbol_fetcher_registry, path
from  symbols import *
# from .base_symbol_fetcher import BaseSymbolFetcher, Symbol, SymbolType
from typing import List
from pandas import read_csv


@symbol_fetcher_registry.register('technology-usa')
class TechnologySectorSymbolFetcher(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[Symbol]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks and exchange

        """
        vxx_symbols = read_csv(path_data + "/vxx_symbols.txt", comment="#")

        symbols = [Symbol(row.symbol, SymbolType[row.symbol_type], row.exchange, row.description)
                        for row in vxx_symbols.itertuples(index=False)]


        return symbols
