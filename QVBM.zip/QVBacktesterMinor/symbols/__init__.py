import os
import pathlib
from tqdm import tqdm
from pathlib import Path
from class_registry import ClassRegistry
from typing import Union
import pandas as pd
from deprecated import deprecated
from sklearn.utils import Bunch
from .base_symbol_fetcher import BaseSymbolFetcher, Symbol, SymbolType, Exchange

# from .faang_symbol_fetcher import FaangSymbolFetcher
# from .sp500_wikipedia_symbol_fetcher import SP500WikipediaSymbolFetcher
# from .nasdaq_symbol_fetcher import NasdaqOtherSymbolFetcher
# from .etf_symbol_data_fetcher import SpdrEtfSymbolFetcher
# from .globex_futures_symbol_fetcher import GlobexSymbolFutureFetcher
# from .sector_etf_symbol_fetcher import SectorETFSymbolFetcher
# from .indices_symbol_fetcher import IndicesSymbolFetcher

path = os.path.dirname(__file__)
path_data = pathlib.Path(os.path.dirname(__file__)) / 'data'


# exposing the packckage
__all__ = [
    'BaseSymbolFetcher',
    'symbol_fetcher_registry',
    'Symbol',
    'SymbolType',
    'Exchange'
]

# whence the registry is initialized we can import the fetcher
symbol_fetcher_registry = ClassRegistry()
from .vix_symbol_fetcher import VixSymbolFetcher
from .technology_usa_symbol_fetcher import TechnologySectorSymbolFetcher


@deprecated("move to dict based get_stockdata")
def get_stock_data(symbols: Union[str, list], repo_home: str = 'D:\eoddata', source: str = 'us', mode: str = 'daily', suppress_exception: bool = True):
    """

    Parameters
    ----------
    symbols
    repo_home
    source
    mode
    suppress_exception

    Returns
    -------
        get stockdata as list (deprecated)
    """
    # data_source = 'av'
    # default_output_dir_name = 'Test/' + source
    # default_output_dir_path = pathlib.Path.home() / default_output_dir_name / mode
    # Create the directory if it doesn't exist
    default_output_dir_path = Path(repo_home) / source / mode

    if isinstance(symbols, str):
        symbols = [symbols]
    print(default_output_dir_path)
    #if isinstance(symbols, list):
    print("list mode")
    df = []
    for s in symbols:
        try:
            symbol_str = f'{s.upper()}.csv'
            # print(symbol_str)
            df_ = pd.read_csv(os.path.join(default_output_dir_path, symbol_str), parse_dates=['date'],
                           index_col='date')
            # print(df_.head(4))
            if df_.empty:
                print(f"Empty dataframe {symbol_str}")
            else:
                df.append(df_)

        except Exception as e:
            print(e)
            if not suppress_exception:
                raise e
    # else:
    #     df = read_csv(os.path.join(default_output_dir_path, f'{symbols.upper()}.US.csv'), parse_dates=['date'],
    #                   index_col='date')
    return df

# dictionary based version

# dictionary based version
def get_stockdatad(symbols: Union[str, list],
                   repo_home: str = 'D:\eoddata',
                   source: str = 'us',
                   mode: str = 'daily',
                   suffix: str = 'csv',
                   index_col: str = 'date',  # default to index is "date" column
                   *,
                   from_date: str = None,
                   suppress_exception: bool = True):
    """

    Parameters
    ----------
    symbols
    repo_home
    source
    mode
    suppress_exception

    Returns
    -------
        stockdata as dict where key is stock name and value is its data
    """
    # data_source = 'av'
    # default_output_dir_name = 'Test/' + source
    # default_output_dir_path = pathlib.Path.home() / default_output_dir_name / mode
    # Create the directory if it doesn't exist
    default_output_dir_path = Path(repo_home) / source / mode

    if isinstance(symbols, str):
        symbols = [symbols]
    print(default_output_dir_path)
    # if isinstance(symbols, list):

    main_dict = dict()
    for s in tqdm(symbols, desc="reading symbols.."):
        try:

            symbol_str = f'{s.upper()}'
            symbol_filename = f'{s.upper()}.{suffix}'
            # print(symbol_str)
            df_ = pd.read_csv(os.path.join(default_output_dir_path, symbol_filename), parse_dates=[index_col],
                              index_col=0, sep=",")
            # print(df_.head(4))
            if df_.empty:
                print(f"Empty dataframe {symbol_str}")
            # else:
            #     df[symbol_str] = df_
            # data_ = Bunch(ohlc=df_)  # attrdict from sklearn or package addict

            main_dict[symbol_str] = df_[df_.index >= from_date] if from_date else df_
        except Exception as e:
            print(f"problem in processing {symbol_str} {e}")
            if not suppress_exception:
                raise e

    # example of read_csv
    # df = read_csv(os.path.join(default_output_dir_path, f'{symbols.upper()}.US.csv'), parse_dates=['date'],
    #               index_col='date')
    return main_dict


def get_stockdatad_old(symbols: Union[str, list],
                   repo_home: str = 'D:\eoddata',
                   source: str = 'us',
                   mode: str = 'daily',
                   suffix: str = 'csv',
                   suppress_exception: bool = True):
    """

    Parameters
    ----------
    symbols
    repo_home
    source
    mode
    suppress_exception

    Returns
    -------
        stockdata as dict where key is stock name and value is its data
    """
    # data_source = 'av'
    # default_output_dir_name = 'Test/' + source
    # default_output_dir_path = pathlib.Path.home() / default_output_dir_name / mode
    # Create the directory if it doesn't exist
    default_output_dir_path = Path(repo_home) / source / mode

    if isinstance(symbols, str):
        symbols = [symbols]
    print(default_output_dir_path)
    #if isinstance(symbols, list):

    main_dict = dict()
    for s in tqdm(symbols, desc="reading symbols.."):
        try:

            symbol_str = f'{s.upper()}'
            symbol_filename = f'{s.upper()}.{suffix}'
            # print(symbol_str)
            df_ = pd.read_csv(os.path.join(default_output_dir_path, symbol_filename), parse_dates=['date'],
                           index_col='date')
            # print(df_.head(4))
            if df_.empty:
                print(f"Empty dataframe {symbol_str}")
            # else:
            #     df[symbol_str] = df_
            # data_ = Bunch(ohlc=df_)  # attrdict from sklearn or package addict
            main_dict[symbol_str] = df_
        except Exception as e:
            print(f"problem in processing {symbol_str} {e}")
            if not suppress_exception:
                raise e

    # example of read_csv
    # df = read_csv(os.path.join(default_output_dir_path, f'{symbols.upper()}.US.csv'), parse_dates=['date'],
    #               index_col='date')
    return main_dict
