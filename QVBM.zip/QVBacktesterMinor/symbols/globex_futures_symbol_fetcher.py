from . import symbol_fetcher_registry, BaseSymbolFetcher, Symbol, SymbolType
from typing import List


symbol_fetcher_registry.register('globex-futures')
class GlobexSymbolFutureFetcher(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[str]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks

        """

        # https://easylanguagemastery.com/15-price-action-patterns-that-work-in-2020/
        symbols = []

        symbols.append(Symbol('NE1', SymbolType.CONTFUTURE, 'NYSE', 'Newzeland currency'))
        symbols.append(Symbol('AD', SymbolType.CONTFUTURE, 'NYSE', 'Australian Dollar'))
        symbols.append(Symbol('SF', SymbolType.CONTFUTURE, 'NYSE', 'Swiss Franc'))

        symbols.append(Symbol('LH', SymbolType.CONTFUTURE, 'NYSE', 'Lean Hogs'))
        symbols.append(Symbol('SM', SymbolType.CONTFUTURE, 'NYSE', 'Soybean Meal'))
        symbols.append(Symbol('LC', SymbolType.CONTFUTURE, 'NYSE', 'Live Cattle'))
        symbols.append(Symbol('FC', SymbolType.CONTFUTURE, 'NYSE', 'Feeder Cattle'))
        symbols.append(Symbol('OJ', SymbolType.CONTFUTURE, 'NYSE', 'Orange Juice'))

        symbols.append(Symbol('GC', SymbolType.CONTFUTURE, 'NYSE', 'Gold'))
        symbols.append(Symbol('SI', SymbolType.CONTFUTURE, 'NYSE', 'Silver'))
        symbols.append(Symbol('HG', SymbolType.CONTFUTURE, 'NYSE', 'Copper'))

        symbols.append(Symbol('US', SymbolType.CONTFUTURE, 'NYSE', 'US Bonds'))

        symbols.append(Symbol('ES', SymbolType.CONTFUTURE, 'NYSE', 'Mini S&P'))
        symbols.append(Symbol('NQ', SymbolType.CONTFUTURE, 'NYSE', 'Mini Nasdaq'))
        symbols = ['ES']
        return symbols
