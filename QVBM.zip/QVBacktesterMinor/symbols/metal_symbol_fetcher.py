from . import symbol_fetcher_registry, BaseSymbolFetcher, Symbol, SymbolType
from typing import List, Tuple


@symbol_fetcher_registry.register('indicies')
class IndicesSymbolFetcher(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[Tuple[str,str]]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks and exchange

        """
        symbols = []

        # # Indices
        # symbols.append(Symbol('USS', SymbolType.INDEX, 'Globex', 'Dollar Index'))
        # symbols.append(Symbol('GOX', SymbolType.INDEX, 'CBOE', 'Gold Index'))
        #
        # # ETF
        # symbols.append(Symbol('VXX', SymbolType.STOCK, 'SMART', 'Etf'))
        # symbols.append(Symbol('UVXY', SymbolType.STOCK, 'SMART', 'Etf Ultra'))
        # symbols.append(Symbol('SVXY', SymbolType.STOCK, 'SMART', 'Etf Ultra'))

        # Futures
        symbols.append(Symbol('MGC', SymbolType.CONTFUTURE, 'NYMEX', 'Micro Gold Futures'))

        return symbols
