import pandas as pd

df = pd.read_csv('ftp://ftp.nasdaqtrader.com/SymbolDirectory/nasdaqlisted.txt', sep='|')
df.to_csv('nasdaqlisted.txt', index=False)
print ("done nasdaqlisted")

df = pd.read_csv('ftp://ftp.nasdaqtrader.com/SymbolDirectory/nasdaqtraded.txt', sep='|')
df.to_csv('nasdaqtraded.txt', index=False)
print ("done nasdaqtraded")

df = pd.read_csv('ftp://ftp.nasdaqtrader.com/SymbolDirectory/otherlisted.txt', sep='|')
df.to_csv('otherlisted.txt', index=False)
print ("done otherlisted")

