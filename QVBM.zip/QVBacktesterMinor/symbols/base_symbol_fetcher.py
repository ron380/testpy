import logbook
from collections import namedtuple
from enum import IntEnum, Enum

log = logbook.Logger('BaseSymbolFetcher')


class SymbolType(IntEnum):
    STOCK = 1
    INDEX = 2
    CONTFUTURE = 3
    FUTURE = 4
    FOREX = 5
    CFD = 6
    BOND = 7


class Exchange(Enum):
    SMART = "SMART"
    NYSE = "NYSE"
    NYMEX = "NYMEX"
    GLOBEX = "GLOBEX"


# classlike tuple for Symbol definition
Symbol = namedtuple("Symbol", ['Name', 'Type', 'Exchange', 'Description'], defaults=('SMART', ''))


class BaseSymbolFetcher(object):

    def __init__(self):
        pass

    def symbols(self):
        """
        Returns the list of symbols that were fetched.

        Returns:
            symbols (list): list of symbols that were fetched.

        """
        raise NotImplementedError
