from . import symbol_fetcher_registry, BaseSymbolFetcher, Symbol, SymbolType


import pandas as pd
from typing import List


@symbol_fetcher_registry.register('nasdaq-traded')
class NasdaqSymbolFetcherTraded(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[str]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks

        """
        df = pd.read_csv('ftp://ftp.nasdaqtrader.com/SymbolDirectory/nasdaqtraded.txt', sep='|')

        # save example
        # data.to_csv('nasdaqlisted.txt', index=False, sep='|')
        # remove the last row
        df.drop(df.tail(1).index, inplace=True)
        # df = data.iloc[:-1] another way to do this
        SYMBOL_COLUMN = 'NASDAQ Symbol'
        """
        Financial Status 	Indicates when an issuer has failed to submit its regulatory filings on a timely basis, has failed to meet NASDAQ's continuing listing standards, and/or has filed for bankruptcy. Values include:

                D = Deficient: Issuer Failed to Meet NASDAQ Continued Listing Requirements
                E = Delinquent: Issuer Missed Regulatory Filing Deadline
                Q = Bankrupt: Issuer Has Filed for Bankruptcy
                N = Normal (Default): Issuer Is NOT Deficient, Delinquent, or Bankrupt.
                G = Deficient and Bankrupt
                H = Deficient and Delinquent
                J = Delinquent and Bankrupt
                K = Deficient, Delinquent, and Bankrupt

        """
        """
        Test Issue 	Indicates whether or not the security is a test security. Values: 
            Y = yes, it is a test issue. 
            N = no, it is not a test issue.
        """
        symbols = df.loc[(df['Financial Status'] == 'N') & (df['Test Issue'] == 'N') & (df['ETF'] == 'N'), SYMBOL_COLUMN].tolist()
        return [Symbol(x) for x in symbols]


@symbol_fetcher_registry.register('nasdaq-listed')
class NasdaqSymbolFetcherListed(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[str]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks

        """
        df = pd.read_csv('ftp://ftp.nasdaqtrader.com/SymbolDirectory/nasdaqlisted.txt', sep='|')
        df.drop(df.tail(1).index, inplace=True)
        df.set_index('Symbol', inplace=True)
        #df = data.iloc[:-1]
        SYMBOL_COLUMN = 'NASDAQ Symbol'

        # save
        #.to_csv('nasdaqlisted.txt', index=False, sep='|')

        filter1 =  (df['Financial Status'] == 'N') & (df['Test Issue'] == 'N') & (df['ETF'] == 'N')
        filter2 = ~(df['Security Name'].str.contains('Warrant') & df.index.str.endswith('W'))
        filter3 = ~(df['Security Name'].str.endswith('Units') & df.index.str.endswith('U'))

        symbols = df.loc[filter1 & filter2 & filter3].index


        return [Symbol(x, SymbolType.STOCK, 'NYSE') for x in symbols]


@symbol_fetcher_registry.register('nasdaq-other')
class NasdaqOtherSymbolFetcher(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[str]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks

        """
        df = pd.read_csv('ftp://ftp.nasdaqtrader.com/SymbolDirectory/otherlisted.txt', sep='|')

        # save output example
        # data.to_csv('otherlisted.txt', index=False, sep='|')
        df.drop(df.tail(1).index, inplace=True)
        #df = data.iloc[:-1]
        SYMBOL_COLUMN = 'NASDAQ Symbol'
        symbols = df.loc[(df['Test Issue'] == 'N') & (df['ETF'] == 'N'), SYMBOL_COLUMN].tolist()
        return [Symbol(x) for x in symbols]


