from . import symbol_fetcher_registry, BaseSymbolFetcher, Symbol, SymbolType
from typing import List, Tuple


@symbol_fetcher_registry.register('sector-etfs')
class SectorETFSymbolFetcher(BaseSymbolFetcher):

    def __init__(self):
        super().__init__()

    def symbols(self) -> List[Tuple[str,str]]:
        """

        Returns:
            symbols (List[str]): A list containing all the ticker symbols of the S&P500 stocks and exchange

        """
        symbols = []
        # Indices
        # SymbolType.STOCK, 'NYSE'
        symbols.append(Symbol('SPY', SymbolType.STOCK, 'NYSE', 'S&P 500'))
        symbols.append(Symbol('QQQ', SymbolType.STOCK, 'NYSE', 'Nasdaq 100'))

        return symbols
