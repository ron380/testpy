from finvizfinance.screener.overview import Overview
import pathlib


def fetch_sector_finviz(sector: str, country: str = 'USA'):
    overview = Overview()
    filters_dict = {
                    'Sector':  sector,
                    'Country': country
                    }
    overview.set_filter(filters_dict=filters_dict)
    df = overview.ScreenerView().drop(columns=["Change"])
    print(df)
    data_source = f"tickerlist_{sector.replace(' ', '').lower()}_{country}.txt"
    data_dir = pathlib.Path('data')
    output_filename = data_dir / data_source
    df.to_csv(output_filename, index=False)


if __name__ == '__main__':
    print("Technology")
    fetch_sector_finviz(sector='Technology')
    print("Healthcare")
    fetch_sector_finviz(sector='Healthcare')
    print("Communication Services")
    fetch_sector_finviz(sector='Communication Services')