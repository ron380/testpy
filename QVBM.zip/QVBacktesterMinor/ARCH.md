# Architecture




strategy class

        class MTRSStrategy56(QVStrategy):
            """
            RSI(5) cross over the zero line (tesing)
            """
            # install the class attributes
            copy = False
            deep = False
            



        the attributes are 
            cls.copy
            cls.deep
    
        @classmethod
        def preprocess(cls, ohlcv: DataFrame, **fit_params):
        # return a preprocessed dataset, does not touch the strategy internals
        if cls.copy:
            """
            When deep=True (default), a new object will be created with a copy of the calling object’s 
            data and indices. Modifications to the data or indices of the copy will not be reflected in 
            the original object (see notes below).

            When deep=False, a new object will be created without copying the calling object’s data or 
            index (only references to the data and index are copied). Any changes to the data of the 
            original will be reflected in the shallow copy (and vice versa).
            """
            ohlcv = ohlcv.copy(deep=cls.deep)
        ohlcv.ta.rsi(length=5, append=True)
        return ohlcv


backtrade
    