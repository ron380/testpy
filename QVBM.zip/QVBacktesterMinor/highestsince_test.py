import numpy as np
import pandas as pd
from pandas import Series

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)

def highestsince(cond: Series, x: Series, n: int = 1):
    # y = Series(x[cond].shift(periods=n-1), index=x.index)

    N = cond.shape[0]
    y = np.full(N, np.NaN)
    yy = np.full(N, np.NaN)
    # array of cond indices
    cond_ind = np.flatnonzero(cond)
    v_ = False
    # first round
    for i in range(N):
        if cond[i]:
            y[i] = x[i]
            v_ = True
            continue
        if v_:
            y[i] = max(x[i], y[i-1])

    if n == 1:
        return Series(y, index=x.index)

    cond_count = -1
    for i in range(N):
        if cond[i]:
            cond_count += 1
            if cond_count >= n-1:
                for k in range(0, n-1):
                    if cond_count - k >= 0:
                        j = cond_ind[cond_count - k] - 1
                        if j >= 0:
                            # last_max = max(last_max, y[j])
                            # print(i, j)
                            yy[i] = max(x[i], y[j])
                v_ = True
                continue

        if v_ and cond_count >= n-1:
            yy[i] = max(x[i], yy[i-1])

    return Series(yy, index=x.index)



def highestsince(cond: Series, x: Series, n: int = 1):
    # y = Series(x[cond].shift(periods=n-1), index=x.index)

    N = cond.shape[0]
    y = np.full(N, np.NaN)
    yy = np.full(N, np.NaN)
    # array of cond indices
    cond_ind = np.flatnonzero(cond)
    v_ = False
    # first round
    for i in range(N):
        if cond[i]:
            y[i] = x[i]
            v_ = True
            continue
        if v_:
            y[i] = max(x[i], y[i-1])

    if n == 1:
        return Series(y, index=x.index)

    cond_count = -1
    for i in range(N):
        if cond[i]:
            cond_count += 1
            if cond_count >= n-1:
                for k in range(0, n-1):
                    if cond_count - k >= 0:
                        j = cond_ind[cond_count - k] - 1
                        if j >= 0:
                            # last_max = max(last_max, y[j])
                            # print(i, j)
                            yy[i] = max(x[i], y[j])
                v_ = True
                continue

        if v_ and cond_count >= n-1:
            yy[i] = max(x[i], yy[i-1])

    return Series(yy, index=x.index)

if __name__ == '__main__':
    A = pd.read_csv("test_data.txt", delimiter="\t")
    A.Condition = A.Condition.astype(bool)
    A['CumSumCond'] = np.cumsum(A.Condition)
    s = highestsince(A.Condition, A.Close, n=2)
    print(pd.concat([A["Date/Time"], A['CumSumCond'], A.Condition, A.Close, A["HighestSince 1"], A["HighestSince 2"], s], axis=1))

    # s = highestsince(A.Condition, A.Close, n=1)
    # print(pd.concat([A["Date/Time"], A['CumSumCond'], A.Condition, A.Close, A["HighestSince 1"], s], axis=1))
