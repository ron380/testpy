
# main example
python scripts/backtest_ami_portfolio_hydra.py

# new version
scripts/backtest_ami_portfolio_hydra2.py