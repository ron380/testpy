# %%
import pandas as pd
import pandas_ta as ta
import symbols
from symbols import get_stockdatad
from pathlib import Path
import time

REPOHOME = "c:/Users/ronsh/eoddata"
OUT_DIR  = "C:/Users/ronsh/code/R-devel/TechnicalAnalysis/tests/testthat/compdir"
import pandas as pd
universe_all = pd.read_csv(Path(REPOHOME) / "list/US_marketcap_1B_symbols.csv")
# filter the sector or the industry
# build the algotrade on each sector
universe = universe_all[universe_all['sector'] == 'Technology']
print(universe.head())
print(len(universe))

symbols = (universe['code'] + '.' + universe['country']).to_list()

# to save some time....
symbols = symbols[:100]

symbols = ['AAPL.US', 'MSFT.uS', 'NVDA.US', 'NFLX.US', 'AMZN.US']

start = time.time()
ohlc_list = get_stockdatad(symbols, repo_home=REPOHOME)
# ohlc_list = [get_stock_data(x) for x in symbol_list]
print("time = ", time.time() - start)
print(ohlc_list["AAPL.US"])

df = ohlc_list["AAPL.US"]

# %% 
if False:
    df.to_csv(Path(OUT_DIR) / "AAPL.US.csv")

funcs = ["ema", "rma", "zlma"]
# apply indicator
for func in funcs:
    result = eval("df.ta." + func + "()")
    result = pd.DataFrame({func: result})
    result.to_csv(Path(OUT_DIR) / f"check-{func}.csv")

# pandas ewm with some alphe
func = "ewm"
alpha = 0.2
ewm = df.close.ewm(alpha=alpha, adjust=False).mean()
ewm.to_csv(Path(OUT_DIR) / f"check-{func}-adjF.csv")
ewm = df.close.ewm(alpha=alpha, adjust=True).mean()
ewm.to_csv(Path(OUT_DIR) / f"check-{func}-adjT.csv")


# linreg
func = "linreg"
attr_list = ["slope", "intercept"]
for attr in attr_list:
    result = eval("df.ta." + func + f"({attr}=True)")
    result = pd.DataFrame({f"{func}_{attr}": result})
    result.to_csv(Path(OUT_DIR) / f"check-{func}-{attr}.csv")
