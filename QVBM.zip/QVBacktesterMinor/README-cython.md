using setup2.py

running: 
