
Sys.setenv(CUDA="gpu")
# Load required libraries
library(tidyverse)
library(tibble)
# Tidy Temporal Data Frames and Tools
library(tsibble) 
# Feature Extraction and Statistics for Time Series
library(feasts) 
# Diverse Datasets for 'tsibble'
library(tsibbledata) 
# library(reticulate)
library(torch)
library(luz)

# input dimensionality (number of input features)
d_in <- 3
# number of observations in training set
n <- 100
# dimensionality of hidden layer
d_hidden <- 32
# output dimensionality (number of predicted features)
d_out <- 1

learning_rate <- 0.01

batch_size <- 16

net <- nn_sequential(
  nn_linear(d_in, d_hidden),
  nn_relu(),
  nn_linear(d_hidden, d_out)
)

# Initialize the torch device

# proper training
# train_ds <- dataset_subset(ds, indices = train_ids)
# valid_ds <- dataset_subset(ds, indices = valid_ids)
# test_ds <- dataset_subset(ds, indices = test_ids)

# train_dl <- dataloader(train_ds, batch_size = batch_size)
# valid_dl <- dataloader(valid_ds, batch_size = batch_size)
# test_dl <- dataloader(test_ds, batch_size = batch_size)

# Define the GRU model
# gru_model <- nn_sequential(
#   nn_gru(input_size = input_size, hidden_size = hidden_size, num_layers = 1, batch_first = TRUE),
#   nn_linear(hidden_size, output_size)
# )


# # Send the model to the torch device
# gru_model$to(torch_device)

# # Define the loss function (MSE Loss)
# loss_fn <- nn_loss_mse()

# # Define the optimizer
# optimizer <- torch_optimizer_adam(gru_model$parameters(), lr = learning_rate)


demand_dataset <- dataset(
  name = "demand_dataset",
  initialize = function(x, n_timesteps, sample_frac = 1) {
    self$n_timesteps <- n_timesteps
    self$x <- torch_tensor((x - train_mean) / train_sd)

    n <- length(self$x) - self$n_timesteps

    self$starts <- sort(sample.int(
      n = n,
      size = n * sample_frac
    ))
  },
  .getitem = function(i) {
    start <- self$starts[i]
    end <- start + self$n_timesteps - 1

    list(
      x = self$x[start:end],
      y = self$x[end + 1]
    )
  },
  .length = function() {
    length(self$starts)
  }
)



demand_hourly <- vic_elec %>%
  index_by(Hour = floor_date(Time, "hour")) %>%
  summarise(
    Demand = sum(Demand))

demand_train <- demand_hourly %>% 
  filter(year(Hour) == 2012) %>%
  as_tibble() %>%
  select(Demand) %>%
  as.matrix()

demand_valid <- demand_hourly %>% 
  filter(year(Hour) == 2013) %>%
  as_tibble() %>%
  select(Demand) %>%
  as.matrix()

demand_test <- demand_hourly %>% 
  filter(year(Hour) == 2014) %>%
  as_tibble() %>%
  select(Demand) %>%
  as.matrix()

train_mean <- mean(demand_train)
train_sd <- sd(demand_train)

input_size <- 1
hidden_size <- 32
num_layers <- 2
rec_dropout <- 0.2


n_timesteps <- 7 * 24
train_ds <- demand_dataset(demand_train, n_timesteps)
valid_ds <- demand_dataset(demand_valid, n_timesteps)
test_ds <- demand_dataset(demand_test, n_timesteps)

dim(train_ds[1]$x)
dim(train_ds[1]$y)


batch_size <- 32

train_dl <- train_ds %>%
  dataloader(batch_size = batch_size)
valid_dl <- valid_ds %>%
  dataloader(batch_size = batch_size)
test_dl <- test_ds %>%
  dataloader(batch_size = length(test_ds))

b <- train_dl %>%
  dataloader_make_iter() %>%
  dataloader_next()

dim(b$x)
dim(b$y)


model <- nn_module(
  initialize = function(input_size,
                        hidden_size,
                        dropout = 0.2,
                        num_layers = 1,
                        rec_dropout = 0) {
    self$num_layers <- num_layers

    self$rnn <- nn_lstm(
      input_size = input_size,
      hidden_size = hidden_size,
      num_layers = num_layers,
      dropout = rec_dropout,
      batch_first = TRUE
    )

    self$dropout <- nn_dropout(dropout)
    self$output <- nn_linear(hidden_size, 1)
  },
  forward = function(x) {
    (x %>%
      # these two are equivalent
      # (1)
      # take output tensor,restrict to last time step
      self$rnn())[[1]][, dim(x)[2], ] %>%
      # (2)
      # from list of state tensors,take the first,
      # and pick the final layer
      # self$rnn())[[2]][[1]][self$num_layers, , ] %>%
      self$dropout() %>%
      self$output()
  }
)

# setup model and hyperparameters
model <- model %>%
  setup(optimizer = optim_adam, loss = nn_mse_loss()) %>%
  set_hparams(
    input_size = input_size,
    hidden_size = hidden_size,
    num_layers = num_layers,
    rec_dropout = rec_dropout
  )


# learning rate finder
rates_and_losses <- model %>% 
  lr_finder(train_dl, start_lr = 1e-3, end_lr = 1)

rates_and_losses %>% plot()



fitted <- model %>%
  fit(train_dl, epochs = 50, valid_data = valid_dl,
      callbacks = list(
        luz_callback_early_stopping(patience = 3),
        luz_callback_lr_scheduler(
          lr_one_cycle,
          max_lr = 0.1,
          epochs = 50,
          steps_per_epoch = length(train_dl),
          call_on = "on_batch_end")
      ),
      verbose = TRUE)

plot(fitted)

# # Train the model
# for (epoch in 1:num_epochs) {
#   # Set the model to training mode
#   gru_model$train()

#   # Iterate through the batches
#   for (i in 1:num_batches) {
#     # Generate batch data (x_train, y_train) or load from your dataset
    
#     # Convert data to torch tensors and send to device
#     x_train_tensor <- torch_tensor(x_train, dtype = torch_float(), device = torch_device)
#     y_train_tensor <- torch_tensor(y_train, dtype = torch_float(), device = torch_device)
    
#     # Zero the gradients
#     optimizer$zero_grad()

#     # Forward pass
#     y_pred <- gru_model(x_train_tensor)

#     # Compute the loss
#     loss <- loss_fn(y_pred, y_train_tensor)

#     # Backward pass
#     loss$backward()

#     # Update weights
#     optimizer$step()
#   }

#   # Print loss after each epoch
#   cat(sprintf("Epoch %d - Loss: %.4f\n", epoch, loss$item()))
# }
