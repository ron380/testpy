
library(tidyverse, warn.conflicts = FALSE)
# add TTR, quant, do we need this?
# library(tidyquant, warn.conflicts = FALSE)
# function composition https://search.r-project.org/CRAN/refmans/gestalt/html/compose.html
library(gestalt)

base_path <- file.path("C:/Users/ronsh/eoddata")

symbol_universe_metadata <- read_csv(file.path(base_path, "list", "US_marketcap_1B_symbols.csv"), show_col_types = FALSE)

sectors <- symbol_universe_metadata |> pull(sector)|> unique()
cat("sectors: ", paste(sectors, sep=","), "\n")
symbols <- c('AAPL.US', 'MSFT.US', 'NVDA.US', 'NFLX.US', 'AMZN.US', 'META.US')


# concatenate symbols to path and apply read_csv function
# df is a list of tibbles and we want it to be indexed indexed using setNames
df <- map(file.path(base_path, "us", "daily", paste0(symbols, ".csv")), ~read_csv(., show_col_types=FALSE)) |> setNames(symbols)



pfunc <- function(func, ...) {
    fixed_args <- list(...)
    
    # Define a new function with fixed arguments
    partial_function <- function(...) {
        args <- c(fixed_args, list(...))
        call(func, args)
    }
    
    return(partial_function)
}


run_grid <- function(ind) {

    func <- call(ind$func, ohlc=df$AAPL.US, ind$params)

}

library(yaml)
conf <- read_yaml("scripts/conf_test.yaml")
ind <- conf$indicators[["rsi"]]




func <- call(ind$func, ohlc=df$AAPL.US, ind$params)




# getfun - allow to parse package::function
# for invocation using do.call
getfun <- function(x) {
    if (length(grep("::", x)) > 0) {
        parts <- strsplit(x, "::")[[1]]
        getFromNamespace(parts[2], parts[1])
    } else {
        x
    }
}

# parse steps
composite_function_from_yaml <- function(steps) {
    # witll return a function applied on source
    
    function(source) {
        for (i in seq_along(steps)) {
        
            step <- steps[[i]]
            func_name <- step$func
            func <- getfun(func_name)
            params <- step$params
            cat("start step", func_name, "\n")
            # print(func)
            print(params)
            if (i == 1)
                result <- do.call(func, c(list(ohlc=df$AAPL.US), params))
            else
                result <- do.call(func, list(result, params))
            

            # head(result, 30)
        }
        return (result)
    }
}


composite_function_from_yaml(conf$composite_indicators$rsi_high$steps)(1)


composite_function <- function(functions_with_params) {
  
    function(x) {
        result <- x
        for (func_param in functions_with_params) {
            func <- func_param[[1]]
            params <- func_param[-1]
            
            # result <- f(result)
            result <- do.call(func, c(result, params))
        }
        return(result)
    }
}

# list comprehesion for ohlc and parameters
# combine two lists to one list c(list, list) or add key-value list[[key]] <- value
result <- do.call(getfun(ind$func), c(list(ohlc=df$AAPL.US), ind$params))


composite_function_from_yaml(conf$composite_indicators$rsi_high$steps)(1)

stop()
# eval(func)


https://stackoverflow.com/questions/38983179/do-call-a-function-in-r-without-loading-the-package


# `getExportedValue()` is a function in R's `tools` package. It is primarily used to retrieve exported values from namespaces. This function is particularly useful when you need to access objects exported by a package but don't want to attach the entire namespace.

# Here's a breakdown of how `getExportedValue()` works:

# 1. **Retrieve Exported Values**: The primary purpose of `getExportedValue()` is to obtain exported values (such as functions, datasets, or other objects) from a namespace without attaching the entire namespace.

# 2. **Arguments**:
#    - `ns`: The namespace from which you want to retrieve the exported value.
#    - `name`: The name of the object you want to retrieve from the namespace.

# 3. **Usage**:
#    ```R
#    getExportedValue(ns, name)
#    ```

# 4. **Example**:
#    ```R
#    # Load the package
#    library(dplyr)

#    # Retrieve the exported function "summarize" from the dplyr namespace
#    summarize_fun <- tools::getExportedValue("dplyr", "summarize")
#    ```

#    In this example, `getExportedValue()` retrieves the exported function `summarize` from the `dplyr` namespace. This allows you to use the function without attaching the entire `dplyr` namespace.

# 5. **Avoiding Namespace Conflicts**: Using `getExportedValue()` can help avoid namespace conflicts, especially when working with multiple packages that may have objects with the same name.

# Overall, `getExportedValue()` provides a convenient way to access specific exported objects from namespaces, contributing to better encapsulation and namespace hygiene in R programming.
# getfun <- function(x) {
#     if(length(grep("::", x)) > 0) {
#         parts <- strsplit(x, "::")[[1]]
#         getExportedValue(parts[1], parts[2])
#     } else {
#         x
#     }
# }
# library(dplyr)

# # Define the function arguments
# args_list <- list(.data = iris, exprs = quote(mean(Sepal.Length)))

# # Call the function from the dplyr package using do.call
# result <- do.call(getfun("dplyr::summarize"), args_list)



library(dplyr)

# Define the function name with the package prefix
fun_name <- "summarize"
package_name <- "dplyr"

# Define the function arguments
args_list <- list(.data = iris, exprs = quote(mean(Sepal.Length)))

# Get the function object using get()
fun <- get(fun_name, envir = asNamespace(package_name))

# Call the function using do.call()
result <- do.call(fun, args_list)



# grep from list 
ls("package:base") %>% grep("^get", ., value=T)