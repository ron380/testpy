# https://bookdown.org/kochiuyu/Technical-Analysis-with-R/blotter-package.html


# To start, we initialize account and portfolio where:

# Porfolio: stores which stocks to be traded

# Account: stores which money transactions
# The pos argument can specify the environment from which to remove the objects in any of several ways
rm("account.buyHold",pos=.blotter)
rm("portfolio.buyHold",pos=.blotter)

initPortf("buyHold", symbol=symbols)
initAcct("buyHold", portfolios = "buyHold",
         initEq = initEq)