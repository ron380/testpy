library(yaml)
library(rlang)
# reference for yaml https://realpython.com/python-yaml/ 
conf <- read_yaml("conf_test.yaml", merge.precedence = "override")
print(conf)


ind <- conf$indicators[["rsi"]]
mysteps <- conf$composite_indicators$rsi_high


# parse steps
composite_function_from_yaml <- function(steps) {
    # witll return a function applied on source
    
    function(...) {
        # source <- enexpr(source)
        # print(source)
        args1 <- list(...)
        result <- NULL
        for (i in seq_along(steps)) {
        
            step <- steps[[i]]
            func_name <- step$func
            func <- getfun(func_name)
            params <- step$params
            cat("\n\n> start step", func_name, "\n")
            # print(func)
            print(params)
            # print(func)
            print(typeof(params))
            if (i == 1) {
                result <- do.call(func, c(args1, params))
                cat(head(result, 30))
            }
            else {
                args <- c(list(result), params)
                cat("names args ", names(args))
                print(head(args, 30))
                result <- do.call(func, args)
                cat(head(result, 30))
            }
            

            
        }
        return (result)
    }
}


composite_func <- composite_function_from_yaml(mysteps)
result <- composite_func(ohlc=df$AAPL.US)
