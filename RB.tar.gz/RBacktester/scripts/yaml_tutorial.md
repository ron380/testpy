library(yaml)


x <- read_yaml("b.yaml")



without (-) it's just key-value. This sample document defines a family tree with grandparent as the root element, whose immediate child is the parent element, which has two children with the name attribute on the lowest level in the tree. You can think of each element as an opening statement followed by a colon (:) in Python.

grandparent:
  parent:
    child:
      name: Bobby
    sibling:
      name: Molly

yaml uses block indentation or embed its json 


grandparent:
  parent:
    child: {name: Bobby}
    sibling: {'name': "Molly"}


Sequences in YAML are just like Python lists or JSON arrays. They use the standard square bracket syntax ([]) in the inline-block mode or the leading dashes (-) at the start of each line when they’re block indented:

fruits: [apple, banana, orange]
veggies:
  - tomato
  - cucumber
  - onion
mushrooms:
- champignon
- truffle
You can keep your list items at the same indentation level as their property name or add more indentation if that improves readability for you



person:
  firstName: John
  lastName: Doe
  dateOfBirth: 1969-12-31
  married: true
  spouse:
    firstName: Jane
    lastName: Smith
  children:
    - firstName: Bobby
      dateOfBirth: 1995-01-17
    - firstName: Molly
      dateOfBirth: 2001-05-14

```r
x <- read_yaml("person.yaml")
$person
$person$firstName
[1] "John"

$person$lastName
[1] "Doe"

$person$dateOfBirth
[1] "1969-12-31"

$person$married
[1] TRUE

( here its just a fields under spouse )
$person$spouse
$person$spouse$firstName
[1] "Jane"

$person$spouse$lastName
[1] "Smith"

(here is a list under children)
$person$children
$person$children[[1]]
$person$children[[1]]$firstName
[1] "Bobby"

$person$children[[1]]$dateOfBirth
[1] "1995-01-17"


$person$children[[2]]
$person$children[[2]]$firstName
[1] "Molly"

$person$children[[2]]$dateOfBirth
[1] "2001-05-14"
```


## YAML Features
Other powerful features of YAML are anchors and aliases, which let you define an element once and then refer to it many times within the same document. Potential use cases include:

Reusing the shipping address for invoicing
Rotating meals in a meal plan
Referencing exercises in a training program

To declare an anchor, which you can think of as a named variable, you’d use the ampersand (&) symbol, while to dereference that anchor later on, you’d use the asterisk (*) symbol:



## YAML language independent types

Language-Independent Types for YAML™ Version 1.1
Last Updated On 2005-01-18
Copyright © 2001-2005 Oren Ben-Kiki, Clark Evans, Brian Ingerson

This document may be freely copied provided it is not modified.
1. Introduction
The following is the list of language-independent YAML tags defined under the domain yaml.org. The use of these tags is not mandatory. However these tags represent types that are useful across a wide range of applications and it is strongly recommended they be used whenever appropriate to promote interoperability.

New language-independent tags may be proposed on the yaml-core mailing list. This mailing list is also the forum for raising any question regarding these types.

2. Collection Types
!!map html pdf ps

Unordered set of key: value pairs without duplicates.

!!omap html pdf ps

Ordered sequence of key: value pairs without duplicates.

!!pairs html pdf ps

Ordered sequence of key: value pairs allowing duplicates.

!!set html pdf ps

Unordered set of non-equal values.

!!seq html pdf ps

Sequence of arbitrary values.

3. Scalar Types
!!binary html pdf ps

A sequence of zero or more octets (8 bit values).

!!bool html pdf ps

Mathematical Booleans.

!!float html pdf ps

Floating-point approximation to real numbers.

!!int html pdf ps

Mathematical integers.

!!merge html pdf ps

Specify one or more mappings to be merged with the current one.

!!null html pdf ps

Devoid of value.

!!str html pdf ps

A sequence of zero or more Unicode characters.

!!timestamp html pdf ps

A point in time.

!!value html pdf ps

Specify the default value of a mapping.

!!yaml html pdf ps

Keys for encoding YAML in YAML.