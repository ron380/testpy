library(tidyverse, warn.conflicts = FALSE)
# add TTR, quant
library(tidyquant, warn.conflicts = FALSE)
# function composition https://search.r-project.org/CRAN/refmans/gestalt/html/compose.html
library(gestalt)

base_path <- file.path("C:/Users/ronsh/eoddata")

symbol_universe_metadata <- read_csv(file.path(base_path, "list", "US_marketcap_1B_symbols.csv"), show_col_types = FALSE)

sectors <- symbol_universe_metadata |> pull(sector)|> unique()
cat("sectors: ", paste(sectors, sep=","), "\n")
symbols <- c('AAPL.US', 'MSFT.US', 'NVDA.US', 'NFLX.US', 'AMZN.US')

# concatenate symbols to path and apply read_csv function
# df is a list of tibbles and we want it to be indexed indexed using setNames
df <- map(file.path(base_path, "us", "daily", paste0(symbols, ".csv")), ~read_csv(., show_col_types=FALSE)) |> setNames(symbols)

print(df)
stop()
# learn how to pivot for close on list of dataframes
# first concatenate all rows
all_rows <- bind_rows(df)
all_rows |> pivot_wider(id_cols=c("date"), names_from = c("ticker"), values_from = "close")
# for open, close
all_rows |> pivot_wider(id_cols=c("date"), names_from = c("ticker"), values_from=c("open", "close"), names_sep = ".")


# concatenate symbols to path and apply read_csv function
# df becomes a `list`` indexed using setNames function
df <- map(file.path(base_path, "us", "daily", paste0(symbols, ".csv")), ~read_csv(., show_col_types=FALSE)) |> setNames(symbols)

# create multiple columns of different RSI values
map_dfc (c(3,4,5), ~df[[1]] |>  transmute("rsi_{{.}}" := RSI(close, .) ))

# define functions
fun =  RSI(4) %>>>% runMax(5)
# since we are using a matrix we need to subsert it
fu1 = BBands(3) %>>>% subset(select=2)  %>>>% runMax(3)

# expand.grid to create dataframe grid over more than two parameters
x = list(n = c(1,2,3), n=c(2,3,4))
expand.grid(x)
# to optimize reverse names to start from last

# for uneven list with unquote splice operator
expand_grid(!!!params_grid_)

# we will create a list of expandable grids
AAA = list( list(kernel="A"), list(kernel="B", b=c(1,2,3)))
do not use c() becuase it will coerce two list two one_of(

then map(AAA, ~ expand_grid(!!!.x)) will expand wisely the grid

# call a function with list using do.call

# access columns with the same name
# https://stackoverflow.com/questions/67649621/data-frame-with-2-columns-with-the-same-name-how-to-select-the-second-one
library(makeunique)
> make_unique(names(df), sep="_", wrap_in_brackets=F)
[1] "n_1" "n_2"

# new in tidyr
expand_grid(n=c(1,2,3), n=c(2,3,4), .name_repair="unique")
# we need to change names manually based on the steps

# inject parameters from params grid to a function
library(purrr)
results = pmap(param_grid, my_function)
print(results)

my_function <- function(x, y, z) {
  # Perform calculations using x, y, and z
}

data_list <- list(list(1, 2, 3), list(4, 5, 6), list(7, 8, 9))
results <- pmap(data_list, my_function)

# Using named arguments:
# Use the .named = TRUE argument in pmap() to pass values by name.
# Provides flexibility in argument order and clarity in code.
results <- pmap(data_list, my_function, .named = TRUE, z = fixed_arg)  # Pass fixed_arg as the z argument

Additional considerations:

Partial argument specification: Pass a mix of explicit arguments and dots for flexibility.
Non-standard evaluation (NSE): Use rlang::enquo() for dynamic argument names.
Example with partial argument specification:

Code snippet
results <- pmap(data_list, my_function, y = "world", ...)  # Pass y as "wo


# calling function from string rlang in rland
```r
library(rlang)
func_name <- "mean"
arg_expr <- enquo(c(1, 2, 3))
eval(expr(!!func_name(!!arg_expr)))
```

# example solution withg key-value enquo
**While `enquo()` doesn't directly handle key-value pairs, here are effective strategies to work with them in R:**

**1. Capturing Expressions Within a Function:**

- Enquote expressions containing key-value pairs within a function:

```R
library(rlang)

my_function <- function(data, key, value) {
  key_expr <- enquo(key)
  value_expr <- enquo(value)

  # Use key_expr and value_expr to access or manipulate data
  filtered_data <- dplyr::filter(data, !!key_expr == !!value_expr)
  return(filtered_data)
}
```

**2. Using Lists for Dynamic Parameter Passing:**
## check this feature
- Create a list of key-value pairs and pass it to a function using `!!!`:

```R
params <- list(name = "Alice", age = 30)
my_function(data, !!!params)  # Equivalent to my_function(data, name = "Alice", age = 30)
```

**3. Combining NSE with String Manipulation:**

- Extract key and value strings using `quo_name()`, then construct function calls:

```R
key_string <- quo_name(key_expr)
value_string <- quo_name(value_expr)

call_expr <- expr(filter(data, !!key_string == !!value_string))
filtered_data <- eval(call_expr)
```

**4. Advanced NSE with `rlang::quos()`:**

- Capture multiple quosures and extract key-value pairs using `quos()`:

```R
params <- quos(name, age)
key_values <- map(params, quo_name)
```

**Remember:**

- `enquo()` captures expressions, not key-value pairs directly.
- Combine it with other techniques to achieve key-value functionality.
- Prioritize clarity and avoid overly complex NSE for maintainability.

**Additional Considerations:**

- For simpler cases, consider using functions with explicit named arguments.
- Explore packages like `lazyeval` or `glue` for alternative NSE approaches.


https://stackoverflow.com/questions/68272622/how-to-use-purrrpmap-to-invoke-a-user-defined-function-in-r

## Memoization with pmap
 **While pmap() doesn't have a built-in memoization feature, here are effective ways to incorporate memoization into pmap() workflows in R:**

**1. Wrapping the Function with Memoization:**

- Use a memoization wrapper function like `memoise::memoise()` to cache previous results:

```R
library(purrr)
library(memoise)

my_function <- function(x, y) {
  # Perform expensive calculations
}

mem_func <- memoise(my_function)

pmap(list(x_values, y_values), mem_func)  # Each unique combination called only once
```

**2. Creating a Memoized Version of pmap:**

- Define a custom `memoized_pmap()` function that internally caches results:

```R
memoized_pmap <. function(.l, .f, ...) {
  cache <- new.env()
  pmap(.l, function(...) {
    key <- list(...)
    cached_result <- cache[[key]]
    if (is.null(cached_result)) {
      cached_result <- .f(...)
      cache[[key]] <- cached_result
    }
    cached_result
  }, ...)
}

results <- memoized_pmap(list(x_values, y_values), my_function)
```

**3. Using Memoization Within the Function:**

- Implement memoization within the function itself if it repeatedly performs the same calculations:

```R
my_function <- function(x, y) {
  memo_cache <- new.env()
  get_or_calculate_result <- function(x, y) {
    key <- paste(x, y, sep = "_")
    cached_result <- memo_cache[[key]]
    if (is.null(cached_result)) {
      cached_result <- # Perform expensive calculations
      memo_cache[[key]] <- cached_result
    }
    cached_result
  }
  get_or_calculate_result(x, y)
}

pmap(list(x_values, y_values), my_function)
```

**Key Points:**

- Memoization can significantly improve performance when functions are called repeatedly with the same arguments.
- Choose the method that best suits your function structure and memoization needs.
- Consider the trade-offs between performance gains and memory usage when using memoization.
- If using external packages for memoization, ensure they are installed (`install.packages("memoise")`).



memoized_h1 <- memoise(h1)
memoized_g1 <- memoise(g1)
memoized_f1 <- memoise(f1)

composed_function <- function(x) {
  f1(memoized_g1(memoized_h1(x)))
}

results <- pmap(data_list, composed_function)



convert list of vectors to tibble(
as_tibble(list_of_vectors)
problem with NULL elements



