library(tidyverse, warn.conflicts = FALSE)
# add TTR, quant, do we need this?
# library(tidyquant, warn.conflicts = FALSE)
# function composition https://search.r-project.org/CRAN/refmans/gestalt/html/compose.html

base_path <- file.path("C:/Users/ronsh/eoddata")

symbol_universe_metadata <- read_csv(file.path(base_path, "list", "US_marketcap_1B_symbols.csv"), show_col_types = FALSE)

sectors <- symbol_universe_metadata |> pull(sector)|> unique()
cat("sectors: ", paste(sectors, sep=","), "\n")
symbols <- c('AAPL.US', 'MSFT.US', 'NVDA.US', 'NFLX.US', 'AMZN.US', 'META.US')


# concatenate symbols to path and apply read_csv function
# df is a list of tibbles and we want it to be indexed indexed using setNames
df <- map(file.path(base_path, "us", "daily", paste0(symbols, ".csv")), ~read_csv(., show_col_types=FALSE)) |> setNames(symbols)
