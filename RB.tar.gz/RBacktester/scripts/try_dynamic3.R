library(rlang)

# Define a function that takes a key-value pair as an expression
my_function <- function(key_expr) {
  # Evaluate the key expression and print the result
  
  x <- enquos(key_expr)
  
  y <- eval_tidy(!!key_expr)
  # print(x)
  eval_tidy(y)
  print(y)
  print(a)

#   key <- eval_tidy(quo_name(enexpr(key_expr)))
#   value <- eval_tidy(enexpr(key_expr))
  
#   print("Key:", key)
#   print("Value:", value)
#   # key <- eval_tidy(enexpr(key_expr))
  # print(key)
}

# Call the function with a key-value pair as an expression
my_function(key_expr = a:=2)
