# """ initialize constants required for backtest """
# """
# we want to add the special intent buy/sell
# we want to add the tp/sl exit based on percent
# we want to add the trailing stop/railing take profit

# only backtest features

library(logger)

backtester <- function(stratgy.st, 
                portfolio.st = NULL,
                fromdate,
                todate,
                test_fromdate,
                exchange = c('US', 'FUTURE'),
                commission = .0,
                margin = 100,
                initial_equity = 10000,
                cash_unittrade = 10000,
                drawdown_mode = DrawDownMode.drawdownAtClose,
                trade_on_close=FALSE,
                hedging=FALSE,
                exclusive_orders=FALSE) {

    # Parameters
    # ----------
    # strategy_cls - strategy constructor must
    # portfolio_strategy_cls - optional portfolio strategy (or use the default)


    self.trades = None
    self.imp_equity = None
    self.tick_size = None  # need? 0.25 for futures 0.01 for stocks
    self.cash_unittrade = cash_unittrade

    self._log.info(f"strategy {strategy_cls}")
    self._log.info(f"portflio strategy {portfolio_strategy_cls}")
    # translate class strings to classes
    # pass a class and not an object
    strategy_clazz = import_class(strategy_cls)
    self._log.debug(f"initialize strategy clazz: {strategy_clazz}")
    if not (isinstance(strategy_clazz, type) and issubclass(strategy_clazz, Strategy)):
        raise TypeError('`strategy` must be a Strategy sub-type')
    portfolio_strategy_clazz = import_class(portfolio_strategy_cls)
    self._log.debug(f"initialize portfolio strategy clazz: {portfolio_strategy_clazz}")

    # if not (isinstance(portfolio_strategy_clazz, type) and issubclass(portfolio_strategy_clazz, QVPortfolioStrategy)):
    #     raise TypeError('`strategy` must be a Strategy sub-type')

    #
    # the portfolio and strategy classes for managing the strategy built-in
    #
    self.strategy_cls = strategy_clazz
    self.portfolio_strategy_cls = portfolio_strategy_clazz

    if not isinstance(commission, Number):
        raise TypeError('`commission` must be a float value, percent of '
                        'entry order price')

    # if isinstance(ohlc, DataFrame) and np.any(ohlc.close > initial_equity):
    #     warnings.warn('Some prices are larger than initial cash value. Note that fractional '
    #                   'trading is not supported. If you want to trade Bitcoin, '
    #                   'increase initial cash, or trade μBTC or satoshis instead (GH-134).',
    #                   stacklevel=2)

    # self.slicer = timestamp_slicer(fromdate, todate)

    # slicer all for both the train and the test sets
    self.daterangeslicer = slice(fromdate, todate)
    self.testfromdate = test_fromdate

    # do we need a deep copy not to destroy the initial data?
    # self.ohlc = ohlc.loc[slicer, :]
    # self.ohlc = ohlc
    # self.strategy.use_integer_positions(integer_positions)

    self.calendar = Exchange_Calendars['US'](start=fromdate)

    # the portfolio strategy instance
    # self.portfolio_strategy = None
    self.portfolio_runner = None

    # ptimer = time.time()
    # print("run portfolio preprocess")
    # self.portfolio_strategy.preprocess()
    # print(f'preprocess finished in {time.time() - ptimer:.3f} seconds.\n')

    self.initial_equity = initial_equity

    # self.name = name if name is not None else strategy.name
    # self.progress_bar = progress_bar

    self._original_prices = None
    self._weights = None
    self._sweights = None
    self.has_run = False
    self.margin = margin
    self.equity = 0
    self.backtest_mode = BacktestMode.backtestRegular
    self.commission_mode = CommissionMode.commissionDisable
    self.commission_amount = commission
    self.drawdown_mode = drawdown_mode # DrawDownMode.drawdownAtClose
    # self.tradedirection = TradeDirection.tradeDirectionBoth
    self.fractiontrade_mode = False
    self.mode = 'individual'

    # instance
    self.runner: QVRunner = None
}

initial_split <- function(ohlcv_list, train_fromdate, test_fromdate, end_date) {

    train_slicer = timestamp_slicer(end=date)
    test_slicer = timestamp_slicer(begin=date)

    tickers_ohlc_train = [ohlc.loc[train_slicer] for ohlc in ohlc_list]
    tickers_ohlc_test = [ohlc.loc[test_slicer] for ohlc in ohlc_list]
    return tickers_ohlc_train, tickers_ohlc_test
}
 
    # @property
    # def positionsize(self):
    #     return self._positionsize

    # @positionsize.setter
    # def positionsize(self, positionsize: Series):
    #     self._positionsize = positionsize

    # @property
    # def positionsize_type(self):
    #     return self._positionsize_type

    # @positionsize_type.setter
    # def positionsize_type(self, positionsize_type: PositionSizeType):
    #     self._positionsize_type = positionsize_type

    # @property
    # def initial_equity(self):
    #     return self._initial_equity

    # @initial_equity.setter
    # def initial_equity(self, initial_equity: float):
    #     if initial_equity > 0:  # and isinstance(new_price, float):
    #         self._initial_equity = initial_equity
    #     else:
    #         raise ValueError("initialequity must be positive")

    # @property
    # def margin(self):
    #     return self._margin

    # @margin.setter
    # def margin(self, margin: int):
    #     """
    #     Account margin setting defines percentage margin requirement for entire account. The default value of
    #     Account margin is 100. This means that you have to provide 100% funds to enter the trade. Now you can
    #     simulate a margin account. When you buy on margin you are simply borrowing money from your broker to buy stock. With current regulations
    #     you can put up 50% of the purchase price of the stock you wish to buy and borrow the other half from your
    #     broker. To simulate this just enter 50 in the Account margin field. If your intial equity
    #     is set to 10000 your buying power will be then 20000 and you will be able to enter bigger positions

    #     :param margin:
    #     :return:
    #     """
    #     if margin > 0:  # and isinstance(new_price, float):
    #         self._margin = margin
    #     else:
    #         raise ValueError("margin must be positive")

    # @property
    # def commission_amount(self):
    #     return self._commission_amount

    # @commission_amount.setter
    # def commission_amount(self, amount: float):
    #     # if amount > 0:  # and isinstance(new_price, float):
    #     self._commission_amount = amount
    #     # else:
    #     #     raise ValueError("commission amount must be positive")

    # @property
    # def commission_mode(self):
    #     return self._commission_mode

    # @commission_mode.setter
    # def commission_mode(self, mode: CommissionMode):
    #     self._commission_mode = mode

    # def set_commission(self, amount: float, mode: CommissionMode):
    #     self.commission_mode = mode
    #     self.commission_amount = amount

    # @property
    # def fractiontrade_mode(self):
    #     return self._fractiontrade_mode

    # @fractiontrade_mode.setter
    # def fractiontrade_mode(self, mode: bool):
    #     self._fractiontrade_mode = mode

    # @property
    # def backtest_mode(self):
    #     return self._backtest_mode

    # @backtest_mode.setter
    # def backtest_mode(self, mode: BacktestMode):
    #     """
    #     SetBacktestMode( mode )

    #     Sets working mode of the backtester. A 'mode' parameter is one of the following backtest modes:
    #     Supported backtest modes:

    #     backtestRegular - regular, signal-based backtest, redundant signals are removed as shown in this picture
    #     backtestRegularRaw - signal-based backtest, redundant (raw) entry signals are NOT removed, only one position per symbol allowed
    #     backtestRegularRawMulti - signal-based backtest, redundant (raw) entry signals are NOT removed, MULTIPLE positions per symbol will be open if BUY/SHORT signal is true for more than one bar and there are free funds, Sell/Cover exit all open positions on given symbol, Scale-In/Out work on all open positions of given symbol at once.
    #     backtestRegularRaw2 - for custom backtester users only, the same as backtestRegularRaw, but redundant exit signals are also kept. AVOID this mode - it requires lots of memory and slows everything down.
    #     backtestRegularRaw2Multi - for custom backtester users only, same as backtestRegularRawMulti, but redundant exit signals are also kept. AVOID this mode - it requires lots of memory and slows everything down.
    #     backtestRotational - rotational trading system see this.

    #     :param backtestmode:
    #     :return:
    #     """
    #     self._backtest_mode = mode

    # def set_fractiontrade(self):
    #     self.fraction_trade = True

set_positionsize <- function(size: Union[float, Series], method: PositionSizeType) -> None:
        """
        SetPositionSize( size, method )
        RETURNS	ARRAY
        FUNCTION	This function allows to control trade (position) size in four different ways, depending on 'method' parameter.
        Parameters:

        size (ARRAY) defines desired trade size

        method (ARRAY) defines how 'size' is interpreted

        spsValue (=1) - dollar value of size (as in previous versions)
        spsPercentOfEquity (=2) - size expressed as percent of portfolio-level equity (size must be from ..100 (for regular accounts) or .1000 for margin accounts)
        spsShares (=4) - size expressed in shares/contracts (size must be > 0 )
        spsPercentOfPosition (=3) - size expressed as percent of currently open position (for SCALING IN and SCALING OUT ONLY)
        spsNoChange (=0) - don't change previously set size for given bar

        :return:
        """
        # if method == PositionSize.spsValue:
        self.positionsize_type = method
        if isinstance(size, float):
            self.positionsize = Series(size, index=self.strategy.index)
        else:
            self.positionsize = size

    def set_positionsize_risk(self, PositionRisk, TradeRisk):
        """
        PositionRisk = 1; // how much (in percent of equity) we risk in single position
        TradeRisk = 15; // trade risk in percent equals to max. loss percentage stop
        PctSize = 100 * PositionRisk / TradeRisk;
        // here TradeRisk is used to max stop loss
        ApplyStop( stopTypeLoss, stopModePercent, TradeRisk, True );
        SetPositionSize( PctSize, spsPercentOfEquity )

        :return:
        """
        PctSize = 100 * PositionRisk / TradeRisk
        self.apply_stop()
        self.set_positionsize(PctSize, PositionSizeType.spsPercentOfEquity)


    def walkforward(self, ohlc: Union[DataFrame, List[DataFrame]], *,
                    mode: str = 'individual', tf: str = 'month',
                    train_size=3, test_size=1, cross_boundary=True, **params):
        """

        for each param on the grid_params:
            run the fit (generate the signals) / problem not enough data generated
        plan: we need only to build the equity curve on the rolling training set
        execute over different parameters and scores
        """
        assert mode in ('individual', 'portfolio'), "mode: individual or portfolio"

        assert tf in ('quarter', 'month', 'week', 'day'), "timeframe not 'quarter', 'month', 'week', 'day'"

        # update the mode accordingly for analyze the results
        self.mode = mode

        assert mode in ('individual', 'portfolio'), "mode: individual or portfolio"
        # assert method in ('backtest', 'walkforward'), "method: backtest or walkforward"
        # update the mode accordingly for analyze the results

        self.mode = mode

        # in case of one ohlc (one symbol) otherwise ohlc is already a list
        ohlc_list = [ohlc] if isinstance(ohlc, DataFrame) else ohlc

        for ohlc in ohlc_list:
            if isinstance(ohlc, DataFrame) and not isinstance(ohlc.index, pd.DatetimeIndex):
                warnings.warn('Data index is not datetime. Assuming simple periods, '
                              'but `pd.DateTimeIndex` is advised.',
                              stacklevel=2)

        # slice ohlc_list by the slicer dates defined in the backtest
        # used to run the preprocess on both train and test
        ohlc_list = [ohlc.loc[self.daterangeslicer] for ohlc in ohlc_list]

        if self.mode == 'individual':
            if BacktestMode.backtestRegularRawMulti in self.backtest_mode:
                # add transaction table
                # when apply the stop rule add the transaction id
                self.strategy._add_transaction_tracking()
                pass

            # fit with parameters and runs the strategy logic
            # parameters are within the strategy_cls

            print("call portfolio strategy fit (individual)")
            self.portfolio_strategy.fit(**params)

            # build the equity and trades curves
            ptimer = time.time()
            print("run portfolio strategy equity builder")
            self.portfolio_strategy.walkforward(mode=self.mode, tf=tf, initial_equity=self.initial_equity,
                                                train_size=train_size, test_size=test_size)
            print(f'portfolio run finished in {time.time() - ptimer:.3f} seconds.\n')

            print("run portfolio strategy postprocess")
            self.portfolio_strategy.postprocess(**params)

    def train(self, universe: Dict[str, DataFrame], *,
              mode: str = 'individual',
              method: str = 'backtest',
              strategy_grid_params=None,
              **params):
        """

        Parameters
        ----------
        universe - Dict of DataFrames
        mode - individual/portfolio
        method - 'backtest'/'walkforward'
        strategy_grid_params - external startegy parameter grid
        params - add more data such as earnings reports

            cross_boundary allow train dataset to see the remainder of trades in the end of the training dataset
            True/False

        Returns
        -------

        """

        # parameter for the portfolio_strategy
        assert mode in ('individual', 'portfolio'), "mode: individual or portfolio"

        # method type of training
        assert method in ('backtest', 'walkforward'), "method: backtest or walkforward analysis"
        # update the mode accordingly for analyze the results

        self.mode = mode
        self._log.info(f"backtesting train method={method} mode={mode}")


        # in case of one ohlc (one symbol) otherwise ohlc is already a list
        # ohlc_list = [ohlc] if isinstance(ohlc, DataFrame) else ohlc

        for ohlc in universe.values():
            if isinstance(ohlc, DataFrame) and not isinstance(ohlc.index, pd.DatetimeIndex):
                warnings.warn('Data index is not datetime. Assuming simple periods, ''but `pd.DateTimeIndex` is advised.', stacklevel=2)

        # slice ohlc_list by the slicer dates defined in the backtest
        # for executing the preprocessing on both train and the test datasets
        # ohlc_list_2 = []
        # for ohlc in ohlc_list:
        #     ohlc_ = ohlc.loc[self.rangeslicer]
        #     if not ohlc_.empty:
        #         ohlc_list_2.append()
        # ohlc_list = ohlc_list_2

        # this will make a copy of a new portion of the data using daterangeslicer object
        # can we have uniform time margins?

        for ticker, ohlcv in universe.items():
            ohlcv_sliced = ohlcv.loc[self.daterangeslicer]
            if not ohlcv_sliced.empty:
                universe[ticker] = ohlcv_sliced
        # one liner version
        # universe = {ticker: ohlc.loc[self.daterangeslicer] for ticker, ohlc in universe.items() if not ohlc.loc[self.daterangeslicer].empty}

        # compute ohlc_list min/max over index?
        # ohlc_minmax_dates = [(ohlc.index.min(), ohlc.index.max()) for ohlc in ohlc_list]
        # print(ohlc_minmax_dates)

        if BacktestMode.backtestRegularRawMulti in self.backtest_mode:
            # add transaction table tracking (multi entries/multi exits)
            # when apply the stop rule add the transaction id
            self.portfolio_strategy._add_transaction_tracking()
            pass


        ptimer = time.time()

        # use two different methods in portfolio_strategy_cls
        # 1. backtest
        # 2. walkforward
        #    a. mode = individual
        #    b. mode = portfolio

        # runner host the strategy class and the portfolio class
        # self._log.debug("allocate runner AmiRunner (qvrunner")
        # check where we want mode?
        self.runner = QVRunner(self.strategy_cls,
                               self.portfolio_strategy_cls,
                               mode,
                               InitialEquity=self.initial_equity)
        # runner execute backtest
        self.runner.backtest_portfolio(universe, mode, strategy_params_grid=strategy_grid_params, **params)

        # match mode:
        #     case 'individual':
        #         self._log.debug("run strategy fit (in individual level)")
        #         if method == 'backtest':
        #             self.runner.backtest_portfolio(universe, mode, strategy_params_grid=strategy_grid_params)
        #         elif method == 'walkforward':
        #             self.runner.walkforward(universe, method=method, strategy_params_grid=strategy_grid_params)
        #     case 'portfolio':
        #         self._log.debug("run portfolio strategy fit (in portfolio level)")
        #         if method == 'backtest':
        #             self.runner.backtest_portfolio(universe, mode, strategy_params_grid=strategy_grid_params)
        #         elif method == 'walkforward':
        #             self.runner.walkforward(universe, strategy_params_grid=strategy_grid_params)

        self._log.info(f'run finished in {time.time() - ptimer:.3f} seconds.\n')

        # print("run portfolio strategy postprocess")
        # self.portfolio_strategy.postprocess(**params)

    def test(self, ohlc: Union[DataFrame, List[DataFrame]], *,
             mode: str = 'individual',
             testfromdate: str = None,
             strategy_grid_params=None,
             **params):
        """

        Parameters
        ----------
        ohlc
        mode
        params: additional params:
                    cross_boundary allow train dataset to see the remainder of trades in the end of the training dataset
                    True/False

        Returns
        -------

        """
        assert mode in ('individual', 'portfolio'), "mode: individual or portfolio"

        # update the mode accordingly for analyze the results

        self.mode = mode

        testfromdate = self.testfromdate if testfromdate is None else testfromdate

        ohlc_train_list, ohlc_test_list = self.set_traintest_split(ohlc_list, self.testfromdate)

        # in case of one ohlc (one symbol) otherwise ohlc is already a list
        ohlc_list = [ohlc] if isinstance(ohlc, DataFrame) else ohlc

        for ohlc in ohlc_list:
            if isinstance(ohlc, DataFrame) and not isinstance(ohlc.index, pd.DatetimeIndex):
                warnings.warn('Data index is not datetime. Assuming simple periods, '
                              'but `pd.DateTimeIndex` is advised.',
                              stacklevel=2)

        # slice ohlc_list by the slicer dates defined in the backtest
        ohlc_list = [ohlc.loc[self.daterangeslicer] for ohlc in ohlc_list]

        # compute ohlc_list min/max
        # ohlc_minmax_dates = [(ohlc.index.min(), ohlc.index.max()) for ohlc in ohlc_list]
        # print(ohlc_minmax_dates)

        ohlc_idx_min, ohlc_idx_max = minmax_tuples(((ohlc.index.min(), ohlc.index.max()) for ohlc in ohlc_list))

        # crate a walkforward

        # we need the train/test split here before passing to protfolio_strategy
        if validation == 'backtest' and self.testfromdate:
            tickers_ohlc_train, tickers_ohlc_test = self.set_traintest_split(ohlc_list, self.testfromdate)

        elif validation == 'walkforward':
            dates_ = DataFrame(0, columns=['close'], index=pd.date_range(ohlc_idx_min, ohlc_idx_max))
            dates_.ta.monthseq(append=True, col_names=('seq',))

        if BacktestMode.backtestRegularRawMulti in self.backtest_mode:
            # add transaction table
            # when apply the stop rule add the transaction id
            self.portfolio_strategy._add_transaction_tracking()
            pass

        # portfolio strategy instance is constructed from its class
        self.portfolio_strategy = self.portfolio_strategy_cls(self.strategy_cls,
                                                              mode=self.mode,
                                                              initialequity=self.initial_equity)
        print(vars(self.portfolio_strategy))

        # fit with parameters and runs the strategy logic
        # parameters are within the strategy_cls

        # PreprocessStrategy(self.portfolio_strategy)
        # portfolio_strategy = self.portfolio_strategy()
        print("run portfolio strategy fit (in portfolio level")

        # might need to enable the grid search for portfolio fit
        # using the portfolio estimator
        # portfolio_grid = GridSearchCV(self.portfolio_strategy, self.portfolio_strategy.grid_param)

        # build the equity and trade curves for each ohlc
        print("run portfolio strategy equity builder")
        ptimer = time.time()

        self.portfolio_strategy.fit(ohlc_list, method=validation, strategy_params_grid=strategy_grid_params)

        print(f'portfolio run finished in {time.time() - ptimer:.3f} seconds.\n')

        # print("run portfolio strategy postprocess")
        # self.portfolio_strategy.postprocess(**params)

    def analyze_results(self, rfr: float = 0., plot=False):
        """
            Analyze trades

        Parameters
        ----------
        rfr : fix rate
        plot

        Returns
        -------

        """

        print("analyze trades/daily returns")
        print("--------------")
        # was the dataframe
        trades = self.trades
        print("trades:\n", trades)

        total_ret = trades.equity[-1] / trades.equity[0] - 1
        self.stats['total_ret'] = round_(total_ret, 3)
        t_short = len(trades[trades.direction == 'short'])
        t_long = len(trades[trades.direction == 'buy'])
        pt_count = len(trades[trades.value > 0])
        pt_short = len(trades[(trades.value > 0) & (trades.direction == 'cover')])
        pt_long = len(trades[(trades.value > 0) & (trades.direction == 'sell')])
        total_trades = t_long + t_short

        print(self.symbol)
        print('Starting Equity: ' + str(trades['equity'][0]))
        print('Final Equity: ' + str(trades['equity'][-1]))
        print('Total return: {}'.format(float(total_ret)))
        print('Profitable trades: ' + str(int(pt_count)))
        print('Losing trades: {}'.format(total_trades - pt_count))
        print('Total trades: {}'.format(total_trades))

        if total_trades > 0:
            winners = pt_count / total_trades * 100
            print('Winrate: ' + str(round_(winners, 2)) + '%')
        else:
            print('No trades made')

        if t_short > 0:
            print('Short winrate: ' + str(round_(pt_short / t_short * 100, 2)) + '%')
        if t_long > 0:
            print('Long winrate: ' + str(round_(pt_long / t_long * 100, 2)) + '%')

        temp = trades.equity.resample('1D').last().dropna()
        temp.name = self.symbol
        print("temp:\n", temp)
        idx = self.ohlc.close.resample('1D').last().index
        # print(idx)
        # sys.exit()
        equity = pd.DataFrame(temp, index=idx).fillna(method='ffill').fillna(method='bfill')
        print("equity temp:\n", temp)
        daily_ret = equity[self.symbol].pct_change()

        self.stats['symbol'] = self.symbol
        self.stats['daily_return'] = round_(daily_ret.mean(), 4)
        self.stats['daily_risk'] = round_(daily_ret.std(), 4)
        daily_excess = daily_ret - rfr / 252
        sharpe = 252 ** 0.5 * daily_excess.mean() / daily_excess.std()
        self.stats['sharpe'] = round_(sharpe, 3)
        sortino = 252 ** 0.5 * daily_excess.mean() / daily_excess[daily_excess < 0].std()
        self.stats['sortino'] = round_(sortino, 3)
        period = (self.ohlc.index[-1] - self.ohlc.index[0]).total_seconds() / (31557600)
        cagr = (trades.equity.values[-1] / trades.equity.values[0]) ** (1 / float(period)) - 1
        self.stats['cagr'] = round_(cagr, 3)
        tval = trades.value.values
        pfr = tval[tval > 0].sum() / max(abs(tval[tval < 0].sum()), 1)
        self.stats['pfr'] = round_(pfr, 3)
        maxdd = _max_draw(trades.equity.sort_index())
        closs = _consecutive_loss(trades.equity.sort_index())
        self.stats['maxdd'] = round_(maxdd, 3)

        print('Daily return: {}'.format(float(daily_ret.mean())))
        print('Risk: {}'.format(float(daily_ret.std())))
        print('Sharpe: {:.2f} '.format(float(sharpe)))
        print('Sortino: {:.2f} '.format(float(sortino)))
        print('CAGR: {}'.format(float(cagr)))
        print('Profit factor: {:.2f}'.format(pfr))
        print('Consecutive losses: ' + str(closs))
        print('Max drawdown: {}'.format(float(maxdd)))
        print('\n')

        if plot:
            new_equity = trades.equity[(trades.equity != trades.equity.shift(1))]
            rolling_dd = new_equity.rolling(min_periods=1, window=2,
                                            center=False).apply(func=_max_rolling_dd)

            zipp = list(zip(new_equity, rolling_dd))
            df1 = pd.DataFrame(zipp, index=new_equity.index)
            df1.columns = ['Equity', 'Drawdown']

            fig = plt.figure()
            ax1 = fig.add_subplot(211)
            df1.plot(ax=ax1)
            ax1.set_ylabel('Portfolio value (USD)')
            ax1.set_xlabel('')
            plt.gcf().set_size_inches(12, 15)
            plt.show()
            plt.close()

    def amirun(self):
        # idx = buy.index
        ohlc = self.ohlc
        bt = self.strategy.bt
        strategy = self.strategy
        buy = strategy.Buy
        short = strategy.Short
        sell = strategy.Sell
        cover = strategy.Cover
        buyprice = strategy.BuyPrice
        shortprice = strategy.ShortPrice
        sellprice = strategy.SellPrice
        coverprice = strategy.CoverPrice

        myeq = self.initial_equity
        myequity = np.empty(len(buy))
        imp_equity = np.empty(len(buy))
        imargin = np.zeros(len(buy))
        myequity.fill(myeq)
        imp_equity.fill(myeq)
        mytrades = []
        mvalue = np.zeros(1, dtype='float64')

        keys = ['buy', 'sell', 'short', 'cover']
        keys += [f'{o}price' for o in keys]
        openum = IntEnum("Op", keys, start=0)

        margin_required = 100.0 / self.margin
        # margin_required is the account leverage
        leverage = margin_required

        if self.positionsize_type == PositionSize.spsShares:
            buy_lotsize = short_lotsize = self.positionsize
        if self.positionsize_type == PositionSize.spsValue:
            buy_lotsize = self.positionsize / buyprice
            short_lotsize = self.positionsize / shortprice

        for i, item in enumerate(zip(buy.values, short.values, sell.values, cover.values,
                                     buyprice.values, shortprice.values, sellprice.values, coverprice.values)):

            if item[openum.short.value] > 0:  # *** active short *** #

                # if self.risk == 0.0:
                #     lotsize= 1
                #     used_margin = self.margin_required  # used margin
                #     if self.margin_required == 0:
                #         used_margin = _open[i]
                # elif self.margin_required == 0:
                #     lotsize= int(myequity[i] / _open[i] * self.risk)
                #     used_margin = _open[i] * lot_size
                # else:
                #     lotsize= int(myequity[i] / margin_required * self.risk)
                #     used_margin = lotsize* margin_required
                #
                # if lotsize< 0 or myequity[i] < 0:
                #     continue
                #
                # imargin[i] = imargin[i] + used_margin
                # imp_equity[i] = myequity[i]
                # loceq = myequity[i]

                mytrades.append({'index': short.index[i], 'direction': 'short',
                                 'lotsize': -lot_size, 'price': shortprice[i],
                                 'value': 0, 'equity': myequity[i], 'ticks': 0,
                                 'umargin': used_margin})

                # with count we generate a new counter starting at 0 with step=1
                for cnt, col1, col2, col3 in zip(itertools.count(),
                                                 cover.values[i + 1:], coverprice.values[i + 1:], buy.values[i + 1:]):

                    trd_ticks = (item[5] - col2) / self.tick_size
                    commission = self.commission * lot_size
                    trade_value = (trd_ticks * self.tick_value * lot_size) - commission
                    imp_equity[cnt + i + 1] = loceq + trade_value
                    imargin[cnt + i + 1] = imargin[cnt + i]

                    if (col1 == item[1]) | (col3 > 0):

                        if self.risk == 0.0:
                            lotsize = 1
                        elif self.margin_required == 0:
                            lotsize = int(myequity[i] / _open[i] * self.risk)
                        else:
                            lotsize = int(myequity[i] / self.margin_required * self.risk)

                        mvalue = np.append(mvalue, trade_value)

                        value = myeq + np.sum(mvalue)
                        myequity[cnt + i + 1:] = value
                        imp_equity[cnt + i + 1:] = value
                        imargin[cnt + i + 1] = 0

                        mytrades.append({'index': cover.index[cnt + i + 1], 'direction': 'cover',
                                         'lotsize': lot_size, 'price': coverprice[cnt + i + 1],
                                         'value': trade_value, 'equity': value, 'ticks': trd_ticks,
                                         'umargin': 0})

                        break

            elif item[openum.buy.value] > 0:  # *** active long *** #

                # if self.risk == 0.0:
                #     lotsize= 1
                #     used_margin = self.margin_required  # used margin
                #     if self.margin_required == 0:
                #         used_margin = _open[i]
                # elif self.margin_required == 0:
                #     lotsize= int(myequity[i] / _open[i] * self.risk)
                #     used_margin = _open[i] * lot_size
                # else:
                #     lotsize= int(myequity[i] / self.margin_required * self.risk)
                #     used_margin = lotsize* self.margin_required
                #
                # if lotsize< 0 or myequity[i] < 0:
                #     continue
                #
                imargin[i] = imargin[i] + used_margin
                imp_equity[i] = myequity[i]
                loceq = myequity[i]

                mytrades.append({'index': buy.index[i], 'direction': 'buy',
                                 'lotsize': buy_lotsize, 'price': buyprice[i],
                                 'value': 0, 'equity': myequity[i], 'ticks': 0,
                                 'umargin': used_margin})

                for cnt, col1, col2, col3 in zip(itertools.count(), sell.values[i + 1:],
                                                 sellprice.values[i + 1:], short.values[i + 1:]):

                    trd_ticks = (col2 - item[openum.buyprice.value]) / self.tick_size
                    commission = self.commission * buy_lotsize
                    trade_value = (trd_ticks * self.tick_value * buy_lotsize) - commission
                    imp_equity[cnt + i + 1] = loceq + trade_value
                    imargin[cnt + i + 1] = imargin[cnt + i]

                    if (col1 > 0) | (col3 > 0):
                        # if self.risk == 0.0:
                        #     lotsize= 1
                        # elif self.margin_required == 0:
                        #     lotsize= int(myequity[i] / _open[i] * self.risk)
                        # else:
                        #     lotsize= int(myequity[i] / self.margin_required * self.risk)

                        mvalue = np.append(mvalue, trade_value)

                        value = myeq + np.sum(mvalue)
                        myequity[cnt + i + 1:] = value
                        imp_equity[cnt + i + 1:] = value
                        imargin[cnt + i + 1] = 0

                        mytrades.append({'index': sell.index[cnt + i + 1], 'direction': 'sell',
                                         'lotsize': -lot_size, 'price': sellprice[cnt + i + 1],
                                         'value': trade_value, 'equity': value, 'ticks': trd_ticks,
                                         'umargin': 0})

                        break

        mytrades = pd.DataFrame(mytrades).dropna()
        mytrades.set_index('index', drop=True, append=False, inplace=True, verify_integrity=False)
        mytrades.index = pd.to_datetime(mytrades.index)
        mytrades['symbol'] = self.symbol
        mytrades = mytrades[:][['symbol', 'direction', 'lotsize', 'price',
                                'value', 'equity', 'ticks', 'umargin']]
        mytrades = mytrades.sort_index()
        self.trades = mytrades
        self.imp_equity = imp_equity
        self.equity = myequity
        self.margin = imargin
        # mytrades.to_csv('trades.csv')

    def analyze_results_silent(self, rfr):
        ''' analyze trades '''
        trades = self.trades
        total_return = trades.equity[-1] / trades.equity[0] - 1

        self.stats['total_return'] = round(total_return, 3)
        temp = trades.equity.resample('1D').last().dropna()
        temp.name = self.symbol
        idx = self.ohlc.close.resample('1D').last().index
        equity = pd.DataFrame(temp, index=idx).fillna(method='ffill').fillna(method='bfill')
        daily_ret = equity[self.symbol].pct_change()

        self.stats['symbol'] = self.symbol
        self.stats['daily_return'] = round(daily_ret.mean(), 4)
        self.stats['daily_risk'] = round(daily_ret.std(), 4)
        daily_excess = daily_ret - rfr / 252
        sharpe = 252 ** 0.5 * daily_excess.mean() / daily_excess.std()
        self.stats['sharpe ratio'] = round(sharpe, 3)
        sortino = 252 ** 0.5 * daily_excess.mean() / daily_excess[daily_excess < 0].std()
        self.stats['sortino ratio'] = round(sortino, 3)
        period = (self.ohlc.index[-1] - self.ohlc.index[0]).total_seconds() / (31557600)
        cagr = (trades.equity.values[-1] / trades.equity.values[0]) ** (1 / float(period)) - 1
        self.stats['cagr'] = round(cagr, 3)
        tval = trades.value.values
        pfr = tval[tval > 0].sum() / max(abs(tval[tval < 0].sum()), 1)
        self.stats['pfr'] = round(pfr, 3)
        maxdd = max_draw(trades.equity.sort_index())
        self.stats['maxdd'] = round(maxdd, 3)

    def analyze_results(self, rfr, plot=True):
        ''' analyze trades '''
        trades = self.trades
        total_ret = trades.equity[-1] / trades.equity[0] - 1
        self.stats['total_ret'] = round(total_ret, 3)
        t_short = len(trades[trades.direction == 'short'])
        t_long = len(trades[trades.direction == 'buy'])
        pt_count = len(trades[trades.value > 0])
        pt_short = len(trades[(trades.value > 0) & (trades.direction == 'cover')])
        pt_long = len(trades[(trades.value > 0) & (trades.direction == 'sell')])
        total_trades = t_long + t_short

        print(self.symbol)
        print('Starting Equity: ' + str(trades['equity'][0]))
        print('Final Equity: ' + str(trades['equity'][-1]))
        print('Total return: {:.2%} '.format(float(total_ret)))
        print('Profitable trades: ' + str(int(pt_count)))
        print('Losing trades: ' + str(int(total_trades - pt_count)))

        if total_trades > 0:
            winners = pt_count / total_trades * 100
            print('Winrate: ' + str(round(winners, 2)) + '%')
        else:
            print('No trades made')

        if t_short > 0:
            print('Short winrate: ' + str(round(pt_short / t_short * 100, 2)) + '%')
        if t_long > 0:
            print('Long winrate: ' + str(round(pt_long / t_long * 100, 2)) + '%')

        temp = trades.equity.resample('1D').last().dropna()
        temp.name = self.symbol
        idx = self.ohlc.close.resample('1D').last().index
        equity = pd.DataFrame(temp, index=idx).fillna(method='ffill').fillna(method='bfill')
        daily_ret = equity[self.symbol].pct_change()

        self.stats['symbol'] = self.symbol
        self.stats['daily_return'] = round(daily_ret.mean(), 4)
        self.stats['daily_risk'] = round(daily_ret.std(), 4)
        daily_excess = daily_ret - rfr / 252
        sharpe = 252 ** 0.5 * daily_excess.mean() / daily_excess.std()
        self.stats['sharpe'] = round(sharpe, 3)
        sortino = 252 ** 0.5 * daily_excess.mean() / daily_excess[daily_excess < 0].std()
        self.stats['sortino'] = round(sortino, 3)
        period = (self.ohlc.index[-1] - self.ohlc.index[0]).total_seconds() / (31557600)
        cagr = (trades.equity.values[-1] / trades.equity.values[0]) ** (1 / float(period)) - 1
        self.stats['cagr'] = round(cagr, 3)
        tval = trades.value.values
        pfr = tval[tval > 0].sum() / max(abs(tval[tval < 0].sum()), 1)
        self.stats['pfr'] = round(pfr, 3)
        maxdd = _max_draw(trades.equity.sort_index())
        closs = _consecutive_loss(trades.equity.sort_index())
        self.stats['maxdd'] = round(maxdd, 3)

        print('Daily return: {:.2%} '.format(float(daily_ret.mean())))
        print('Risk: {:.2%} '.format(float(daily_ret.std())))
        print('Sharpe: {:.2f} '.format(float(sharpe)))
        print('Sortino: {:.2f} '.format(float(sortino)))
        print('CAGR: {:.2%} '.format(float(cagr)))
        print('Profit factor: {:.2f}'.format(pfr))
        print('Consecutive losses: ' + str(closs))
        print('Max drawdown: {:.2%} '.format(float(maxdd)))
        print('\n')

        if plot:
            new_equity = trades.equity[(trades.equity != trades.equity.shift(1))]
            rolling_dd = new_equity.rolling(min_periods=1, window=2,
                                            center=False).apply(func=_max_rolling_dd)

            zipp = list(zip(new_equity, rolling_dd))
            df1 = pd.DataFrame(zipp, index=new_equity.index)
            df1.columns = ['Equity', 'Drawdown']

            fig = plt.figure()
            ax1 = fig.add_subplot(211)
            df1.plot(ax=ax1)
            ax1.set_ylabel('Portfolio value (USD)')
            ax1.set_xlabel('')
            plt.gcf().set_size_inches(12, 15)
            plt.show()
            plt.close()

    def plot_trades(self, startdate, enddate):
        ''' plot trades '''
        tlen = len(self.trades)
        if tlen > 0:
            trd = self.trades
            subset = slice(str(startdate), str(enddate))
            frm = trd.ix[subset]

            lent = frm.price[(frm.direction == 'buy') & (frm.lotsize > 0)]
            sent = frm.price[(frm.direction == 'short') & (frm.lotsize < 0)]
            lex = frm.price[(frm.direction == 'sell') & (frm.lotsize < 0)]
            sex = frm.price[(frm.direction == 'cover') & (frm.lotsize > 0)]

            fig = plt.figure()
            ax1 = fig.add_subplot(212)
            plt.gcf().set_size_inches(12, 15)
            ax1.set_ylabel('')
            ax1.set_xlabel('')

            if len(lent) > 0:
                pylab.plot(lent.index, lent.values, '^', color='lime', markersize=12,
                           label='long enter')
            if len(sent) > 0:
                pylab.plot(sent.index, sent.values, 'v', color='red', markersize=12,
                           label='short enter')
            if len(lex) > 0:
                pylab.plot(lex.index, lex.values, 'o', color='lime', markersize=7,
                           label='long exit')
            if len(sex) > 0:
                pylab.plot(sex.index, sex.values, 'o', color='red', markersize=7,
                           label='short exit')

            temp = pd.DataFrame(self.ohlc.open.ix[subset])
            temp.columns = [self.symbol + ' Trades']
            temp.plot(ax=ax1, color='black')
            plt.show()
            plt.close()

            fig = plt.figure()
            ax1 = fig.add_subplot(212)
            plt.gcf().set_size_inches(12, 15)
            ax1.set_ylabel('')
            ax1.set_xlabel('')
            eqt = pd.DataFrame(self.trades.ticks[subset].cumsum() * self.tick_size)
            eqt.columns = ['value']
            idx = eqt.index
            (eqt + self.ohlc.open[idx[0]]).plot(ax=ax1, color='red', style='-', label='value')
            self.ohlc.close.ix[subset].plot(ax=ax1, color='black', label='price')
            plt.show()
            plt.close()
        else:
            print('No trades to plot!')

    def annual_gains(self):
        ''' calculate annual gains '''
        gains = []
        years = []

        equity = self.equity.resample('1D').last().dropna()

        start, end = equity.index[0].year, equity.index[-1].year
        # print (equity[str(start)])
        # print (equity[str(end)])

        # temp.name = 'equity'
        # idx = self.ohlc.close.resample('1D').last().index
        # equity = pd.DataFrame(temp, index=idx).fillna(method='ffill').fillna(method='bfill')

        for i in range(start, end + 1, 1):
            gain = (equity[str(i)][-1] - equity[str(i)][0]) / equity[str(i)][0]
            gains.append(gain * 100)
            years.append(i)

        # if self.trades.lotsize.abs().mean() == 1:
        #     for i in range(start, end + 1, 1):
        #         gain = (equity[str(i)].equity[-1] - \
        #                 equity[str(i)].equity[0]) / equity.equity[0]
        #         gains.append(gain * 100)
        #         years.append(i)
        # else:
        #     for i in range(start, end + 1, 1):
        #         gain = (equity[str(i)].equity[-1] - \
        #                 equity[str(i)].equity[0]) / equity[str(i)].equity[0]
        #         gains.append(gain * 100)
        #         years.append(i)

        zipp = list(zip(gains, years))
        df1 = pd.DataFrame(zipp)
        df1.columns = ['gains', 'years']
        print(df1)
        # fig = plt.figure()
        # ax1 = fig.add_subplot(212)
        # df1.plot(x='years', y='gains', ax=ax1, kind='bar', color='green')
        # ax1.set_ylabel('Annual Returns (%)')
        # ax1.set_xlabel('')
        # plt.gcf().set_size_inches(12, 15)
        # plt.show()
        # plt.close()

    def analyze_results_ffn(self, benchmark_rate: float = 0.01):
        """
        analyze performance with ffn
            Benchmark rate is assumed to be annualized. Adjusted according for the
            number of periods per year seen in the data.

        """

        if self.mode == 'individual':
            # go over Strategies which are a strategy running on different stocks
            equities_ = [x.EquityTicker for x in self.portfolio_strategy.Strategies]
            # print(concat(equities, axis=1))

        if len(equities_) == 1:
            equities = equities_[0]
        else:
            equities = concat(equities_, axis=1)
        # equity = self.portfolio_strategy.Equity
        # print ("backtest equity: ", equities)
        # if equities is None:
        #     return
        # equity = equities.resample('1D').last().dropna()
        # data.name = self.symbol
        # idx = self.ohlc.close.resample('1D').last().index
        # equity = pd.DataFrame(data, index=idx).fillna(method='ffill').fillna(method='bfill')

        print("equity in ffn:\n", equities)
        ffn_ = ffn.calc_stats(equities)
        # ffn_ = PerformanceStats(equity, rfr)
        print('\n')
        ffn_.display()
        # access to stats series ffn_.stats
        print('\n')

        # display monthly returns
        for symbol in equities.columns:
            print(symbol)
            ffn_[symbol].display_monthly_returns()
            print("\n")

    def showbt(self):
        if self.mode == 'individual':
            summaries = [get_targets(x) for x in self.portfolio_strategy.Strategies]
            print(summaries)
