source("strategies/R6MTRStrategies.R")

train_df <- df
m <- MTRSStrategy56$new()
# check how to perform static method better
new_df <- map(train_df, ~ m$preprocess(.))
print(new_df$AAPL.US)
# stop()
strategy <- MTRSStrategy56$new()  # create an instance
strategy$fit(ohlcv=new_df$AAPL.US)


# lapply(new_df, ~ { 
#     strategy <- MTRSStrategy56$new()  # create an instance
#     strategy$fit()
#     }
# )