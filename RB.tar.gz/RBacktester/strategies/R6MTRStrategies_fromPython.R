


# class MTRSStrategy56(QVStrategy):
#     """
#         Idea:
#         RSI(5) cross over the zero line (tesing)
#     """
#     # class attributes
#     copy = False
#     deep = False

#     # derived class
#     # see https://stackoverflow.com/questions/28399131/how-can-i-simply-pass-arguments-to-parent-constructor-in-child-class


# the strategy grid search parameters
# https://www.r-bloggers.com/2016/12/grid-search-in-the-tidyverse/
params_grid_ <- list(
    ProfitTargetPercent=seq(2, 5, 0.5),
    HoldDays=seq(3, 5)
    # "OffsetBuyPercent": pybt.npFloatRange(0.05, 0.1, 0.01)
)
# grid is created by cross product
params_grid |> cross_d() 

MTRSStrategy56 <- R6Class("MTRSStrategy56", inherit= R6Strategy,
    preprocess = function(ohlcv, ...) { 
        invisible(self)
    },
    fit = function(ohclv, 
                   ProfitTargetPercent=3,
                   HoldDays=3,
                   OffsetBuyPercent=0.2,
                   ...),
    

)


# fit is inline function definition
# by passing the strategy and attaching a FUN which is described below
add.fit(st, FUN=function(ohlcv,
                    ProfitTargetPercent=3,
                    HoldDays=3,
                    OffsetBuyPercent=0.06,
                    ...) {
        # FUN implementation code
        # self.log.debug(f"{get_clazzname(self)} fit_ {self.get_params(deep=False)}")
        rsi <- ohlcv['RSI_5']
        # print (rsi)

        # initialize the buy/sell signal
        st$ = ta.cross_value(rsi, 50, above=True, asint=False)
        # print(concat([self.Buy, rsi], axis=1))
        # sys.exit()
        # reverse
        # self.Sell = ta.cross_value(rsi, 50, above=False, asint=False)
        # self.set_tradeordermode(ohlcv, mode=OrderMode.orderThisBarClose)
        self.set_tradeordermode(ohlcv, mode=OrderMode.orderNextBarOpen)
        # print(concat([self.Buy, rsi], axis=1))
        # sys.exit()

        # initialize tradedirection
        self.set_tradedirection(TradeDirection$tradeDirectionLong)

        # exrem  - set max concurrent trades allowed
        # self.set_exrem_maxtrades()

        # ProfitTarget = fit_params.pop("ProfitTarget", 3)
        # HoldDays = fit_params.pop("HoldDays", 4)
        ProfitTargetPercent = self.ProfitTargetPercent
        HoldDays = self.HoldDays

        # apply various stops
        # in this example, profit target in percentage or exit by number of bars whichever occurs first
        # apply stop must appear in bartrade column
        # while other logic exit are in sell column
        self.applystop(ohlcv, StopType.stopTypeProfit, StopMode.stopModePercent, ProfitTargetPercent)
        self.applystop(ohlcv, StopType.stopTypeNBar, StopMode.stopModeBars, HoldDays)
        NULL
}

add.postprocess(strategy) {
    # """ train ML
    #     we evaluate the equity curve and and the trade list
    #     trade list (dollar or percentage) serves as the target variable for machine learning
    # """
    NULL
}
