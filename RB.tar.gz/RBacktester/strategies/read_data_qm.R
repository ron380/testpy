library(tidyquant)

df <- tq_get("QQQ", get="yahoo", from="2000-01-01", to=Sys.Date())


# signal condition
df["dirr"] <- df$close > df$open & df$low > shift(df$low, 1) # green bar and low is up than previous bar
