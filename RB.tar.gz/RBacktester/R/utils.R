# helper utils function for the package

# ref:
# https://stackoverflow.com/questions/33838392/enum-like-arguments-in-r

# makeEnum <- function(inputList) {
#     myEnum <- as.list(inputList)
#     enumNames <- names(myEnum)
#     if (is.null(enumNames)) {
#         names(myEnum) <- myEnum
#     } else if ("" %in% enumNames) {
#         stop("The inputList has some but not all names assigned. They must be all assigned or none assigned")
#     }
#     return(myEnum)
# }


# Defs (enum) and named lists

# makeEnum <- function(inputList) {
#     myEnum <- as.list(inputList)
#     enumNames <- names(myEnum)
#     if (is.null(enumNames)) {
#         names(myEnum) <- myEnum
#     } else if ("" %in% enumNames) {
#         stop("The inputList has some but not all names assigned. They must be all assigned or none assigned")
#     }
#     return(myEnum)
# }


# Create an environment with a specific name
create_environment <- function(env_name) {
  new_env <- new.env()
  assign(env_name, new_env, envir = .GlobalEnv)
  return(new_env)
}

# see mvbutils package
extract.named <- function (x, to = parent.frame()) 
{
    n <- names(x)
    for (i in n[nchar(n) > 0]) assign(i, x[[i]], envir = to)
}

# cat display string while print display data object
printf <- function(...) cat(sprintf(...))

shift <- function(x, ...) UseMethod("shift")
# shift forward
# https://stackoverflow.com/questions/26997586/shifting-a-vector
# for vector we use double typeof(c(...))
shift.double <- function(x, n, fill_value=NA) c(rep(fill_value, times=n), x[1:(length(x)-n)])

# ref: https://stackoverflow.com/questions/22104774/how-to-initialize-a-vector-with-fixed-length-in-r
# ref: https://www.geeksforgeeks.org/how-to-create-a-vector-of-specific-type-and-length-in-r/
empty.vector_like <- function(x, mode = NULL) as.vector(character(length(x)), mode = ifelse(is.null(mode), storage.mode(x), mode))
# ref: 
empty.vector <- function(n, mode="double") as.vector(character(n), mode = mode)

# faster directly using atomic modes logical,integer, numeric, synonym double
# this vector initialized by 0
empty_vector <- function(n, mode="double") vector(mode=mode, length=n)
# best allocate vector of double with initialization value
empty_vector_NA <- function(n, mode="double") {
    v <- empty_vector(n, mode)
    v[] <- NA
    return(v)
}


allNA <- function(x) all(is.na(x))

last.double <- function(x, k=-1) x[length(x) + k + 1]


# less operator
less <- function(x, y) UseMethod("less")

less.numeric <- function(x, y) x < y

less.tuple <- function(x, y) x[1] < y[1] || x[2] < y[2]


# safe bool
safe_true <- function(x) ifelse(is.na(x), FALSE, x == TRUE)

# or use %ge%, %le% from extraoperators
operator.le <- function(x, y) x <= y
operator.ge <- function(x, y) x >= y

# check Lag in Hmisc package
lag <- function(x, shift = 1) {
    N <- length(x)
    if (shift == 0)
        return(x)
    
    # initialize with the same type as x initialize with NA
    ret <- as.vector(character(N), mode = storage.mode(x))
    # attrib <- attributes(x)
    # if (length(attrib$label)) 
    #     attrib$label <- paste(attrib$label, "lagged", shift, 
    #         "observations")
    if (abs(shift) < N) {
        if (shift > 0)
            ret[-(1:shift)] <- x[1:(N - shift)]
        else 
            ret[1:(N + shift)] <- x[(1 - shift):N]
    }
    # attributes(ret) <- attrib
    return(ret)
}


# first nonzero element of a vector
first_nz <- function(x) UseMethod("first_nz")

first_nz.integer <- function(x) {
    stopifnot(is.vector(x))

    idx <- NA
    N <- length(x)
    i <- 1L
    while (i <= N) {
        if (x[i] != 0L) {
            idx <- i
            break
        }
        i <- i + 1
    }
    return(idx)
}

first_nz.logical <- function(x) {
    stopifnot(is.vector(x))

    idx <- NA
    N <- length(x)
    i <- 1L
    while (i <= N) {
        if (x[i]) {
            idx <- i
            break
        }
        i <- i + 1
    }
    return(idx)
}

last_nz <- function(x) UseMethod("last_nz")
last_nz.integer <- function(x) {
    stopifnot(is.vector(x))

    idx <- NA
    N <- length(x)
    i <- N
    while (i >= 1L) {
        if (x[i] != 0) {
            idx <- i
            break
        }
        i <- i - 1
    }
    
    return(idx)
}

#' @export 
get_series <- function(X, name) {
    series <- X[name]
    attr(series, "name") <- name
    series
}


# Using ifelse for log protection
log.0 <- function(x) ifelse(x == 0, 0, log(x))
log2.0 <- function(x) ifelse(x == 0, 0, log2(x))


# learn how condition is passed for example in dplyr filter
#' @export
filter_nrows_cond <- function(df, cond, n=5) {


    # Find the row indices where the condition is met
    indices <- which(cond)
    # Define the range of rows to show, including the previous n rows
    rows_to_show <- max(1, min(indices) - n):max(indices)
    # Filter rows based on the condition and select the specified rows
    result <- df |> slice(rows_to_show)

    # Print the resulting tibble
    result
}


getfun <- function(x) {
    if (length(grep("::", x)) > 0) {
        parts <- strsplit(x, "::")[[1]]
        getFromNamespace(parts[2], parts[1])
    } else {
        x
    }
}
