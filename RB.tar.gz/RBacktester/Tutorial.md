# reference python project qvbacktester in Dropbox


# works with composite functions
try_dynamic1.R


# running the strategy
strategies\R6MTRStratgies.R


# flow for running
source("strategies/run_strategy_flow.R")
devtools::load_all(".")



# read the data
c('AAPL.US', 'MSFT.US', 'NVDA.US', 'NFLX.US', 'AMZN.US', 'META.US')