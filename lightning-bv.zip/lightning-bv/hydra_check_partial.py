import numpy as np
import nibabel as nib
import hydra
from omegaconf import DictConfig, OmegaConf
import os
import sys
from typing import Optional


@hydra.main(config_path="configs/", config_name="config.yaml")
def main(config: DictConfig) -> Optional[float]:
    """Contains the training pipeline. Can additionally evaluate model on a testset, using best
    weights achieved during training.

    Args:
        config (DictConfig): Configuration composed by Hydra.

    Returns:
        Optional[float]: Metric score for hyperparameter optimization.
    """

    print(OmegaConf.to_yaml(config))



if __name__ == '__main__':
    main()