A _Config Group_ is a named group with a set of valid options. 
we want to support one option in the group but with possibility to change between options

Example
db |
   |- mysql.yaml
   |- postgresql.yaml

Selecting a non-existent config option generates an error message with the valid options.

You can add a Default List to your config file. A Defaults List is a list telling Hydra how to compose the final config object. By convention, it is the first item in the config.
so in config.yaml
    defaults:
        -db: mysql # what's under db in the hierarchy

db/mysql.yaml
    driver: mysql
    user: aa

will give:
    db:
        driver: mysql


different files with choice option is suitable for to `OR` configuration.

## Packages
The package determines where the content of each input config is placed in the output config. The default package of an input config is derived from its Config Group. e.g. The default package of server/db/mysql.yaml is server.db.

The default package can be overridden in the Defaults List or via a Package Directive at the top of the config file. Changing the package of a config can be useful when using a config from another library, or when using the same config group twice in the same app.

The priority for determining the final package for a config is as follows:

The package specified in the Defaults List (relative to the package of the including config)
The package specified in the Package Directive (absolute)
The default package


# inheritence


```yaml
# we have two files in the same directory named callback
- default.yaml (base)
- more_conf.yaml  


more_conf.yaml:
# first in line we inherit default.yaml, then expand
defaults:
  - default.yaml

watch_model:
  _target_: src.callbacks.wandb_callbacks.WatchModel
  log: "all"
  log_freq: 100

upload_code_as_artifact:
  _target_: src.callbacks.wandb_callbacks.UploadCodeAsArtifact
  code_dir: ${work_dir}/src
```




`# @package _global_` - Changes specified in this config should be interpreted as relative to the _global_ package.

We could instead place nglite.yaml and aplite.yaml next to config.yaml and omit this line.

The overrides of /db and /server are absolute paths.

This is necessary because they are outside of the experiment directory.
Example:

consider config with two folders: db and server. We choose from db mysql and from server apache
defaults:
  - db: mysql
  - server: apache
├── config.yaml
├── db
│   ├── mysql.yaml
│   └── sqlite.yaml
└── server
    ├── apache.yaml
    └── nginx.yaml

Key point to know where you are:
in mysql.yaml put
    name: mysql (to know what is the node about)

