# %%
import pandas as pd
from pathlib import Path
import os

pd.options.display.max_columns = 999

DATA_DIR = "Z:/datasets/RANZCR" if os.name == 'nt' else "/mnt/data/datasets/RANZCR"

"""
train.csv contains image IDs, binary labels, and patient IDs.
TFRecords are available for both train and test. (They are also available for the hidden test set.)

train_annotations.csv - these are segmentation annotations for training samples that have them. They are included solely as additional information for competitors.    

Columns
    StudyInstanceUID - unique ID for each image
    ETT - Abnormal - endotracheal tube placement abnormal
    ETT - Borderline - endotracheal tube placement borderline abnormal
    ETT - Normal - endotracheal tube placement normal
    NGT - Abnormal - nasogastric tube placement abnormal
    NGT - Borderline - nasogastric tube placement borderline abnormal
    NGT - Incompletely Imaged - nasogastric tube placement inconclusive due to imaging
    NGT - Normal - nasogastric tube placement borderline normal
    CVC - Abnormal - central venous catheter placement abnormal
    CVC - Borderline - central venous catheter placement borderline abnormal
    CVC - Normal - central venous catheter placement normal
    Swan Ganz Catheter Present
    PatientID - unique ID for each patient in the dataset


rain_v2.csv has 2 additional columns, "fold" (using last digit technique) and "w_anno" ( do we have annotation)
"""

# %%
T = dict(study_uid='StudyInstanceUID', patient_id='PatientID')
hash_ = lambda x: int(x[-1])
df_train = pd.read_csv(Path(DATA_DIR) / 'train.csv')

df_train_annotation = pd.read_csv(Path(DATA_DIR) / 'train_annotations.csv')
df_train_annotation['w_anno'] = True
# %% 
df_train['hash'] = df_train[T['study_uid']].apply(hash_)
print(df_train.columns.tolist())

# %%
from collections import Counter
counts = Counter( df_train['hash'] )
print(counts)

#% sample dataframe using group by hash
sample_df = df_train.groupby("hash").sample(n=100, random_state=1)

#% create column with_ano
df_train_new = pd.merge(df_train, df_train_annotation[[T['study_uid'], 'w_anno']], on=T['study_uid'], how='left')
print(df_train_new)

# df_train = pd.read_csv('../input/ranzcr-fold/train_v2.csv')

# # If DEBUG == True, use only 100 samples to run.
# df_train = pd.concat([
#     df_train.query('fold == 0').sample(20),
#     df_train.query('fold == 1').sample(20),
#     df_train.query('fold == 2').sample(20),
#     df_train.query('fold == 3').sample(20),
#     df_train.query('fold == 4').sample(20),
# ]) if DEBUG else df_train

# df_train_anno = pd.read_csv(DATA_DIR / 'train_annotations.csv'))