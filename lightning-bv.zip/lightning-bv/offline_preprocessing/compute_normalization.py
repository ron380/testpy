'''
Filename: r:\pycode\BrainVentricles\offline_preprocessing\compute_normalization.py
Path: r:\pycode\BrainVentricles\offline_preprocessing
Created Date: Wednesday, March 16th 2022, 3:40:42 pm
Author: Ron Shefi

Copyright (c) 2022 Philips
'''
from typing import List, Dict, Tuple, Optional, Union
from matplotlib.colors import Normalize
import pandas as pd
import numpy as np
from pathlib import Path, PosixPath
from itertools import chain # concatenate 
from functools import partial
import glob
import os
import sys
import re

import torch
# https://github.com/Project-MONAI/tutorials/blob/master/modules/image_dataset.ipynb
from monai.data import ImageDataset, Dataset, DataLoader, CacheDataset
from monai.transforms import (
    Compose,
    MapTransform,
    AdjustContrastd, 
    EnsureChannelFirst,
    NormalizeIntensityd,
    RandAdjustContrast, 
    Spacingd, 
    LoadImaged,
    ToTensord,
    LoadImage, LoadImaged,
    AddChanneld,
    Resized,
    EnsureTyped,
    RandRotate90d, 
    Identity)
from monai.transforms.utility.dictionary import (    
    Transposed)
from monai.config import print_config
from monai.utils import first, set_determinism

# local implementations
from transforms import CTThresholdIntensityd, ModalityBasedTransformd
print_config()


T = dict(study_uid='Study Instance Uid', series_uid='Series Instance Uid', accession='Accession', scan_type='Scan type T1/T2/FLAIR')

BASE_PATH = Path('/mnt/data/Data')
_path = BASE_PATH / 'GroundTruth' / 'BrainVentricles'
dataset_file = _path / 'ventricles.xlsx'
print(dataset_file)
# read the annotation dataset
df = pd.read_excel(dataset_file, engine="openpyxl", dtype={'Status': 'Int8'})
main_df = df[df['Status'] == 1]
# print(main_df)

# input sources
studies_path = _path / 'studies'
segmentation_path = _path / 'segmentation'

# pairing images and segmentation in dataset folder
dataset_path = _path / 'dataset'

def extract_modality(s: PosixPath) -> str:
    print(s.name)
    m = re.match(r"[\w^]+_(\w+)_image.nii.gz", s.name)
    return m.group(1)

class ConvertLabels(MapTransform):
    """
    Convert labels to multi channels based on brats classes:
    label 0 is the background
    label 1 is the peritumoral edema
    label 2 is the GD-enhancing tumor
    label 3 is the necrotic and non-enhancing tumor core
    The possible classes are TC (Tumor core), WT (Whole tumor)
    and ET (Enhancing tumor).

    """

    def __call__(self, data: Dict) -> Dict:
        d = dict(data)
        for key in self.keys:
            result = d[key].astype(np.int8)
            # merge LEFT and RIGHT
            result = np.where(d[key] == 2, 1, result)
            result = np.where(d[key] == 2, 2, result)
            result = np.where(d[key] == 3, 4, result)
            d[key] = result.astype(np.float32)
        return d

def prepare_data(modalities: List[str]) -> List[Dict[str,Union[str,PosixPath]]]:
    # set up the correct data path
    images = sorted(chain(*(dataset_path.glob(f"*{mod}*image.nii.gz") for mod in modalities)))
    labels = sorted(chain(*(dataset_path.glob(f"*{mod}*label.nii.gz") for mod in modalities)))
    
    # arrange the data in list of image/label dict (prefereable generator)
    
    data_dicts = [
        {'img': image_name, 'seg': label_name, 'mod': extract_modality(mod_name)}
        for image_name, label_name, mod_name in zip(images, labels, images)
    ]
    
    return data_dicts

    # example on how to construct     
    # train_files, val_files = data_dicts[:-10], data_dicts[-10:]

def get_mean_and_std(dataloader: DataLoader) -> Tuple[Float, Float]:
    """ get the mean and std

    Parameters
    ----------
    dataloader : DataLoader
        _description_

    Returns
    -------
    _type_
        _description_
    """

    
    channels_sum, channels_squared_sum, num_batches = 0, 0, 0
    for data, _ in dataloader:
        # Mean over batch, height, width, and depth, but not over the channels
        channels_sum += torch.mean(data, dim=[0,2,3,4])
        channels_squared_sum += torch.mean(data**2, dim=[0,2,3,4])
        num_batches += 1
    
    mean = channels_sum / num_batches

    # std = sqrt(E[X^2] - (E[X])^2)
    std = (channels_squared_sum / num_batches - mean ** 2) ** 0.5

    return mean, std

def compute_stats(modality: str):
    """
        return (mean, std) for each channel

    Args:
        modality (str): _description_
    """
    image_labels = prepare_data([modality])
    print(image_labels)
    preprocess_transformations = [
        LoadImaged(keys=['img', 'seg']),
        Transposed(keys=['img', 'seg'], indices=(2, 1, 0)),
        # # add channel (grayscale)
        AddChanneld(keys=['img', 'seg']),
        Resized(keys=['img', 'seg'],
            spatial_size=resize_target,
            mode=['trilinear', 'nearest'],
            align_corners=[False, None]
        ) if resize_target is not None else Identity(),

        ]
    _transforms = Compose(transforms=preprocess_transformations)
    _ds = Dataset(data=image_labels, transform=_transforms)
    # dataloader
    _loader = DataLoader(_ds, batch_size=1)
    return get_mean_and_std(_loader)





# get the data filenames
image_labels = prepare_data(['T1'])
print(image_labels)

# MONAI-tutorials\modules\3d_image_transforms.ipynb
# z-y-x
resize_target = (224, 224, 32)

transform_preprocess=Compose([
        LoadImaged(keys=['img', 'seg']),
        CTThresholdIntensityd(keys=['img'], a_min=0, a_max=80),
        ToTensord(keys=['img', 'seg']),        
        # MRI
        # transpose indices 
        # Spacingd(
        #     keys=['img', 'seg'],
        #     pixdim=(0.3, 0.3, 2.0),
        #     diagonal=False,
        #     mode=("bilinear", "nearest"),
        # ),
        Transposed(keys=['img', 'seg'], indices=(2, 1, 0)),
        # add channel (grayscale)
        AddChanneld(keys=['img', 'seg']),

        # resize only the [xy] plane, and leave the z-axis intact
        Resized(keys=['img', 'seg'],
            spatial_size=resize_target[:2] + (-1,),
            mode=['trilinear', 'nearest'],
            align_corners=[False, None]
        ) if resize_target is not None else Identity(),
        RandSliceAxisd(keys=['img', 'seg'], axis=0, size=32),

        # RandRotate90d(keys=['img', 'seg'], prob=1, spatial_axes=[1, 2]),
        # EnsureTyped(keys=['img', 'seg']),
    ])

preprocess_transformations = [
    LoadImaged(keys=['img', 'seg']),
    Transposed(keys=['img', 'seg'], indices=(2, 1, 0)),
    # # add channel (grayscale)
    AddChanneld(keys=['img', 'seg']),
    Resized(keys=['img', 'seg'],
        spatial_size=resize_target,
        mode=['trilinear', 'nearest'],
        align_corners=[False, None]
    ) if resize_target is not None else Identity(),

    ModalityBasedTransformd(keys=['img', 'mod'], 
        transform=partial(CTThresholdIntensityd, a_min=0, a_max=80), 
        modality='CT'),
    ModalityBasedTransformd(keys=['img', 'mod'], 
        transform=partial(NormalizeIntensityd, subtrahend=mean_FLAIR, divisor=std_FLAIR), 
        modality='FLAIR'),
    ModalityBasedTransformd(keys=['img', 'mod'], 
        transform=partial(NormalizeIntensityd, subtrahend=mean_T1, divisor=std_T1), 
        modality='T1'),        
    ]

_transforms = Compose(transforms=preprocess_transformations)
#  `LoadImage` class is a simple callable wrapper of the underlying `Nibabel` image loader
loader = LoadImage()
image, metadata = loader(image_labels[0]['img'])
print(f"input: {image_labels[0]['img']}")
print(metadata)
print(image.data)

print(f"image shape: {image.shape}")
print(f"image affine:\n{metadata['affine']}")
print(f"image pixdim:\n{metadata['pixdim']}")



check_ds = Dataset(data=image_labels, transform=_transforms)
# pick the first image
check_loader = DataLoader(check_ds, batch_size=1)
check_data = first(check_loader)
print("CHECK_DATA")
print(check_data)
# sys.exit()
image, label = check_data['img'], check_data['seg']
print(f"image shape: {image.shape}")
print(f"label shape: {label.shape}")
sys.exit()
# B x C x D x H x W
# loader = LoadImaged(keys=['img', 'seg'], image_only=True)
# data_dict = loader(image_labels[0])
# print(f"input:, {train_data_dicts[0]}")
# print(f"image shape: {data_dict['img'].shape}")
# print(f"label shape: {data_dict['seg'].shape}")
# print(f"image pixdim:\n{data_dict['image_meta_dict']['pixdim']}")

# view with napari
def visualize(image, label):
    import napari
    viewer = napari.view_image(image.numpy())
    viewer.add_labels(label.numpy().astype(np.int8))
    napari.run()


# dataset = Dataset(
#         data=image_labels,
#         transform=LoadImaged(keys=['img', 'seg']),
#     )

"""
The list of data dictionaries, `train_data_dicts`,
could be used by PyTorch's data loader.

For example,

```python
from torch.utils.data import DataLoader

data_loader = DataLoader(train_data_dicts)
for training_sample in data_loader:
    # run the deep learning training with training_sample
```

"""
"""
loader = data.DataLoader(dataset,
                         batch_size=10,
                         num_workers=0,
                         shuffle=False)

mean = 0.
std = 0.
for images, _ in loader:
    batch_samples = images.size(0) # batch size (the last batch can have smaller size!)
    images = images.view(batch_samples, images.size(1), -1)
    mean += images.mean(2).sum(0)
    std += images.std(2).sum(0)

mean /= len(loader.dataset)
std /= len(loader.dataset)
"""