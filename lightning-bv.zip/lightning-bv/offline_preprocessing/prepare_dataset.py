'''
Filename: r:\pycode\BrainVentricles\offline_preprocessing\prepare_dataset.py
Path: r:\pycode\BrainVentricles\offline_preprocessing
Author: Ron Shefi

Copyright (c) 2022 Philips
'''
import nibabel as nib
import pandas as pd
from pathlib import Path
import argparse
from pyparsing import col
from alginfra_utils import *
import logging
import sys
from alginfra_utils.rbvutils import EmptyLabel, UIDReadError
from collections import namedtuple as NamedTuple

logging.basicConfig(level=logging.ERROR, filename='prepare_dataset.log')


pd.options.display.max_columns=999
pd.options.display.max_rows=999

T = dict(study_uid='Study Instance Uid', series_uid='Series Instance Uid', accession='Accession', scan_type='Scan type T1/T2/FLAIR')

BASE_PATH = Path('/mnt/data/Data')
_path = BASE_PATH / 'GroundTruth' / 'BrainVentricles'
dataset_file = _path / 'ventricles.xlsx'
print(dataset_file)
# read the annotation dataset
df = pd.read_excel(dataset_file, engine="openpyxl", dtype={'Status': 'Int8'})
main_df = df[df['Status'] == 1]
print(main_df)

# input sources
studies_path = _path / 'studies'
segmentation_path = _path / 'segmentation'

# pairing images and segmentation in dataset folder
dataset_path = _path / 'dataset'
dataset_resample_path = _path / 'dataset_resample'

ImageRowItem = NamedTuple("ImageItem", ["study_uid", "series_uid", "accession", "scan_type", "dim_x", "dim_y", "dim_z", "slope", "intercept", "pixdim_x", "pixdim_y", "pixdim_z", "issue"])

def process_item(i, row, args):
    study_uid = row[T['study_uid']]
    series_uid = row[T['series_uid']]
    accession = row[T['accession']]
    scan_type = row[T['scan_type']]
    slope, intercept, error_str = None, None, None

    pixdim = (None, None, None)
    shape = (None, None, None)

    # external resample (using)
    resample = args.resample
    box_tuple = None
    if args.resample:
        box_tuple = tuple(args.box)

    if scan_type == 'T2':
        error_str = "skip T2 scan type"
        return ImageRowItem(study_uid, series_uid, accession, scan_type, shape[0], shape[1], shape[2], slope, intercept, pixdim[0], pixdim[1], pixdim[2], error_str)
        

    img_path = studies_path / study_uid / series_uid
    seg_path = segmentation_path / study_uid / series_uid

    try:
        # missing study image (can't be retrived by tool_retriever)
        try:
            image3d = load_image3d(img_path)
        except FileNotFoundError:
            error_str = "image3d not found"
            return ImageRowItem(study_uid, series_uid, accession, scan_type, shape[0], shape[1], shape[2], slope, intercept, pixdim[0], pixdim[1],pixdim[2], error_str)

        # image3d.Resample(box, padding)
        # resample section

        vecs = IP_Box_Methods.vecs(image3d.box)
        affine = IP_Box_Methods.affine(image3d.box)
        shape = IP_Box_Methods.shape(image3d.box)
        logging.debug("vecs = ", vecs)
        logging.debug("affine = ", affine)
        logging.debug("slope/intercept: ", image3d.get_slope(), image3d.get_intercept())
        logging.debug("pixdim: ", IP_Box_Methods.pixdim(image3d.box))
        labels = label_data(seg_path, image3d.box, ['LEFT', 'RIGHT', '3', '4'])

        slope, intercept = image3d.get_slope(), image3d.get_intercept()
        pixdim = IP_Box_Methods.pixdim(image3d.box)

        # check pixdim

        extra = {'scan_type': scan_type, 'accession': accession}        
        # construct a nifti image object
        # construct nifti object with image, affine, and extra
        nifti_image = nib.Nifti1Image(transpose_image3d(image3d.data), affine, extra=extra)
        # print(nifti_image.header)
        # update nifti header
        nifti_image.header['scl_slope'] = image3d.get_slope()
        nifti_image.header['scl_inter'] = image3d.get_intercept()
        # nifti_image.header['pixdim'] = [0] + IP_Box_Methods.pixdim(image3d.box) + [1, 1, 1, 1]
        
        # construct nifti label object
        nifti_label = nib.Nifti1Image(transpose_image3d(labels), affine, extra=extra)
        # done automatically
        # nifti_label.header['pixdim'] = [0] + IP_Box_Methods.pixdim(image3d.box) + [1, 1, 1, 1]
        
        # save the nifti image/label
        filename_image = f'{accession}_{scan_type}_image.nii.gz'
        filename_label = f'{accession}_{scan_type}_label.nii.gz'
        dataset_path_target = dataset_resample_path if resample else dataset_path
        nib.save(nifti_image, dataset_path_target / filename_image)
        nib.save(nifti_label, dataset_path_target / filename_label)
        print(".. save image ", (dataset_path_target / filename_image).as_posix())
        
    except FileNotFoundError as e:
        logging.error(f"{i}-{accession}-folders not found {study_uid} {series_uid}")
        logging.error(str(e))
        print(e)
        error_str = "folders not found"
    except KeyError as e:
        logging.error(f"{i}-{accession}-segmentation key folder check {study_uid} {series_uid}")
        error_str = "segmentation key folder"
    except UIDReadError as e:
        logging.error(f"{i}-{accession}-wrong uid {study_uid} {series_uid} {str(e)}")
        error_str = "wrong uid/missing numbers in uid"
    except EmptyLabel as e:
        logging.error(f"{i}-{accession}-empty segmentation check {study_uid} {series_uid} {str(e)}")
        error_str = "empty segmentation/not labeled"
    except ValueError as e:
        print (str(e))
        logging.error(f"{i}-{accession}-processing check {study_uid} {series_uid} {str(e)}")
        error_str = str(e)

    return ImageRowItem(study_uid, series_uid, accession, scan_type, shape[0], shape[1], shape[2], slope, intercept, pixdim[0], pixdim[1], pixdim[2], error_str)

def main(args):
    items = []
    for i, row in main_df.iterrows():
        print(f"...  processing {i} {row['Accession']}..")
        item = process_item(i, row, args)
        items.append(item)
        # if i > 5: break

    df = pd.DataFrame.from_records(items, columns=ImageRowItem._fields)
    df.to_csv("brain_ventricles_report.csv", index=False)


def main_for_accession(args):
    accession = args.accession
    print(main_df[T['accession']])
    print(accession)
    row = main_df.loc[main_df[T['accession']] == accession,:].squeeze()
    print("row = ", row)
    if row.empty:
        raise ValueError(f"accession {accession} not found")
    i = 9999
    print(f"...  processing {i} {row['Accession']}..")
    process_item(i, row, args)


def tuple_type(s: str) -> tuple:
    s = s.replace("(", "").replace(")", "")
    mapped_int = map(int, s.split(","))
    return tuple(mapped_int)

if __name__ == '__main__':    
    parser = argparse.ArgumentParser()    
    parser.add_argument('--resample', action='store_true')
    parser.add_argument('--no-resample', action='store_false')
    parser.add_argument('-a', '--accession', type=str)
    parser.set_defaults(resample=False)
    parser.add_argument('-b', '--box', nargs='+', type=int, default=[224,224,36])
    
    args = parser.parse_args()
    print(args)
    if args.accession:        
        main_for_accession(args)
    else:
        main(args)