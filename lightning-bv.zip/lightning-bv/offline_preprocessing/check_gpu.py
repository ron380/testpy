import torch

print("gpu = ", torch.cuda.is_available())