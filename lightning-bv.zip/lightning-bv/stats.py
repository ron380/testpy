#import dotenv
import hydra
from omegaconf import DictConfig, OmegaConf
import argparse

# load environment variables from `.env` file if it exists
# recursively searches for `.env` in all folders starting from work dir
# dotenv.load_dotenv(override=True)


@hydra.main(config_path="configs/", config_name="config.yaml")
def main(config: DictConfig):


    # Imports can be nested inside @hydra.main to optimize tab completion
    # https://github.com/facebookresearch/hydra/issues/934
    from src.utils import extras
    from src.stats_pipeline import stats


    print(OmegaConf.to_yaml(config))
    # Applies optional utilities
    extras(config)

    # Train model
    return stats(config)


if __name__ == "__main__":
    # parser = argparse.ArgumentParser(description='Process some options.')
    # parser.add_argument('--distr', action='store_true',
    #                 help='image distribution')
    # parser.add_argument('--stats', action='store_true',                    
    #                 help='image mean/std')

    # args = parser.parse_args()
    # print(args.accumulate(args.integers))
    """
        python stats.py train=

    """
    main()
