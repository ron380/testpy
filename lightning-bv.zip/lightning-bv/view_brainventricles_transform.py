import numpy as np
import nibabel as nib
import hydra
from omegaconf import DictConfig, OmegaConf
from monai.transforms import LoadImage
import os
import sys
from torch import nn
import torch
import src.utils

# monai
# https://github.com/Project-MONAI/tutorials/blob/master/modules/image_dataset.ipynb
from monai.data import (ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch)
from monai.config import print_config
from monai.utils import first, set_determinism

# path
from pathlib import Path

from typing import List, Optional


from pytorch_lightning import (
    LightningDataModule,
    seed_everything,
)

# from pytorch_lightning.loggers import LightningLoggerBase
# from src.utils import get_logger
# log = get_logger(__name__)

@hydra.main(version_base=None, config_path="configs/", config_name="config.yaml")
def main(config: DictConfig) -> Optional[float]:

    # Init lightning datamodule
    datamodule: LightningDataModule = hydra.utils.instantiate(config.datamodule)
    name = "YJHGJBGV_FLAIR"
    # construct a sample image/label
    image_name = Path(f"{config.dataset_dir}/{name}_image.nii.gz")
    label_name = Path(f"{config.dataset_dir}/{name}_label.nii.gz")

    loader_dict = [dict(img=image_name, seg=label_name)]

    print(loader_dict)
    _transforms = datamodule.get_transforms("train_check_transforms")

    check_ds = Dataset(data=loader_dict, transform=_transforms)

    # pick the first image
    check_loader = DataLoader(check_ds, batch_size=1)
    check_data = first(check_loader)

    image, label = check_data['img'], check_data['seg']

    print(f"image shape: {image.shape}")
    print(f"label shape: {label.shape}")
    print(type(image))
    visualize(image, label)

    


# view with napari
def visualize(image, label):
    import napari
    viewer = napari.view_image(image.numpy())
    viewer.add_labels(label.numpy().astype(np.int8))
    
    napari.run()


if __name__ == '__main__':
    main()