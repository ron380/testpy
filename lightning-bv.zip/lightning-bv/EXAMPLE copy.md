# running example modalities 

# computing the stats
python stats.py modalities=['T1','FLAIR'] +action=stats

# computing the distribution
python stats.py modalities=['T1','FLAIR'] +action=distr

# computing the distribution
python stats.py modalities=['T1','FLAIR'] +action=class-axial-distr


# training 
python train.py train=brainventricles trainer.max_epochs=300 clearML=true trainer.gpus=1 model.lr=0.01 datamodule.cache=true

# training from a checkpoint
python train.py train=brainventricles trainer.max_epochs=300 clearML=true trainer.gpus=1 model.lr=0.01 datamodule.cache=true trainer.resume_from_checkpoint="/mnt/data/Users/rons/pycode/lightning-brainventricles/logs/experiments/runs/brainventricles/2022-07-04_09-09-48/checkpoints/epoch_123_iou_val_0.545.ckpt"

# testing
python train.py train=brainventricles trainer.max_epochs=300 clearML=true trainer.gpus=1 model.lr=0.01 datamodule.cache=true 

