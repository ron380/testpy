# build the docker exmples

docker build -t nlpbase:3.7 --build-arg SPARK_NLP_VERSION=${SPARK_NLP_VERSION} -f ./DockerfileBase .
docker build -t nlpimage:3.7 --build-arg SPARK_NLP_VERSION=${SPARK_NLP_VERSION} -f ./Dockerfile .
running docker:
docker run -it --rm -p 8888:8888 nlpimage:3.7
docker run  -u $(id -u):$(id -g)  --gpus all -it --rm tensorflow/tensorflow:latest-gpu


docker build -t tensorflow-sparknlp:2.7.5 --build-arg SPARK_NLP_VERSION=2.7.5 --build-arg FRAMEWORK=tensorflow --build-arg FRAMEWORK_VERSION=21.03-tf2-py3  -f ./DockerTensorflowTest .
docker run  -u $(id -u):$(id -g)  --gpus all -it --rm tensorflow-sparknlp:2.7.5
docker build -t tensorflow-sparknlp:3.0 --build-arg FRAMEWORK=tensorflow --build-arg FRAMEWORK_VERSION=21.05-tf2-py3 -f SparkNLPDockerNvidiaShort .
docker build -t tensorflow-sparknlp:3.0.3 --build-arg FRAMEWORK=tensorflow --build-arg FRAMEWORK_VERSION=21.05-tf2-py3 -f SparkNLPDockerNvidiaShort3.0.3 .
docker build -t tensorflow-sparknlp:3.1.1 --build-arg FRAMEWORK=tensorflow --build-arg FRAMEWORK_VERSION=21.03-tf2-py3 -f SparkNLPDockerNvidiaShort3.0.3 .
docker build -t pytorch-sparknlp:3.1.3 --build-arg FRAMEWORK=pytorch --build-arg FRAMEWORK_VERSION=21.03-py3 -f SparkNLPDockerNvidiaShort3.0.3 .
docker build -y pytorch-docker:3.1.3 -build-arg FRAMEWORK=pytorch --build-arg FRAMEWORK_VERSION=21.03-py3 -f PyTorchDocker .
docker build -y pytorch-docker:3.1.3 --no-cache -build-arg FRAMEWORK=pytorch --build-arg FRAMEWORK_VERSION=21.03-py3 -f PyTorchDockerSuperPixel .
docker build -t pytorch-ron:22.02  --no-cache --build-arg FRAMEWORK=pytorch --build-arg FRAMEWORK_VERSION=22.02-py3 -f PyTorchDockerSuperPixel .
docker build -t pytorch-ron:22.02  --build-arg FRAMEWORK=pytorch --build-arg FRAMEWORK_VERSION=22.02-py3 -f PyTorchDockerSuperPixel .
