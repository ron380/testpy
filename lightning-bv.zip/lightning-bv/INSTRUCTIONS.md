#  directives for commandline
trainer.gpus - how many gpus to use
trainer.device
datamodule.cache - allow to cache all the training set in memory
trainer.resume_from_checkpoint - resume training from a ckpt file
    trainer.resume_from_checkpoint="/mnt/data/Users/rons/pycode/lightning-brainventricles/logs/experiments/runs/brainventricles/2022-07-04_09-09-48/checkpoints/epoch_123_iou_val_0.545.ckpt"

##  training 
we have 3 ways of training 
1. all ventricles: bilateral, 3rd, 4th
> python train.py train=brainventricles trainer.max_epochs=300 clearML=true trainer.gpus=1 model.lr=0.01 datamodule.cache=true
2. bilateral only
> python train.py train=brainventricles trainer.max_epochs=300 clearML=true trainer.gpus=1 model.lr=0.01    


##  resume training from a checkpoint
python train.py train=brainventricles trainer.max_epochs=300 clearML=true trainer.gpus=1 model.lr=0.01 datamodule.cache=true trainer.resume_from_checkpoint="/mnt/data/Users/rons/pycode/lightning-brainventricles/logs/experiments/runs/brainventricles/2022-07-04_09-09-48/checkpoints/epoch_123_iou_val_0.545.ckpt"

##  testing (using test dataloader)
python train.py test=brainventricles trainer.max_epochs=300 clearML=true trainer.gpus=1 model.lr=0.01 datamodule.cache=true 

##  run predict to generate predictions 
using the predict script. store the predictions in preds directory
> python predict.py test=brainventricles clearML=false trainer.gpus=1 ckpt_path="/mnt/data/Users/rons/pycode/lightning-brainventricles/logs/experiments/runs/brainventricles/2022-07-18_11-18-29/checkpoints/epoch_210_iou_val_0.555.ckpt"

##  view prediction
1. /mnt/data/Users/rons/pycode/lightning-brainventricles$ 

    view_image_pred.md <image-name> <directory of prediction> <input image to overlay the prediction>
    python view_image_pred.py UPENN-GBM-00216_11_T1 2022-09-01_11-19-24 /mnt/data/Data/GroundTruth/BrainVentricles/images_structural_unstripped


# various testing

## training from a specified experiment
this allows to check some parameters, arch... 

> python train.py train=brainventricles trainer.max_epochs=300 clearML=true trainer.gpus=1 model.lr=0.01 datamodule.cache=true experiment=experiment1
