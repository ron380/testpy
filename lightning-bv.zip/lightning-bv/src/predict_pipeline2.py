import os
from typing import List
import torch
import hydra
from omegaconf import DictConfig
from pytorch_lightning import LightningDataModule, LightningModule, Trainer, seed_everything
from pytorch_lightning.loggers import LightningLoggerBase

from monai.data import ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch
from monai.transforms import (
    Compose,
    AsDiscreted,
    Invertd,
    EnsureTyped,
    CastToTyped,
    LoadImage, 
    LoadImaged,
    AddChanneld,
    Resized
    )


# from src.utils import extras
from src.utils import get_logger, log_hyperparameters, finish

log = get_logger(__name__)


def predict(config: DictConfig) -> None:
    """Contains minimal example of the testing pipeline. Evaluates given checkpoint on a testset.

    Args:
        config (DictConfig): Configuration composed by Hydra.

    Returns:
        None
    """

    # Set seed for random number generators in pytorch, numpy and python.random
    if config.get("seed"):
        seed_everything(config.seed, workers=True)

    # Convert relative ckpt path to absolute path if necessary
    if not os.path.isabs(config.ckpt_path):
        config.ckpt_path = os.path.join(hydra.utils.get_original_cwd(), config.ckpt_path)

    # Init lightning datamodule
    log.info(f"Instantiating datamodule <{config.datamodule._target_}>")
    datamodule: LightningDataModule = hydra.utils.instantiate(config.datamodule)

    # Init lightning model
    log.info(f"Instantiating model <{config.model._target_}>")
    model: LightningModule = hydra.utils.instantiate(config.model)

    # Init lightning loggers
    logger: List[LightningLoggerBase] = []
    if "logger" in config:
        for _, lg_conf in config.logger.items():
            if "_target_" in lg_conf:
                log.info(f"Instantiating logger <{lg_conf._target_}>")
                logger.append(hydra.utils.instantiate(lg_conf))


    # unetr btcv / spleen 3d  ...
    trained_model = datamodule.load_from_checkpoint(checkpoint_path=config.ckpt_path)
    # datamodule.load_state_dict(torch.load(os.path.join(root_dir, "best_metric_model.pth")))
    # print model hyperparameters
    print(trained_model.hparams)

    # switch to evaluation mode
    trained_model.eval()
    trained_model.freeze()

    # transform and loader
    val_org_transforms = config.transforms["preprocess_transforms"]
    num_classes = config.num_classes
    val_files = datamodule.data_test

    val_org_ds = Dataset(data=val_files, transform=val_org_transforms)
    val_org_loader = DataLoader(val_org_ds, batch_size=1, num_workers=1)

    
    post_transforms = Compose([
        EnsureTyped(keys="pred"),
        Invertd(
            keys="pred",
            transform=val_org_transforms,
            orig_keys="image",
            meta_keys="pred_meta_dict",
            orig_meta_keys="image_meta_dict",
            meta_key_postfix="meta_dict",
            nearest_interp=False,
            to_tensor=True,
        ),
        AsDiscreted(keys="pred", argmax=True, to_onehot=num_classes),
        AsDiscreted(keys="label", to_onehot=num_classes),
    ])

    img = Image.open("data/example_img.png").convert("L")  # convert to black and white
    # img = Image.open("data/example_img.png").convert("RGB")  # convert to RGB

    # preprocess
    # xforms = config.transforms.preprocess_xforms
    # mnist_transforms = Compose(
    #     [
    #         transforms.ToTensor(),
    #         transforms.Resize((28, 28)),
    #         transforms.Normalize((0.1307,), (0.3081,)),
    #     ]
    # )
    # img = mnist_transforms(img)
    # img = img.reshape((1, *img.size()))  # reshape to form batch of size 1

    # inference
    output = trained_model(img)
    print(output)
