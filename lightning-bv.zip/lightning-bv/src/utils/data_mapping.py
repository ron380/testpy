from typing import Union, List, Tuple, Any, Optional
import pandas as pd
import re
import os
from pathlib import Path
from itertools import chain

T = dict(study_uid='Study Instance Uid', series_uid='Series Instance Uid', accession='Accession', scan_type='Scan type T1/T2/FLAIR')

# cf. https://codereview.stackexchange.com/questions/241296/combining-none-and-lists-in-one-line
def join(*vars_: List[Any]) -> Optional[List[Any]]:
    return list(chain.from_iterable(elem for elem in vars_ if elem)) or None

def get_dataset(dataset_file: str) -> pd.DataFrame:
    df = pd.read_excel(dataset_file, engine="openpyxl", dtype={'Status': 'Int8'})
    main_df = df[df['Status'] == 1]
    return main_df


def extract_accession_modality(s: str) -> Tuple[str,str]:
    m = re.match(r"([\w^]+)_(\w+)_image.nii.gz", s)
    return m.group(1), m.group(2)


def extract_sequence_id(re_pattern: str, s: str) -> int:
    # m = re.match(r"\w+_(\d+).json", s)
    m = re.match(re_pattern, s)
    return int(m.group(1))


def get_run_sequence_id(directory: Union[str,Path], *, re_pattern, filename_pattern: str) -> int:
    # print (list(directory.glob("*")))
    if not isinstance(directory, Path):
        directory = Path(directory)
    all_runs = map(lambda x: extract_sequence_id(re_pattern, os.path.basename(x)), directory.glob(filename_pattern))
    # print(list(all_runs))
    try:
        last_id = max(all_runs)
    except ValueError as e:
        if str(e) == "max() arg is an empty sequence":
            print(f"empty record directory starting at 0")
            last_id = 0
        else:
            raise(e)
    return last_id + 1
    