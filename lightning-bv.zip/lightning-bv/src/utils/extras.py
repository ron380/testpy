import logging
import warnings
from typing import List, Sequence, Dict

import pytorch_lightning as pl
import rich.syntax
import rich.tree
from omegaconf import DictConfig, OmegaConf
from pytorch_lightning.utilities import rank_zero_only
from pathlib import Path
from .data_mapping import get_run_sequence_id
from addict import Dict
import multiprocessing
import sys

def get_logger(name=__name__) -> logging.Logger:
    """Initializes multi-GPU-friendly python command line logger."""

    logger = logging.getLogger(name)

    # this ensures all logging levels get marked with the rank zero decorator
    # otherwise logs would get multiplied for each GPU process in multi-GPU setup
    for level in (
        "debug",
        "info",
        "warning",
        "error",
        "exception",
        "fatal",
        "critical",
    ):
        setattr(logger, level, rank_zero_only(getattr(logger, level)))

    return logger


log = get_logger(__name__)


mp = multiprocessing.Queue()


@rank_zero_only
def get_queue():
    return mp

def extras(config: DictConfig) -> None:
    """Applies optional utilities, controlled by config flags.

    Utilities:
    - Ignoring python warnings
    - Rich config printing
    """

    # disable python warnings if <config.ignore_warnings=True>
    if config.get("ignore_warnings"):
        log.info("Disabling python warnings! <config.ignore_warnings=True>")
        warnings.filterwarnings("ignore")

    # pretty print config tree using Rich library if <config.print_config=True>
    if config.get("print_config"):
        log.info("Printing config tree with Rich! <config.print_config=True>")
        print_config(config, resolve=True)


@rank_zero_only
def print_config(
    config: DictConfig,
    print_order: Sequence[str] = (
        "datamodule",
        "model",
        "callbacks",
        "logger",
        "trainer",
    ),
    resolve: bool = True,
) -> None:
    """Prints content of DictConfig using Rich library and its tree structure.

    Args:
        config (DictConfig): Configuration composed by Hydra.
        print_order (Sequence[str], optional): Determines in what order config components are printed.
        resolve (bool, optional): Whether to resolve reference fields of DictConfig.
    """

    style = "dim"
    tree = rich.tree.Tree("CONFIG", style=style, guide_style=style)

    quee = []

    for field in print_order:
        quee.append(field) if field in config else log.info(f"Field '{field}' not found in config")

    for field in config:
        if field not in quee:
            quee.append(field)

    for field in quee:
        branch = tree.add(field, style=style, guide_style=style)

        config_group = config[field]
        if isinstance(config_group, DictConfig):
            branch_content = OmegaConf.to_yaml(config_group, resolve=resolve)
        else:
            branch_content = str(config_group)

        branch.add(rich.syntax.Syntax(branch_content, "yaml"))

    rich.print(tree)
    # check rich print to file
    with open("config_tree.log", "w") as file:
        rich.print(tree, file=file)
    # print yaml to file
    with open("config_tree.yaml", "w") as file:
        print(OmegaConf.to_yaml(config, resolve=True), file=file)


@rank_zero_only
def log_hyperparameters(
    config: DictConfig,
    model: pl.LightningModule,
    datamodule: pl.LightningDataModule,
    trainer: pl.Trainer,
    callbacks: List[pl.Callback],
    logger: List[pl.loggers.LightningLoggerBase],
) -> None:
    """Controls which config parts are saved by Lightning loggers.

    Additionaly saves:
    - number of model parameters
    """

    if not trainer.logger:
        return

    hparams = {}

    # choose which parts of hydra config will be saved to loggers
    hparams["model"] = config["model"]

    # save number of model parameters
    hparams["model/params/total"] = sum(p.numel() for p in model.parameters())
    hparams["model/params/trainable"] = sum(
        p.numel() for p in model.parameters() if p.requires_grad
    )
    hparams["model/params/non_trainable"] = sum(
        p.numel() for p in model.parameters() if not p.requires_grad
    )

    hparams["datamodule"] = config["datamodule"]
    hparams["trainer"] = config["trainer"]

    if "seed" in config:
        hparams["seed"] = config["seed"]
    if "callbacks" in config:
        hparams["callbacks"] = config["callbacks"]

    # send hparams to all loggers
    trainer.logger.log_hyperparams(hparams)


def finish(
    config: DictConfig,
    model: pl.LightningModule,
    datamodule: pl.LightningDataModule,
    trainer: pl.Trainer,
    callbacks: List[pl.Callback],
    logger: List[pl.loggers.LightningLoggerBase],
) -> None:
    """Makes sure everything closed properly."""
    pass

@rank_zero_only
def record(
    config: DictConfig,
    model: pl.LightningModule,
    datamodule: pl.LightningDataModule,
    trainer: pl.Trainer,
    callbacks: List[pl.Callback]    
) -> None:
    """Makes sure everything closed properly."""
    import json
    
    conf_dict = OmegaConf.to_container(config, resolve=True)
    # print(json.dumps(conf_dict, sort_keys=False, indent=4))
    config = Dict(conf_dict) # addict Dict
    
    rec : Dict[str,str] = dict()
    # get_run_sequence_id(config.output_dir)
    # See OmegaConf.to_container().
    id = rec["id"] = get_run_sequence_id(config.output_dir, re_pattern=r"\w+_(\d+).json", pattern=".json")
    rec["date"] = config.now
    rec["name"] = config.name
    rec["text"] = config.text
    # rec["modalities"] = config.modalities
    rec["max epochs"] = config.trainer.max_epochs    
    rec["image dims"] = config.dims
    # rec["image dims padding"] = config.dims_pad
    rec["network model name"] = config.model.net._target_
    rec["network channels"] = config.model.net.channels
    rec["network norm"] = config.model.net.norm
    rec["batch size"] = config.datamodule.batch_size
    rec["loss func"] = config.model.loss._target_
    rec["loss jaccard [T/F]"] = config.model.loss.jaccard
    rec["loss squared pred [T/F]"] = config.model.loss.squared_pred
    rec["best at epoch"] = model.best_val_epoch
    # validation report
    rec["val best mean dice"] = model.best_val_dice
    rec["val best mean iou"] = model.best_val_iou
    try:
        rec["val best iou bilateral"] = model.iou_metric_bilateral
        rec["val best iou vnt3"] = model.iou_metric_vnt3
        rec["val best iou vnt4"] = model.iou_metric_vnt4

        rec["val best iou bilateral std"] = model.iou_metric_bilateral_std
        rec["val best iou vnt3 std"] = model.iou_metric_vnt3_std
        rec["val best iou vnt4 std"] = model.iou_metric_vnt4_std
    except:
        pass
    # rec["val loss"]  = model.
    # rec["train loss"]
    print("recording ...")
    from json import encoder
    class RoundingFloat(float):
        __repr__ = staticmethod(lambda x: format(x, '.2f'))
    json.encoder.c_make_encoder = None
    json.encoder.float = RoundingFloat

    with open(Path(config.output_dir) / f"result_{id:04d}.json", "w") as fp:
        json.dump(rec, indent=2, fp=fp)
    return rec


# @rank_zero_only
# def plotly(
#     config: DictConfig,
#     model: pl.LightningModule,
#     datamodule: pl.LightningDataModule,
#     trainer: pl.Trainer,
#     callbacks: List[pl.Callback]    
# ) -> None:

#     if config.clearML:
#         log.info("save labels iou ")
#         logger = task.get_logger().report_plotly(title="Labels IOU", series="labels_iou", iteration=0, figure=model.best_val_iou_labels_fig)
