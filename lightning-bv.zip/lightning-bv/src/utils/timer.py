import torch
import numpy as np
import os
import random
import time
from contextlib import contextmanager
# https://www.kaggle.com/code/yasufuminakama/ranzcr-resnet200d-3-stage-training-sub

@contextmanager
def timer(logger, name):
    t0 = time.time()
    logger.info(f'[{name}] start')
    yield
    logger.info(f'[{name}] done in {time.time() - t0:.0f} s.')


# https://www.kaggle.com/code/yasufuminakama/ranzcr-resnext50-32x4d-starter-training
def asMinutes(s):
    m = math.floor(s / 60)
    s -= m * 60
    return '%dm %ds' % (m, s)


def timeSince(since, percent):
    now = time.time()
    s = now - since
    es = s / (percent)
    rs = es - s
    return '%s (remain %s)' % (asMinutes(s), asMinutes(rs))

