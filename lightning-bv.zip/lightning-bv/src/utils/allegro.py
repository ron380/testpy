from allegroai import Task
from dataclasses import dataclass
from typing import Optional

@dataclass
class TaskParams:
    project_name: str
    task_name: str
    id: Optional[str] = None


def make_task(params: TaskParams) -> Task:
    task = Task.init(
        project_name=params.project_name,
        task_name=params.task_name,
        reuse_last_task_id=False,
        auto_connect_arg_parser=True,
        auto_resource_monitoring=False)
    
    # task_params.id = self.task.id
    return task
