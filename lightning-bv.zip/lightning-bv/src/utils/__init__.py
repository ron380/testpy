from omegaconf import OmegaConf
# custom list merge resolver
OmegaConf.register_new_resolver("merge", lambda x, y : x + y)


from .extras import *
from .data_mapping import *
from .richtable import df_to_richtable
from .allegro import TaskParams, make_task
from .image import *

