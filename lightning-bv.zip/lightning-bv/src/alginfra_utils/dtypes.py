"""
Filename: r:\pycode\BrainVentricles\alginfra_utils\dtypes.py
Path: r:\pycode\BrainVentricles\alginfra_utils
Created Date: Monday, March 14th 2022, 1:55:06 pm
Author: Ron Shefi

Copyright (c) 2022 Philips
"""

from dataclasses import dataclass
from typing import Optional, Tuple, Union
from pathlib import Path
import algpyip as ip
import numpy as np
from alginfra.image import Image3D




@dataclass
class ImageParams:
    shape: Tuple[int, int, int]
    resolution: Tuple[float, float, float]
    slope: int
    intercept: int
    vecs: np.ndarray
    name: str
    accession: str
    study_uid: str
    series_uid: str


@dataclass
class Image(ImageParams):
    data: np.ndarray

    @property
    def box(self) -> ip.IP_Box:
        dims = ip.IP_Dims(*tuple(reversed(self.shape)))
        vecs = ip.IP_BoxParams(self.vecs.astype(np.float32))
        return ip.IP_Box(dims, vecs)

    @property
    def image_3d(self) -> Image3D:
        return Image3D(data=self.data, vecs=self.vecs)

    # recommended resample
    def resample(self, target_box: ip.IP_Box, padding_val: float) -> 'Image':
        new_data = self.img3d.resample(target_box=target_box, padding_val=padding_val).img
        new_resolution = (
            target_box.GetZMmPerPixel(),
            target_box.GetYMmPerPixel(),
            target_box.GetXMmPerPixel())
        vecs = np.zeros([4, 3], dtype=np.float32)
        target_box.GetVecs(vecs)
        return Image(
            shape=new_data.shape,
            resolution=new_resolution,
            slope=self.slope,
            intercept=self.intercept,
            vecs=vecs,
            name=self.name,
            accession=self.accession,
            study_uid=self.study_uid,
            series_uid=self.series_uid,
            data=new_data)


def resample(image3d: Image, target_box: ip.IP_Box, padding_val: float) -> Image:
    new_data = image3d.resample(target_box=target_box, padding_val=padding_val).img
    new_resolution = (
        target_box.GetZMmPerPixel(),
        target_box.GetYMmPerPixel(),
        target_box.GetXMmPerPixel())
    vecs = np.zeros([4, 3], dtype=np.float32)
    target_box.GetVecs(vecs)
    return Image(
        shape=new_data.shape,
        resolution=new_resolution,
        slope=image3d.slope,
        intercept=image3d.intercept,
        vecs=vecs,
        name=image3d.name,
        accession=image3d.accession,
        study_uid=image3d.study_uid,
        series_uid=image3d.series_uid,
        data=new_data)



class IP_Box_Methods:
    @classmethod
    def sized(cls, x: ip.IP_Box):
        return {'x': x.GetWidth(), 'y': x.GetHeight(), 'z': x.GetDepth()}


    @classmethod
    def size(cls, x: ip.IP_Box):
        return [x.GetWidth(), x.GetHeight(), x.GetDepth()]

    @classmethod
    def shape(cls, x: ip.IP_Box):
        return [x.GetX(), x.GetY(), x.GetZ()]

    @classmethod
    def shaped(cls, x: ip.IP_Box):
        return {'x': x.GetX(), 'y': x.GetY(), 'z': x.GetZ()}


    @classmethod
    def resolution(cls, x: ip.IP_Box):
        return {'x': x.GetXMmPerPixel(), 'y': x.GetYMmPerPixel(), 'z': x.GetZMmPerPixel()}

    @classmethod
    def pixdim(cls, x: ip.IP_Box):
        return [x.GetXMmPerPixel(), x.GetYMmPerPixel(), x.GetZMmPerPixel()]


    @classmethod
    def info(cls, x: ip.IP_Box):
        print(f"{x=}\n{size(x)=}\n{resolution(x)=}\n{shape(x)=}\n{vecs(x)}")

    @classmethod
    def vecs(cls, x: ip.IP_Box):
        v = np.zeros([4, 3], dtype=np.float32)
        x.GetVecs(v)
        # return origin, x-axis, y-axis, z-axis as rows
        return v
    
    @classmethod
    def affine(cls, x: ip.IP_Box):
        vecs = cls.vecs(x).T
        # last column is the origin
        affine = np.roll(vecs, shift=-1, axis=1)
        affine = np.vstack([affine, [0, 0, 0, 1]])
        return affine




class RBV:
    
    def __init__(self, box: Optional[ip.IP_Box] = None) -> None:
        if box is None:
            self.rbv = ip.IP_RealBitVol()
        else:
            self.rbv =  ip.IP_RealBitVol(box)


    @property
    def box(self) -> ip.IP_Box:
        _box = self.rbv.GetBox()
        out = ip.IP_Box(_box, _box)
        return out
        # return self.rbv.Box()

    @property
    def shape(self) -> Tuple[int, int, int]:
        return self.box.GetZ(), self.box.GetY(), self.box.GetX()

    @property
    def resolution(self) -> Tuple[float, float, float]:
        return self.box.GetZMmPerPixel(), self.box.GetYMmPerPixel(), self.box.GetXMmPerPixel()

    @property
    def data(self) -> np.ndarray:
        vol = np.zeros(shape=self.shape, dtype=np.byte)
        self.rbv.GetVolume(vol)
        # if vol.sum() != self.rbv.CountBits():
        #     logger.error(f'MISMATCH {self.rbv.CountBits()=} but {vol.sum()=}')
        # else:
        #     logger.debug(f'GOOD {self.rbv.CountBits()=} == {vol.sum()=}')
        return vol

    def logical_or(self, rbv):
        self.rbv.SmoothOr(rbv.rbv)
        return self

    def numpy(self) -> np.ndarray:
        return self.data

    @property
    def count(self) -> int:
        return self.rbv.CountBits()

    @property
    def empty(self) -> bool:
        return self.count == 0

    @staticmethod
    def load_rbv(path: Union[Path, str]):   # from python3.8 otherwise enclose with ''
        rbv_ = RBV()
        if not rbv_.rbv.Read(path.with_suffix('').as_posix()):
            raise RuntimeError(f'could not load segmentation from {path}')
        return rbv_


    @property
    def vecs(self) -> np.ndarray:
        vecs = np.zeros([4, 3], dtype=np.float32)
        self.box.GetVecs(vecs)
        return vecs


    def resample(self, target_box: ip.IP_Box) -> 'RBV':
        new_rbv = ip.IP_RealBitVol(target_box)
        new_rbv.SmoothAssign(self.rbv)
        return RBV(rbv=new_rbv)

    @classmethod
    def from_numpy(cls, data: np.ndarray, box: ip.IP_Box) -> 'RBV':
        # data is a boolean array
        vol_box = ip.IP_Box(box)
        vol_box.SetDims(*data.shape[::-1])
        vol = ip.IP_ShortVolume(
            box=vol_box,
            img=2 * np.ascontiguousarray(data, dtype=np.short))
        rbv = ip.IP_RealBitVol(box)
        rbv.ThreshImage(vol, 1, 3)
        return RBV(rbv=rbv).resample(target_box=box)


@ dataclass
class Sample:
    image: Image
    liver: Optional[RBV] = None
    pv: Optional[RBV] = None
    hv: Optional[RBV] = None
    ivc: Optional[RBV] = None
    path: Optional[str] = None

    def resample(self,
                 by: Optional[str] = None,
                 box: Optional[ip.IP_Box] = None,
                 padding_val: Optional[float] = None) -> 'Sample':
        if ((by is None) and (box is None)) or ((by is not None) and (box is not None)):
            raise ValueError("please provide by or box - one and only one of them")
        elif box is None:
            box = getattr(self, by).box
        if padding_val is None:
            padding_val = self.image.data.min()
        new_sample = Sample(
            image=self.image.resample(target_box=box, padding_val=padding_val),
            path=self.path
            )
        for key in ['liver', 'pv', 'hv', 'ivc']:
            val = getattr(self, key)
            if val is not None:
                setattr(new_sample, key, val.resample(box))
        return new_sample


