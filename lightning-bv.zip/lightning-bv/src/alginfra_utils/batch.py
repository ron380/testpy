from dataclasses import dataclass
import torch
from torch.functional import Tensor

from typing import Optional, Tuple

@dataclass
class Batch:
    input: Tensor
    target: Optional[Tensor] = None
    output: Optional[Tensor] = None
    names: Optional[Tuple[str]] = None

    def to(self, device: torch.device):
        self.input = self.input.to(device)
        if self.target is not None:
            self.target = self.target.to(device)
        if self.output is not None:
            self.output = self.output.to(device)
        return self
