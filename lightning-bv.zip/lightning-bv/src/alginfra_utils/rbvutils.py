from pathlib import Path
from typing import Union, Optional, Tuple, Dict, List
from .dtypes import RBV
import numpy as np
from numpy.typing import ArrayLike
import algpyip as ip
from alginfra.image import Image3D, load_image
import sys
# from algpyip import IP_RealBitVol, IP_Box

class EmptyLabel(Exception):    
    pass

class UIDReadError(Exception):
    pass

__all__ = ['load_image3d', 'transpose_image3d', 'load_rbv', 'load_segmentations_to_dict', 'label_data']

def load_rbv(path: Union[Path, str]) -> ip.IP_RealBitVol:
    rbv = ip.IP_RealBitVol()
    if not rbv.Read(path.with_suffix('').as_posix()):
        raise RuntimeError(f'could not load segmentation from {path}')
    return rbv


def transpose_image3d(data):
    return np.transpose(data, (2, 1, 0))


def load_image3d(path: Union[Path, str]) -> Image3D:
    # image3d is python object and thus .data is the access to its numpy array
    # humsflled units
    image3d = load_image(path)

    # if is not null in image3d

    # valid for CT ok
    # for MRI skip

    # humsfield correction
    # image3d.data = image3d.data * image3d.get_slope() + float(image3d.get_intercept())
    # # the rescale parameters
    # image3d.set_slope(1)
    # image3d.set_intercept(0)
    # return datastructure
    return image3d


def load_segmentation(path: Union[Path, str], box: ip.IP_Box) -> Optional[RBV]:
    print("path = ", path)
    segmentation = ip.IP_RealBitVol(box, box)
    print("segmentations:")
    print(list(Path(path).glob('*/*.rbv')))
    rbvs = (load_rbv(file) for file in Path(path).glob('*/*.rbv'))  # if seg_type in file.stem)

    for rbv in rbvs:
        segmentation.SmoothOr(rbv)
    return segmentation if segmentation.CountBits() > 0 else None


def load_segmentations_to_dict(path: Union[Path, str], box: ip.IP_Box):
    print(f"load segmentation from path: {path}")
    print(list(Path(path).glob('*/*.rbv')))
    seg_dict = dict()
    for file in Path(path).glob('*/*.rbv'):
        key = file.parent.name  # parent of filename
        # print("name = ", key)
        segmentation_result = RBV(box)
        rbv = RBV.load_rbv(file)
        segmentation_result.logical_or(rbv)
        if  segmentation_result.empty:
            raise EmptyLabel(f"logical or {key}")
        segmentation_np = segmentation_result.numpy()
        
        seg_dict[key] = segmentation_np if not segmentation_result.empty else None

    return seg_dict


def label_data(path: Union[Path, str], box: ip.IP_Box, label_sequence: List[str]):
    
    ds = load_segmentations_to_dict(path, box)
    # print("ds = ", ds)
    if not ds:
        raise UIDReadError()

    # print("keys")
    # print(ds.keys())
    # sys.exit()
    label_data = np.zeros_like(next( iter(ds.values()) ), dtype=np.uint8)
    for i, key in enumerate(label_sequence, start=1):
        # print(f"set {i}")
        label_data[ds[key] == 1] = i

    return label_data


def rbv_to_numpy(rbv: ip.IP_RealBitVol) -> np.ndarray:
    """_summary_
        
        convert rbit_vol to numpy
        
    Args:
        rbv (IP_RealBitVol): _description_

    Returns:
        np.ndarray: _description_
    """

    shape = rbv.GetZ(), rbv.GetY(), rbv.GetX()
    data = np.zeros(shape=shape, dtype=np.byte)
    rbv.GetVolume(data)
    return data.astype(np.uint8)


def merge_rbv(path: str, name: str, box: ip.IP_Box) -> Optional[ip.IP_RealBitVol]:
    merged_rbv = ip.IP_RealBitVol(box)
    tmp_rbv = ip.IP_RealBitVol()
    for file in Path(path).glob(f'{name}*.rbv'):
        if 'merged' in file.stem:
            continue
        if not tmp_rbv.Read(file.with_suffix('').as_posix()):
            continue
        merged_rbv.SmoothOr(tmp_rbv)
    merged_rbv.Tighten()
    return merged_rbv if merged_rbv.CountBits() > 0 else None
