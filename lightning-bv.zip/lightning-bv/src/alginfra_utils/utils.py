from typing import List, Tuple

import numpy as np
from alginfra.image import load_image
from algpyip import floatArray, intArray
from offline_preprocessing.load import load_rbv
from offline_preprocessing.utils import calc_target_box, get_data, resample
from scipy.ndimage import binary_dilation, distance_transform_edt
from scipy.spatial.distance import cdist
from torch.utils.data import DataLoader, Dataset, _utils
from tqdm import tqdm


def physical_point_from_pt_indices(box, pt_indices):
    """create a physical point from point indices

    Args:
        box ([type]): [description]
        pt_indices ([type]): [description]

    Returns:
        [type]: [description]
    """
    ip_pt = intArray(3)
    ip_pt[0] = int(pt_indices[2])
    ip_pt[1] = int(pt_indices[1])
    ip_pt[2] = int(pt_indices[0])
    physical_pt = floatArray(3)
    box.IndexToPhysical(ip_pt, physical_pt)
    physical_pt = np.array([physical_pt[0], physical_pt[1], physical_pt[2]])
    return physical_pt


def pt_indices_from_physical_point(box, physical_pt, shape):
    """point indices from physical point

    Args:
        box ([type]): [description]
        physical_pt ([type]): [description]
        shape ([type]): [description]

    Returns:
        [type]: [description]
    """
    ip_pt = floatArray(3)
    ip_pt[0] = physical_pt[0]
    ip_pt[1] = physical_pt[1]
    ip_pt[2] = physical_pt[2]
    pt_indices = intArray(3)
    box.PhysicalToIndex(ip_pt, pt_indices)
    pt_indices = tuple(
        [np.clip(pt_indices[2],
                 0, shape[0] - 1),
         np.clip(pt_indices[1],
                 0, shape[1] - 1),
         np.clip(pt_indices[0],
                 0, shape[2] - 1)])

    return pt_indices


def augment_center_point(
        rbv,
        shift_center_draw='distance-transform',
        restricted_augmentations=True):
    dims = intArray(3)
    # create box from rbv
    rbv_box = rbv.Box()
    rbv_box.GetDims(dims)
    # allocate memory for lesion mask
    lesion_mask = np.zeros((dims[2], dims[1], dims[0]), dtype=np.int8)
    # fill the lesion mask with the allocated array
    rbv.GetVolume(lesion_mask)

    if shift_center_draw == 'uniform':
        dt = lesion_mask.astype(bool).astype(np.float32)
    elif shift_center_draw == 'distance-transform':
        dt = distance_transform_edt(lesion_mask)
        if restricted_augmentations:
            dt = np.exp(dt) - 1
    else:
        raise ValueError(
            "Illegal value on configuration.shift_center_draw {}, should be either 'uniform'\
            or 'distance-transform'".format(shift_center_draw))

    if np.sum(dt) > 1e-7:
        dt /= np.sum(dt)
        dt = dt.ravel()
        index = np.random.choice(len(dt), p=dt)
    else:
        index = 0
    pt = np.unravel_index(index, shape=lesion_mask.shape)
    np_physical_pt = physical_point_from_pt_indices(rbv.Box(), pt)
    return np_physical_pt


def draw_user_input(box, target, parameters):
    dt = distance_transform_edt(target)
    if parameters['user_input_type'] == 'point':
        dt /= np.sum(dt)
        dt = dt.ravel()
        index = np.random.choice(len(dt), p=dt)
        pt = np.unravel_index(index, shape=target.shape)
        physical_pt = physical_point_from_pt_indices(box, pt)
        coordinates = np.array([[physical_pt[0], physical_pt[1], physical_pt[2]]])
    elif parameters['user_input_type'] == 'line':
        dt[dt > 1] = 0
        if parameters['dilation_iterations'] > 0:
            dt = binary_dilation(dt, iterations=parameters['dilation_iterations'])

        if parameters['user_input_line_type'] == 'axial':
            pix_count = np.sum(target, axis=(1, 2))
            if parameters['user_input_line_axial_plane'] == 'largest':
                chosen_slice = np.argmax(pix_count)
            elif parameters['user_input_line_axial_plane'] == 'random':
                dts = pix_count / np.sum(pix_count)
                chosen_slice = np.random.choice(len(dts), p=dts)
            else:
                raise ValueError(
                    "user_input_line_axial_plane parameter is not 'largest' or 'random'")
            dt[:chosen_slice, ...] = 0
            dt[chosen_slice + 1:, ...] = 0

        dt = dt / np.sum(dt)
        p_dt = dt.ravel()

        index1 = np.random.choice(len(p_dt), p=p_dt)

        pt1 = np.unravel_index(index1, shape=target.shape)
        border = np.argwhere(dt)
        possible_distances = cdist([pt1], border)[0]
        possible_distances /= np.max(possible_distances)
        dist_pt2 = (
            possible_distances >= parameters['user_input_line_minimal_extent']).astype(
            np.float32)
        dist_pt2 /= np.sum(dist_pt2)
        pt2 = border[np.random.choice(len(dist_pt2), p=dist_pt2)]
        physical_pt1 = physical_point_from_pt_indices(box, pt1)
        physical_pt2 = physical_point_from_pt_indices(box, pt2)
        coordinates = np.array([[physical_pt1[0], physical_pt1[1], physical_pt1[2]],
                                [physical_pt2[0], physical_pt2[1], physical_pt2[2]]])

    return coordinates


def finalize_user_input(box, coordinates, parameters, shape):
    user_input = np.ones(shape=shape, dtype=np.float32) * parameters['window_min']

    if parameters['user_input_type'] == 'point':
        index = pt_indices_from_physical_point(box, coordinates[0], shape)
        user_input_bool = np.zeros(shape=shape, dtype=bool)
        user_input_bool[index] = True
        if parameters['user_input_point_size'] > 1:
            user_input_bool = binary_dilation(
                user_input_bool, iterations=parameters['user_input_point_size'] - 1)
        user_input[user_input_bool] = parameters['window_max']
    elif parameters['user_input_type'] == 'line':
        pt1 = pt_indices_from_physical_point(box, coordinates[0], shape)
        pt2 = pt_indices_from_physical_point(box, coordinates[1], shape)
        if pt1 == pt2:
            user_input_bool = np.zeros(shape=shape, dtype=float)
            user_input_bool[pt1] = True
            dt = binary_dilation(user_input_bool).astype(float)
            dt[pt1] = 0.0
            dt /= np.sum(dt)
            dt = dt.ravel()
            index = np.random.choice(len(dt), p=dt)
            pt2 = np.unravel_index(index, shape=shape)
            line_coordinates = [tuple(pt1), tuple(pt2)]
        else:
            line_coordinates = [tuple(x)
                                for x in np.linspace(
                                    pt1, pt2, max(abs(np.subtract(pt1, pt2))),
                                    dtype=int)]
        for p in line_coordinates:
            user_input[p] = parameters['window_max']
    return user_input


def recalibrate_lesion(
    image_path,
    lesion_path,
    output_image_shape,
    possible_resolutions,
    shift_center,
    shift_center_draw,
    pick_resolution_type,
    target_fits_pct,
    train_on_user_input,
    user_input_parameters,
    axial_lower_resolution,
    net_type='segmentation',
    segmentation_image_shape_chw=(
        0,
        0,
        0)):

    # load the image from path and rescale the image by image3d * slope + intercept
    image3d = load_image(image_path)
    slope = image3d.get_slope()
    intercept = image3d.get_intercept()

    if (slope != 1.0) or (intercept != 0.0):
        new_img = image3d.data.astype(np.float32)
        if slope != 1.0:
            new_img *= slope
        if intercept != 0.0:
            new_img += intercept
        image3d.data = new_img

    segmentation = load_rbv(paths=[lesion_path[0]])[lesion_path[1]]
    segmentation.Tighten()
    orig_box = segmentation.GetBox()

    user_input_physical_coordinates = draw_user_input(
        orig_box, get_data(segmentation), user_input_parameters)

    if net_type == 'classification':
        scale = get_target_scale(
            axial_lower_resolution,
            orig_box,
            segmentation_image_shape_chw,
            possible_resolutions,
            segmentation,
            target_fits_pct,
            user_input_physical_coordinates,
            output='scale',
            user_input_type=user_input_parameters['user_input_type'])
        res = np.min(possible_resolutions)
        box_size = get_box_size(False, output_image_shape, res)
        temp_box = calc_target_box(
            curr_box=None,
            physical_center_pt=user_input_physical_coordinates,
            target_box_physical_dims=box_size,
            target_dims=output_image_shape,
            use_curr_box=False)
    elif pick_resolution_type == 'target fits':
        box_size, new_segmentation, temp_box = get_target_scale(
            axial_lower_resolution, orig_box, output_image_shape, possible_resolutions,
            segmentation, target_fits_pct, user_input_physical_coordinates, output='full',
            user_input_type=user_input_parameters['user_input_type'])
    elif pick_resolution_type == 'random':
        res = np.random.choice(possible_resolutions, size=1)[0]
        box_size = get_box_size(axial_lower_resolution, output_image_shape, res)
        temp_box = calc_target_box(curr_box=orig_box, physical_center_pt=None,
                                   target_box_physical_dims=box_size,
                                   target_dims=output_image_shape, use_curr_box=True)

    if not net_type == 'classification':
        scale = np.zeros(len(possible_resolutions))

    if (net_type == 'classification') or (pick_resolution_type == 'random'):
        new_segmentation = resample(volume=segmentation, new_box=temp_box)

    if shift_center:
        middle = floatArray(3)
        temp_box.GetMiddle(middle)
        old_middle = np.array([middle[0], middle[1], middle[2]])
        physical_center_pt = augment_center_point(new_segmentation, shift_center_draw)
        new_box = calc_target_box(curr_box=None, physical_center_pt=physical_center_pt,
                                  target_box_physical_dims=box_size,
                                  target_dims=output_image_shape, use_curr_box=False)
        resolution = np.asanyarray(
            [new_box.GetXMmPerPixel(),
             new_box.GetYMmPerPixel(),
             new_box.GetZMmPerPixel()])
        new_segmentation = resample(volume=segmentation, new_box=new_box)
        index_shift = ((physical_center_pt - old_middle) / resolution)[::-1]
    else:
        new_box = temp_box
        index_shift = np.zeros(3, dtype=np.float32)
    new_image = resample(volume=image3d, new_box=new_box, padding_value=-1024.0)

    if train_on_user_input:
        user_input = finalize_user_input(new_box, user_input_physical_coordinates,
                                         user_input_parameters, new_image.data.shape)
    else:
        user_input = np.zeros(new_image.data.shape)
    return get_data(new_image), get_data(new_segmentation), user_input, index_shift, scale


def get_target_scale(
        axial_lower_resolution,
        orig_box,
        output_image_shape,
        possible_resolutions,
        segmentation,
        target_fits_pct=1.0,
        user_input_physical_coordinates=None,
        output='full',
        user_input_type='line'):
    for res in np.sort(possible_resolutions):
        box_size = get_box_size(axial_lower_resolution, output_image_shape, res)
        temp_box = calc_target_box(curr_box=orig_box, physical_center_pt=None,
                                   target_box_physical_dims=box_size,
                                   target_dims=output_image_shape, use_curr_box=True)
        new_segmentation = resample(volume=segmentation, new_box=temp_box)
        temp_target = get_data(new_segmentation)

        if user_input_type == 'line':
            pta = floatArray(3)
            ptb = floatArray(3)
            for i in range(3):
                pta[i] = user_input_physical_coordinates[0][i]
                ptb[i] = user_input_physical_coordinates[1][i]
            box_too_small = not (temp_box.InsideBox(pta) and temp_box.InsideBox(ptb))
        elif user_input_type == 'point':
            if target_fits_pct == 1.0:
                fit_box = temp_target
            elif (target_fits_pct < 1.0) and (target_fits_pct > 0.0):
                indices = []
                for i in range(3):
                    indices.append(int(output_image_shape[i] * (1 - target_fits_pct) / 2))
                    indices.append(int(output_image_shape[i] * (1 + target_fits_pct) / 2))
                fit_box = temp_target[indices[0]: indices[1],
                                      indices[2]: indices[3],
                                      indices[4]: indices[5]]
            else:
                raise ValueError('target_fits_pct should be a positive float up to 1.0')

            box_too_small = any(np.any(np.take(fit_box, index, axis=axis))
                                for axis in range(temp_target.ndim)
                                for index in (0, -1)) or np.sum(temp_target) == 0
        if not box_too_small:
            break
    if output == 'full':
        return box_size, new_segmentation, temp_box
    elif output == 'scale':
        return possible_resolutions.index(res)


def get_box_size(axial_lower_resolution, output_image_shape, res):
    if axial_lower_resolution:
        box_size = [res * output_image_shape[0], res * output_image_shape[1],
                    2 * res * output_image_shape[2]]
    else:
        box_size = [res * shape for shape in output_image_shape]
    return box_size
