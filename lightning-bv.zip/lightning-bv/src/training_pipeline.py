import multiprocessing
import os
from typing import List, Optional
import sys
import hydra
from omegaconf import DictConfig, OmegaConf
from pytorch_lightning import (
    Callback,
    LightningDataModule,
    LightningModule,
    Trainer,
    seed_everything,
)
from pytorch_lightning.loggers import LightningLoggerBase
import multiprocessing
from src.utils import get_logger, log_hyperparameters, finish, record
from src.utils import make_task, TaskParams
from pathlib import Path

log = get_logger(__name__)


def train(config: DictConfig) -> Optional[float]:
    """Contains the training pipeline. Can additionally evaluate model on a testset, using best
    weights achieved during training.

    Args:
        config (DictConfig): Configuration

    Returns:
        Optional[float]: Metric score for hyperparameter optimization.
    """

    # Set seed for random number generators in pytorch, numpy and python.random
    if config.get("seed"):
        seed_everything(config.seed, workers=True)


    if config.clearML:
        log.info("Initiate clearML!")
        task = make_task(TaskParams(project_name=config.project_name, task_name=f"{config.name}_{config.now}"))
        # task.connect(OmegaConf.to_yaml(config, resolve=True))
        logger = task.get_logger()
        logger.report_text("full configuration under Configuration tab in the UI")
        # task.connect(name='config', configuration=OmegaConf.to_yaml(config))
        task.connect(config)

    # Convert relative ckpt path to absolute path if necessary
    ckpt_path = config.trainer.get("resume_from_checkpoint")
    if ckpt_path and not os.path.isabs(ckpt_path):
        config.trainer.resume_from_checkpoint = os.path.join(
            hydra.utils.get_original_cwd(), ckpt_path
        )

    # Init lightning datamodule
    log.info(f"Instantiating datamodule <{config.datamodule._target_}>")
    datamodule: LightningDataModule = hydra.utils.instantiate(config.datamodule)

    # Init lightning model
    log.info(f"Instantiating model <{config.model._target_}>")
    model: LightningModule = hydra.utils.instantiate(config.model)

    # Init lightning callbacks
    callbacks: List[Callback] = []
    if "callbacks" in config:
        for _, cb_conf in config.callbacks.items():
            if "_target_" in cb_conf:
                log.info(f"Instantiating callback <{cb_conf._target_}>")
                callbacks.append(hydra.utils.instantiate(cb_conf))

    # Init lightning loggers
    logger: List[LightningLoggerBase] = []
    if "logger" in config:
        for _, lg_conf in config.logger.items():
            if "_target_" in lg_conf:
                log.info(f"Instantiating logger <{lg_conf._target_}>")
                logger.append(hydra.utils.instantiate(lg_conf))

    # Init lightning trainer
    log.info(f"Instantiating trainer <{config.trainer._target_}>")
    trainer: Trainer = hydra.utils.instantiate(
        config.trainer, callbacks=callbacks, logger=logger, _convert_="partial"
    )

    # Send some parameters from config to all lightning loggers
    log.info("Logging hyperparameters!")
    log_hyperparameters(
        config=config,
        model=model,
        datamodule=datamodule,
        trainer=trainer,
        callbacks=callbacks,
        logger=logger
    )

    # print(OmegaConf.to_yaml(config, resolve=True))
    
    # Train the model
    # if config.get("train"):
    log.info("Starting training!")

    # checl file writing to log location
    # with open("myfile.txt", "w") as file1:
    #     # Writing data to a file
    #     file1.write("Hello\n")
            
    # check for skip training
    trainer.fit(model=model, datamodule=datamodule)

    # confirm that the size of tqdm is (trainingset + validation set / batch size)
    # print(len(datamodule.train_dataloader()))
    
    # Get metric score for hyperparameter optimization
    optimized_metric = config.get("optimized_metric")
    print(optimized_metric)
    if optimized_metric and optimized_metric not in trainer.callback_metrics:
        raise Exception(
            "Metric for hyperparameter optimization not found! "
            "Make sure the `optimized_metric` in `hparams_search` config is correct!"
        )
    score = trainer.callback_metrics.get(optimized_metric)


    # Test the model. if true, going to test
    if config.get("test"):
        ckpt_path = "best"
        if not config.get("train") or config.trainer.get("fast_dev_run"):
            ckpt_path = None
        log.info("Starting testing!")
        
        # testing using the trainer
        # trainer.test(model=model, datamodule=datamodule, ckpt_path=ckpt_path)
        # with separate dataloaders to test and evaluate the iou scores using the best checkpoint for:
        # 0 - test set
        # 1 - train set
        # 2 - val set
        def traintest_dataloader_run(test_dataloader_id):
            # print("multiple test dataloaders")
            log.info(f"> test_dataloader_run {test_dataloader_id}")
            test_stages = {0: "test", 1: "train", 2: "val"}
            test_stage_ = test_stages[test_dataloader_id]
            model.test_stage = f"test[{test_dataloader_id}]"   # for example, test_dataloader[0]
            
            trainer.test(model=model, ckpt_path=ckpt_path, dataloaders=datamodule.traintest_dataloader()[test_dataloader_id])
            if config.clearML:
                log.info(f"save labels iou for {test_stage_}")
                task.get_logger().report_plotly(title=f"Labels IOU {test_stage_}", series="labels_iou", iteration=0, figure=model.best_val_iou_labels_fig)
            model.best_val_iou_labels_fig.write_html(f"labels_iou_boxplot_{test_stage_}.html")
        
        # traintest set (cf. multiple dataloaders on train-val-test)
        # test set will be run with idx = 0
        traintest_dataloader_run(0)
        # If we further want to check the prediction over the rain/val set using the best ckpt then:
        if config.get("debug_train"):
            # train set will be run with idx = 1
            traintest_dataloader_run(1)
        if config.get("debug_val"):
            # val set will be run with idx = 2
            traintest_dataloader_run(2)
        
    # Make sure everything closed properly
    log.info("Finalizing!")
    finish(
        config=config,
        model=model,
        datamodule=datamodule,
        trainer=trainer,
        callbacks=callbacks,
        logger=logger,
    )

    # record summary
    log.info("Recoding!")
    record(
        config=config,
        model=model,
        datamodule=datamodule,
        trainer=trainer,
        callbacks=callbacks
    )
    # and plotly labels
    # print(model.best_val_iou_labels_fig)
    # model.best_val_iou_labels_fig.write_html("labels_iou_boxplot.html")
    # if config.clearML:
    #     log.info("save labels iou ")
    #     logger = task.get_logger().report_plotly(title="Labels IOU", series="labels_iou", iteration=0, figure=model.best_val_iou_labels_fig)

    # Print path to best checkpoint
    if not config.trainer.get("fast_dev_run") and config.get("train"):
        log.info(f"Best model ckpt at {trainer.checkpoint_callback.best_model_path}")

    # Return metric score for hyperparameter optimization
    return score
