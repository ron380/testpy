from typing import Optional, Tuple, List, Dict, Any, Sequence
# from src.utils.extras import print_dataframe
import numpy as np
import torch
from pytorch_lightning import LightningDataModule

# utils
from tqdm import tqdm
from functools import partial
from itertools import chain
from ..utils import join
from pathlib import Path
from copy import copy
from ..utils import extract_accession_modality

# monai
# https://github.com/Project-MONAI/tutorials/blob/master/modules/image_dataset.ipynb
from monai.data import ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch
from monai.transforms import (
    Compose,
    EnsureChannelFirst,
    EnsureTyped,
    LoadImaged,
    ScaleIntensityRanged,
    ToTensord,
    LoadImage, 
    LoadImaged,
    SaveImaged,
    AsDiscreted,
    Invertd,
    AddChanneld,
    Resized,
    EnsureTyped,
)
# MONAI loss/metrics/data/inferer
from monai.inferers import sliding_window_inference
from monai.handlers.utils import from_engine
from monai.data import CacheDataset, list_data_collate, decollate_batch

from monai.config import print_config
from monai.utils import first, set_determinism


from ._datamodule import BaseDataModule
import sys

from src.utils import get_logger

log = get_logger(__name__)


class BrainVentriclesDataModule(BaseDataModule):
    """LightningDataModule for Brain Ventricles dataset.

    A DataModule implements 5 key methods:
        - prepare_data (things to do on 1 GPU/TPU, not on every GPU/TPU in distributed mode)
        - setup (things to do on every accelerator in distributed mode)
        - train_dataloader (the training dataloader)
        - val_dataloader (the validation dataloader(s))
        - test_dataloader (the test dataloader(s))

    This allows you to share a full dataset without explaining how to download,
    split, transform and process the data.

    Read the docs:
        https://pytorch-lightning.readthedocs.io/en/latest/extensions/datamodules.html
    """

    def __init__(
        self,
        dataset_dir: str,
        segmentation_dir: str,        
        num_classes: int,
        dims: Sequence,
        transforms: Dict[str, Any],
        modalities: List[str],
        **kwargs
    ):   
        super().__init__(dataset_dir, segmentation_dir, num_classes, dims, transforms)

        self.modalities = modalities
        # this line allows to access init params with 'self.hparams' attribute
        self.save_hyperparameters(logger=False)

        print_config()


    def prepare_data_dict(self) -> List[Dict[str, Any]]:
        log.info(f"> prepare_data_dict: modalities={self.modalities}")
        # Download data if needed.
        # assert isinstance(modalities, list), 'modalities must be list type [cast to python list].'
        # # print(modalities)

        # This method is called only from a single GPU.
        # Do not use it to assign state such as (self.x = y).


        dataset_dir = Path(self.dataset_dir)
        images = sorted(chain.from_iterable(dataset_dir.glob(f"*_{mod}_image.nii.gz") for mod in self.modalities))
        labels = sorted(chain.from_iterable(dataset_dir.glob(f"*_{mod}_label.nii.gz") for mod in self.modalities))
        
        # print(extract_accession_modality(images[0].name))
        
        # arrange the data in list of image/label dict (prefereable generator)
        # some hash functions which can be used
        # hash_ = lambda x: int(repr(hash(x))[-1])
        import hashlib
        
        hash_ = lambda x: int(repr(int(hashlib.sha1(x.encode('utf8')).hexdigest(), 16))[-1])
        # int(hashlib.sha .sha256(s.encode('utf-8')).hexdigest(), 16) % 10**8

        # generate the data list of dicts {image, segmentation, hash, modality, image_name, seg_name}
        data_dicts = [
            {'img': image_name, 'seg': label_name, 'hash': hash_(extract_accession_modality(image_name.name)[0]), 'mod': extract_accession_modality(image_name.name)[1], 'imgname': str(image_name.name), 'segname': str(label_name.name)}
            for image_name, label_name in zip(images, labels)
        ]
        return data_dicts


    @staticmethod
    def distribution(data_dicts: List[Dict[str, Any]]):
        from collections import Counter
        from pandas import DataFrame
        counts = Counter( (d['hash'] for d in data_dicts) )
        log.info(f"> distribution {counts}")
        counts_df = DataFrame.from_records(sorted(counts.items()), columns=['hash_id', 'count'])
        log.info(f"> distribution {counts_df}")
        # print_dataframe(DataFrame.from_dict(counts))



    @staticmethod
    def get_mean_and_std(dataloader: DataLoader) -> Tuple[float, float]:
        """ get the mean and std

        Parameters
        ----------
        dataloader : DataLoader
            _description_

        Returns
        -------
        _type_
            _description_
        """

        
        channels_sum, channels_squared_sum, num_batches = 0, 0, 0
        for k, batch in enumerate(tqdm(dataloader, desc="computing stats (mean,std)", disable=True)):
            data, seg, modality, imgname, segname = batch['img'], batch['seg'], batch['mod'], batch['imgname'], batch['segname']

            # Mean over batch, height, width, and depth, but not over the channels
            mean = torch.mean(data, dim=[0,2,3,4])
            
            log.info(f"{imgname} {segname}  shape: {data.shape} mean: {mean} max img: {torch.max(data)}  max seg: {torch.max(seg)}")
            print(torch.mean(data, dim=[0,2,3,4]))
            channels_sum += torch.mean(data, dim=[0,2,3,4])

            channels_squared_sum += torch.mean(data**2, dim=[0,2,3,4])
            num_batches += 1
        
        mean = channels_sum / num_batches

        # std = sqrt(E[X^2] - (E[X])^2)
        std = (channels_squared_sum / num_batches - mean ** 2) ** 0.5

        return mean, std

    @staticmethod
    def get_class_axial_distribution(dataloader: DataLoader) -> Dict[int, Tuple[int,int]]:
        """ get the mean and std

        Parameters
        ----------
        dataloader : DataLoader
            _description_

        Returns
        -------
        _type_
            _description_
        """

        from collections import defaultdict
        proj_sum, proj_squared_sum, num_batches = 0, 0, 0
        class_proj_dict = defaultdict(list)
        axial_length_list = list()
        
        for batch in tqdm(dataloader, desc="computing class projection length on axial axis", disable=False):
            data = batch['seg']
            segname = batch['segfile']
            # Mean over batch, height, width, and depth, but not over the channels
            axis_length = data.shape[3]
            axial_length_list.append(axis_length)
            # print(data.shape)
            for k in range(1, 5):
                # np.any axis
                # data_bool = data == k
                # print("DEBUG")
                # print(data_bool)
                # print(data_bool.shape)                
                # print(data_bool.sum())

                class_proj = torch.sum(data == k, dim=[0,1,2]).bool().numpy()
                class_proj_nz = np.flatnonzero(class_proj)
                # print("DEBUG")
                # print(segname, class_proj)
                # print(class_proj_nz)
                # print(class_proj.shape)                
                # print(class_proj.sum())
                if len(class_proj_nz) == 0:
                    class_proj_range = 0
                    log.error(f"empty slice for {segname} {k} {class_proj_range}")
                else:    
                    class_proj_range = class_proj_nz[-1] - class_proj_nz[0] + 1
                class_proj_dict[k].append(class_proj_range)
                # log.debug(segname, k, class_proj_range)
                num_batches += 1
        
        # for k, v in class_proj_dict.items():
        #     print(k, np.mean(v), np.std(v))
        print(class_proj_dict[k])
        np.savetxt("billateral_length_array.txt", np.array(class_proj_dict[k]))
        print(axial_length_list)
        np.savetxt("axial_length_array.txt", axial_length_list)
        
        return


    def get_post_transforms(self):
        num_classes = self.num_classes
        # access to transform (test preprossing)
        val_org_transforms = self.get_transforms(mode="predict")
        # https://github.com/PyTorchLightning/pytorch-lightning/discussions/7884
        post_transforms = Compose([
            EnsureTyped(keys="pred"), # data_type="numpy"),
            Invertd(
                keys="pred",
                transform=val_org_transforms,
                orig_keys="img",
                meta_keys="pred_meta_dict",
                orig_meta_keys="img_meta_dict",
                meta_key_postfix="meta_dict",
                nearest_interp=False,
                to_tensor=True,
            ),
            AsDiscreted(keys="pred", argmax=True, to_onehot=num_classes),
            # can save label
            # AsDiscreted(keys="label", to_onehot=num_classes),
            SaveImaged(keys="pred", meta_keys="pred_meta_dict", output_dir="./outputs", output_postfix="pred", separate_folder=False, resample=False)
            ])
        return post_transforms


    def compute_stats(self):
        """
            return (mean, std) for each channel

        Args:
            modality (str): _description_
        """
        log.info(f"> compute_stats {self.modalities}")        
        for modality in self.modalities:
            log.info(f"  working on modality {modality}")

            image_labels_for_modality = self.prepare_data_dict([modality])
            log.debug(f"images: {image_labels_for_modality}")
            preprocess_transformations = [
                    LoadImaged(keys=['img', 'seg']),
                    AddChanneld(keys=['img', 'seg']),                    
                ]
            transforms_ = Compose(transforms=preprocess_transformations)
            ds_ = Dataset(data=image_labels_for_modality, transform=transforms_)
            # dataloader
            loader_ = DataLoader(ds_, batch_size=1)
            print(self.get_mean_and_std(loader_))


    def compute_class_axial_distribution(self):
        """

        Args:
            modality (str): _description_
        """
        log.info("> compute_class_axial_distribution")
        image_labels_for_modality = self.prepare_data_dict()
        # print("working on ", image_labels_for_modality)
        keys = ('img', 'seg')
        dtype = (np.float32, np.uint8)
        preprocess_transformations = [
                LoadImaged(keys=keys),
                CastToTyped(keys, dtype=dtype), 
                # EnsureTyped(keys)
                # Transposed(keys=['img', 'seg'], indices=(2, 1, 0)),
                # add channel (grayscale)
                # AddChanneld(keys=['img', 'seg']),                    
            ]
        transforms_ = Compose(transforms=preprocess_transformations)
        ds_ = Dataset(data=image_labels_for_modality, transform=transforms_)
        # dataloader
        loader_ = self.stats_dataloader(ds_, batch_size=1)
        print(self.get_class_axial_distribution(loader_))
