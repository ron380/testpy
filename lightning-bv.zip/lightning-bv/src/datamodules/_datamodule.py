from typing import Optional, Tuple, List, Dict, Any, Sequence
# from src.utils.extras import print_dataframe
import numpy as np
import torch
from pytorch_lightning import LightningDataModule

# from torch.utils.data import ConcatDataset, DataLoader, Dataset, random_split
from tqdm import tqdm
from itertools import chain
from pathlib import Path
from copy import copy
from omegaconf import OmegaConf
from ..utils import join


# monai
# https://github.com/Project-MONAI/tutorials/blob/master/modules/image_dataset.ipynb
from monai.data import (ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch)
from monai.config import print_config
from monai.utils import first, set_determinism
from monai.transforms import Compose
from abc import  ABC, abstractmethod
import sys

from src.utils import get_logger

log = get_logger(__name__)


class BaseDataModule(ABC, LightningDataModule):
    """Example of LightningDataModule for MNIST dataset.

    A DataModule implements 5 key methods:
        - prepare_data (things to do on 1 GPU/TPU, not on every GPU/TPU in distributed mode)
        - setup (things to do on every accelerator in distributed mode)
        - train_dataloader (the training dataloader)
        - val_dataloader (the validation dataloader(s))
        - test_dataloader (the test dataloader(s))

    This allows you to share a full dataset without explaining how to download,
    split, transform and process the data.

    Read the docs:
        https://pytorch-lightning.readthedocs.io/en/latest/extensions/datamodules.html
    """

    def __init__(
        self,
        dataset_dir: str,
        segmentation_dir: str,
        num_classes: int,
        dims: Sequence,
        transforms: Dict[str, Any],
        **kwargs
    ):
        super().__init__()

        # self.n_classes = kwargs.get('num_classes')
        self.dataset_dir : str = dataset_dir
        self.segmentation_dir : str = segmentation_dir
        self.n_classes : int = num_classes
        self.dims : Sequence = dims
        self.transforms : Dict[str, Any] = transforms

        # this line allows to access init params with 'self.hparams' attribute
        # self.save_hyperparameters(logger=False)

        # print_config()

        # storage for data train/val/test Datasets
        self.data_train: Optional[Dataset] = None
        self.data_train_test: Optional[Dataset] = None  # the training dataset for checking scores (without augmentations)
        self.data_val: Optional[Dataset] = None
        self.data_test: Optional[Dataset] = None
        self.data_predict: Optional[Dataset] = None


    @property
    def num_classes(self) -> int:
        return self.n_classes

    @abstractmethod
    def prepare_data_dict(self) -> List[Dict[str, Any]]:
        # called by setup()
        raise NotImplementedError


    def prepare_data_dict_predict(self) -> List[Dict[str, Any]]:
        # create list of images for predict
        # called by setup()
        print(self.dataset_dir)
        dataset_dir = Path(self.dataset_dir)
        images = sorted(chain.from_iterable(dataset_dir.rglob(f"*_{mod}_*.nii.gz") for mod in self.modalities))
        print(images)
        data_dicts = [{'img': image_name} for image_name in images]
        return data_dicts


    @staticmethod
    def hash_distribution(data_dicts: List[Dict[str, Any]]):
        from collections import Counter
        from pandas import DataFrame
        counts = Counter( (d['hash'] for d in data_dicts) )
        log.info(f"> distribution {counts}")
        counts_df = DataFrame.from_records(sorted(counts.items()), columns=['hash_id', 'count'])
        log.info(f"> distribution {counts_df}")
        # print_dataframe(DataFrame.from_dict(counts))

    def setup(self, stage: Optional[str] = None, **kwargs):
        # perform train/val/test splits
        # apply transforms (defined explicitly in your datamodule)
        
        """Load data. Set variables: `self.data_train`, `self.data_val`, `self.data_test`.

        This method is called by lightning when doing `trainer.fit()` and `trainer.test()`, so be careful not to execute the random split twice! The `stage` can be used to
        differentiate whether it's called before trainer.fit()` or `trainer.test()`.

        stage could be fit/test
        """

        # separate setup for external fit
        if stage == "predict":
            predset = self.prepare_data_dict_predict(**kwargs)
            self.data_predict = Dataset(predset, transform=self.get_transforms(mode='predict'))
            log.info(f"> setup: len of dataset: pred {len(self.data_predict)}")


        data_dicts = self.prepare_data_dict(**kwargs)

        # load datasets only if they're not loaded already
        # apply transforms for trainset, valset, and testset
        if not self.data_train and not self.data_val and not self.data_test:
            trainset, testset, valset = [], [], []
            for d in data_dicts:
                h_ = d['hash']  # retrieve the hash code from the stream
                if h_ == self.hparams.val_split_hash_id:
                    valset.append(d)
                elif h_ == self.hparams.test_split_hash_id:
                    testset.append(d)
                else:
                    trainset.append(d)
            
            # set the following datasets:
            # - self.data_train, 
            # - self.data_val, 
            # - self.data_test 
            # - self.data_train_test 
            if self.hparams.cache: # use cache, with possible adding cache_params (not specified)
                self.data_train = CacheDataset(trainset, transform=self.get_transforms(mode='train'))
            else:
                self.data_train = Dataset(trainset, transform=self.get_transforms(mode='train'))

            self.data_train_test = Dataset(trainset, transform=self.get_transforms(mode='train_test'))
            self.data_val = Dataset(valset, transform=self.get_transforms(mode='val'))
            self.data_test = Dataset(testset, transform=self.get_transforms(mode='test'))

            log.info(f"> setup: len of datasets: train: {len(self.data_train)}, val {len(self.data_val)}, test {len(self.data_test)}")


    @staticmethod
    def get_mean_and_std(dataloader: DataLoader) -> Tuple[float, float]:
        """ get the mean and std per channel

        Parameters
        ----------
        dataloader : DataLoader
            _description_

        Returns
        -------
        _type_
            _description_
        """
        
        channels_sum, channels_squared_sum, num_batches = 0, 0, 0
        for k, batch in enumerate(tqdm(dataloader, desc="computing stats (mean,std)", disable=True)):
            data, seg, modality, imgname, segname = batch['img'], batch['seg'], batch['mod'], batch['imgname'], batch['segname']
            
            # Mean over batch, height, width, and depth, passing over the channels
            # in 2d, use dim=[0,2,3]
            mean = torch.mean(data, dim=[0,2,3,4])
            
            log.info(f"{imgname} {segname}  shape: {data.shape} mean: {mean} max img: {torch.max(data)}  max seg: {torch.max(seg)}")
            print(torch.mean(data, dim=[0,2,3,4]))
            channels_sum += torch.mean(data, dim=[0,2,3,4])

            channels_squared_sum += torch.mean(data**2, dim=[0,2,3,4])
            num_batches += 1
        
        mean = channels_sum / num_batches

        # std = sqrt(E[X^2] - (E[X])^2)
        std = (channels_squared_sum / num_batches - mean ** 2) ** 0.5

        return mean, std

    
    def get_transforms(self, mode="train", keys=("img", "seg")):
        """
        returns a composed transform for train/val/infer. and other verification tasks
        
        """
        assert mode in ("train", "train_test", "train_check_transforms", "val", "test", "predict", "test_check_transforms")
        
        # get preprocess transformations
        preprocess_xforms = OmegaConf.to_container(self.transforms['preprocess_transforms'], resolve=True) if self.transforms['preprocess_transforms'] else None
        # get training transformations
        train_xforms = OmegaConf.to_container(self.transforms['train_transforms'], resolve=True) if self.transforms['train_transforms'] else None
        # check transformation used in training via a viewer
        train_check_xforms = OmegaConf.to_container(self.transforms['train_check_transforms'], resolve=True) if self.transforms.get('train_check_transforms', None) else None
        test_check_xforms = OmegaConf.to_container(self.transforms['test_check_transforms'], resolve=True) if self.transforms.get('test_check_transforms', None) else None


        # get resize to network transformation        
        resize_xforms = OmegaConf.to_container(self.transforms['resize_transforms'], resolve=True) if self.transforms['resize_transforms'] else None
        
        # get resize to network transformation (image only)
        resize_img_xforms = OmegaConf.to_container(self.transforms['resize_img_transforms'], resolve=True) if self.transforms['resize_img_transforms'] else None
        
        # label transform
        label_xforms =  OmegaConf.to_container(self.transforms['label_transforms'], resolve=True) if self.transforms['label_transforms'] else None

        # loader transform
        loader_xforms =  OmegaConf.to_container(self.transforms['loader_transforms'], resolve=True) if self.transforms['loader_transforms'] else None

        # load transform (image only) and possibly transpose
        loader_img_xforms = OmegaConf.to_container(self.transforms['loader_img_transforms'], resolve=True) if self.transforms['loader_img_transforms'] else None

        # type transform
        typed_xforms =  OmegaConf.to_container(self.transforms['typed_transforms'], resolve=True) if self.transforms['typed_transforms'] else None

        # type transform (image only) 
        typed_img_xforms =  OmegaConf.to_container(self.transforms['typed_img_transforms'], resolve=True) if self.transforms['typed_img_transforms'] else None

        pred_xforms =  OmegaConf.to_container(self.transforms['pred_transforms'], resolve=True) if self.transforms['pred_transforms'] else None

        if mode == "train":
            # adding the training transformations
            xforms = join(loader_xforms, resize_xforms, label_xforms, preprocess_xforms, train_xforms, typed_xforms)
            dtype = (np.float32, np.uint8) # not used
        elif mode == "val":
            # no adding transformation for validation and testing
            xforms = join(loader_xforms, resize_xforms, label_xforms, preprocess_xforms, typed_xforms)
            dtype = (np.float32, np.uint8) # not used
        elif mode in ("train_test", "test"):     
            # no adding transformation for validation and testing
            xforms = join(loader_xforms, resize_xforms, label_xforms, preprocess_xforms, typed_xforms)
            dtype = (np.float32, np.uint8) # not used
        elif mode  == "predict":     
            # no adding transformation for validation and testing
            xforms = join(loader_img_xforms, resize_img_xforms, preprocess_xforms, typed_img_xforms)
            dtype = (np.float32, np.uint8) # not used
        elif mode in "train_check_transforms":            
            # check with external viewer the transformation applied on the training set
            xforms = join(loader_xforms, resize_xforms, label_xforms, preprocess_xforms, train_check_xforms, typed_xforms)
            dtype = (np.float32, np.uint8) # not used
        elif mode in "test_check_transforms":            
            # check with external viewer the transformation applied on the training set
            xforms = join(test_check_xforms, typed_img_xforms)
            dtype = (np.float32, np.uint8) # not used
        elif mode in "predex":   # for new version using yaml config (currently not used)         
            # no adding transformation for validation and testing
            preprocess_ = Compose(preprocess_xforms)
            pred_xforms[0] = pred_xforms[0](transform=preprocess_)
            xforms = pred_xforms
            
        # ensuring the final type for transformations is done using `typed_xforms`       
        log.info(f"\n\nfinal xforms mode: {mode}\n{xforms}")
        # sys.exit()
        return Compose(xforms)


    def compute_stats(self):
        """
            return (mean, std) for each channel

        Args:
        
        """
        from monai.transforms import LoadImaged, AddChanneld, Compose
        
        log.info(f"...  compute_stats")

        image_labels = self.prepare_data_dict()
        log.debug(f"images: {image_labels}")
        preprocess_transformations = [
                LoadImaged(keys=['img', 'seg']),
                AddChanneld(keys=['img', 'seg']),                    
            ]
        transforms_ = Compose(transforms=preprocess_transformations)
        ds_ = Dataset(data=image_labels, transform=transforms_)
        # dataloader
        loader_ = DataLoader(ds_, batch_size=1)
        print(self.get_mean_and_std(loader_))


    def compute_hash_distribution(self):
        """
            return hash counts 

        Args:
            modality (str): _description_
        """
        log.info("> compute_stats")

        image_labels = self.prepare_data_dict()
        self.distribution(image_labels)

    
    def train_dataloader(self):
        train_loader = DataLoader(
            dataset=self.data_train, 
            batch_size=self.hparams.batch_size,
            shuffle=True, # in order to reduce overfitting
            num_workers=self.hparams.num_workers, # 4
            pin_memory=self.hparams.pin_memory,
            collate_fn=list_data_collate,
            persistent_workers=self.hparams.persistent_workers
        )
        return train_loader


    def val_dataloader(self):
        val_dataloader = DataLoader(
            dataset=self.data_val,
            batch_size=1,  # self.hparams.batch_size,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False
        )
        return val_dataloader

    # multiple dataloaders for testing - 
    # - dataloader idx [0] is the test set
    # - dataloader idx [1] is the train_test set (train dataset without augmentations)
    # - dataloader idx [2] is the validation set
    # all sets are used to get the scores using the best ckpt 
    def traintest_dataloader(self):
        test_loader = [
            # test set [0]
            DataLoader(
            dataset=self.data_test,
            batch_size=1,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False),
            # train set [1] - used for debuging and check scores over train set
            DataLoader(
            dataset=self.data_train_test,
            batch_size=1,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False),
            # val set [2] - used for debuging and check scores over validation set
            DataLoader(
            dataset=self.data_val,
            batch_size=1,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False),
        ]
        return test_loader


    def test_dataloader(self):
        test_loader = DataLoader(
            dataset=self.data_test,
            batch_size=1,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False),
        return test_loader


    def predict_dataloader(self):
        predict_loader = DataLoader(
            # dataset=self.data_test,
            dataset=self.data_predict,
            batch_size=1,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False,
        )
        return predict_loader


    def stats_dataloader(self, ds, batch_size):
        val_dataloader = DataLoader(
            dataset=ds,
            batch_size=batch_size,  # self.hparams.batch_size,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False
        )
        return val_dataloader
