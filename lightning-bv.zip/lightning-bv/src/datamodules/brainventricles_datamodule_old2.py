from typing import Optional, Tuple, List, Dict, Any, Sequence
from src.utils.extras import print_dataframe
import numpy as np
import torch
from pytorch_lightning import LightningDataModule
# from torch.utils.data import ConcatDataset, DataLoader, Dataset, random_split
from torchvision.transforms import transforms as torch_transforms
from tqdm import tqdm
import glob
from functools import partial
from itertools import chain
from ..utils import extract_accession_modality
from pathlib import Path
# monai
# https://github.com/Project-MONAI/tutorials/blob/master/modules/image_dataset.ipynb
from monai.data import ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch
from monai.transforms import (
    Compose,
    AdjustContrastd, 
    EnsureChannelFirst,
    EnsureTyped,
    CastToTyped,
    NormalizeIntensityd,
    RandAdjustContrast,
    Orientationd,
    Spacingd, 
    LoadImaged,
    ScaleIntensityRanged,
    ToTensord,
    LoadImage, 
    LoadImaged,
    AddChanneld,
    Resized,
    EnsureTyped,
    RandRotate90d,
    RandAffined,
    RandFlipd,
    RandGaussianNoised,
    Identity)
from monai.transforms.utility.dictionary import (    
    Transposed)
from monai.config import print_config
from monai.utils import first, set_determinism

# local implementations
from ..transforms import (
    CTThresholdIntensityd, 
    ModalityBasedTransformd)

import sys

from src.utils import get_logger

log = get_logger(__name__)


class BrainVentriclesDataModule(LightningDataModule):
    """Example of LightningDataModule for MNIST dataset.

    A DataModule implements 5 key methods:
        - prepare_data (things to do on 1 GPU/TPU, not on every GPU/TPU in distributed mode)
        - setup (things to do on every accelerator in distributed mode)
        - train_dataloader (the training dataloader)
        - val_dataloader (the validation dataloader(s))
        - test_dataloader (the test dataloader(s))

    This allows you to share a full dataset without explaining how to download,
    split, transform and process the data.

    Read the docs:
        https://pytorch-lightning.readthedocs.io/en/latest/extensions/datamodules.html
    """

    def __init__(
        self,
        dataset_dir: str,        
        num_classes: int,
        dims: Sequence,
        transforms: Dict[str, Any],
        batch_size: int = 4,
        num_workers: int = 0,
        pin_memory: bool = False,
        **kwargs
    ):
        super().__init__()

        # self.n_classes = kwargs.get('num_classes')
        self.dataset_dir = dataset_dir
        self.n_classes = num_classes
        self.transforms = transforms
        # this line allows to access init params with 'self.hparams' attribute
        self.save_hyperparameters(logger=False)

        print_config()

        print(self.transforms)

        # data transformations
        # self.transforms = transforms.Compose(
        #     [transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))]
        # )

        # storage for data train/val/test
        self.data_train: Optional[Dataset] = None
        self.data_val: Optional[Dataset] = None
        self.data_test: Optional[Dataset] = None

    @property
    def num_classes(self) -> int:
        return self.n_classes

    def prepare_data_dict(self, modalities: List[str]) -> List[Dict[str, Any]]:
        log.info(f"> prepare_data_dict: modalities={modalities}")
        # Download data if needed.

        assert isinstance(modalities, list), 'modalities must be list type'

        # This method is called only from a single GPU.
        # Do not use it to assign state (self.x = y).
        
        # MNIST(self.hparams.data_dir, train=True, download=True)
        # MNIST(self.hparams.data_dir, train=False, download=True)


        # modalities = ['T1']
        # sys.exit()
        # print(modalities)

        # dataset_dir = Path(self.hparams.dataset_dir)
        dataset_dir = Path(self.dataset_dir)
        # print(dataset_dir)
        # images = sorted(chain( *[glob.glob(f"{dataset_dir}/*_{mod}_image.nii.gz") for mod in modalities] ))
        # labels = sorted(chain( *[glob.glob(f"{dataset_dir}/*_{mod}_label.nii.gz") for mod in modalities] ))
        # images = sorted(chain.from_iterable(glob.iglob(f"{dataset_dir}/*_{mod}_image.nii.gz") for mod in modalities))
        images = sorted(chain.from_iterable(dataset_dir.glob(f"*_{mod}_image.nii.gz") for mod in modalities))
        labels = sorted(chain.from_iterable(dataset_dir.glob(f"*_{mod}_label.nii.gz") for mod in modalities))
        # print(images)
        # sys.exit()
        # print(images[0])
        # print(images[0].name)
        print(extract_accession_modality(images[0].name))
        
        # sys.exit()
        # arrange the data in list of image/label dict (prefereable generator)
        # hash_ = lambda x: int(repr(hash(x))[-1])
        import hashlib
        
        hash_ = lambda x: int(repr(int(hashlib.sha1(x.encode('utf8')).hexdigest(), 16))[-1])
        # int(hashlib.sha .sha256(s.encode('utf-8')).hexdigest(), 16) % 10**8

        # generate the data list of {image3d, segmentation, hash, modality}
        data_dicts = [
            {'img': image_name, 'seg': label_name, 'hash': hash_(extract_accession_modality(image_name.name)[0]), 'mod': extract_accession_modality(image_name.name)[1], 'segfile': label_name.name}
            for image_name, label_name in zip(images, labels)
        ]
        
        # self.data_dicts = data_dicts
        return data_dicts


    @staticmethod
    def distribution(data_dicts: List[Dict[str, Any]]):
        from collections import Counter
        from pandas import DataFrame
        counts = Counter( (d['hash'] for d in data_dicts) )
        log.info(f"> distribution {counts}")
        counts_df = DataFrame.from_records(sorted(counts.items()), columns=['hash_id', 'count'])
        log.info(f"> distribution {counts_df}")
        # print_dataframe(DataFrame.from_dict(counts))

    def setup(self, stage: Optional[str] = None):
        # perform train/val/test splits
        # apply transforms (defined explicitly in your datamodule)
        
        """Load data. Set variables: `self.data_train`, `self.data_val`, `self.data_test`.

        This method is called by lightning when doing `trainer.fit()` and `trainer.test()`,
        so be careful not to execute the random split twice! The `stage` can be used to
        differentiate whether it's called before trainer.fit()` or `trainer.test()`.

        stage could be fit/test
        """

        log.info(f">setup: modalities={self.hparams.modalities}")

        data_dicts = self.prepare_data_dict(self.hparams.modalities)

        # load datasets only if they're not loaded already
        if not self.data_train and not self.data_val and not self.data_test:
            # trainset = BrainVentricles(self.hparams.dataset_dir, train=True, transform=self.transforms)
            # testset = BrainVentricles(self.hparams.dataset_dir, train=False, transform=self.transforms)
            # dataset = ConcatDataset(datasets=[trainset, testset])
            
            # self.data_train, self.data_val, self.data_test = random_split(
            #     dataset=dataset,
            #     lengths=self.hparams.train_val_test_split,
            #     generator=torch.Generator().manual_seed(42),
            # )
            trainset, testset, valset = [], [], []
            for d in data_dicts:
                h_ = d['hash']
                if h_ == self.hparams.val_split_hash_id:
                    valset.append(d)
                elif h_ == self.hparams.test_split_hash_id:
                    testset.append(d)
                else:
                    trainset.append(d)
            
            self.data_train, self.data_val, self.data_test = trainset, valset, testset

        log.info(f"> setup: len of datasets: train: {self.train_val}, val {self.data_val}, test {self.data_test}")


    @staticmethod
    def get_mean_and_std(dataloader: DataLoader) -> Tuple[float, float]:
        """ get the mean and std

        Parameters
        ----------
        dataloader : DataLoader
            _description_

        Returns
        -------
        _type_
            _description_
        """

        
        channels_sum, channels_squared_sum, num_batches = 0, 0, 0
        for batch in tqdm(dataloader, desc="computing stats (mean,std)", disable=True):
            data = batch['img']
            # Mean over batch, height, width, and depth, but not over the channels
            print(data.shape)
            print(torch.mean(data, dim=[0,2,3,4]))
            channels_sum += torch.mean(data, dim=[0,2,3,4])

            channels_squared_sum += torch.mean(data**2, dim=[0,2,3,4])
            num_batches += 1
        
        mean = channels_sum / num_batches

        # std = sqrt(E[X^2] - (E[X])^2)
        std = (channels_squared_sum / num_batches - mean ** 2) ** 0.5

        return mean, std

    @staticmethod
    def get_class_axial_distribution(dataloader: DataLoader) -> Dict[int, Tuple[int,int]]:
        """ get the mean and std

        Parameters
        ----------
        dataloader : DataLoader
            _description_

        Returns
        -------
        _type_
            _description_
        """

        from collections import defaultdict
        proj_sum, proj_squared_sum, num_batches = 0, 0, 0
        class_proj_dict = defaultdict(list)
        axial_length_list = list()
        
        for batch in tqdm(dataloader, desc="computing class projection length on axial axis", disable=False):
            data = batch['seg']
            segname = batch['segfile']
            # Mean over batch, height, width, and depth, but not over the channels
            axis_length = data.shape[3]
            axial_length_list.append(axis_length)
            # print(data.shape)
            for k in range(1, 5):
                # np.any axis
                # data_bool = data == k
                # print("DEBUG")
                # print(data_bool)
                # print(data_bool.shape)                
                # print(data_bool.sum())

                class_proj = torch.sum(data == k, dim=[0,1,2]).bool().numpy()
                class_proj_nz = np.flatnonzero(class_proj)
                # print("DEBUG")
                # print(segname, class_proj)
                # print(class_proj_nz)
                # print(class_proj.shape)                
                # print(class_proj.sum())
                if len(class_proj_nz) == 0:
                    class_proj_range = 0
                    log.error(f"empty slice for {segname} {k} {class_proj_range}")
                else:    
                    class_proj_range = class_proj_nz[-1] - class_proj_nz[0] + 1
                class_proj_dict[k].append(class_proj_range)
                # log.debug(segname, k, class_proj_range)
                num_batches += 1
        
        # for k, v in class_proj_dict.items():
        #     print(k, np.mean(v), np.std(v))
        print(class_proj_dict[k])
        np.savetxt("billateral_length_array.txt", np.array(class_proj_dict[k]))
        print(axial_length_list)
        np.savetxt("axial_length_array.txt", axial_length_list)
        
        return


    def get_transforms(self, mode="train", keys=("img", "seg", "mod")):
        """returns a composed transform for train/val/infer."""

        # xforms = [
        #     LoadImaged(keys),
        #     AddChanneld(keys),
        #     Orientationd(keys, axcodes="LPS"),
        #     Spacingd(keys, pixdim=(1.25, 1.25, 5.0), mode=("bilinear", "nearest")[: len(keys)]),
        #     ScaleIntensityRanged(keys[0], a_min=-1000.0, a_max=500.0, b_min=0.0, b_max=1.0, clip=True),
        # ]

        dims = self.hparams.dims


        # preprocess
        xforms = [
            LoadImaged(keys=['img', 'seg']),
            AddChanneld(keys=['img', 'seg']),
            Orientationd(keys=["img", "seg"], axcodes="RAS"),

            # ZScore std dev [-4, -4] to [0, 1]
            NormalizeIntensityd(keys=['img']),
            ScaleIntensityRanged(keys=["img"], a_min=-4, a_max=4, b_min=0, b_max=1, clip=True),

            Resized(keys=['img', 'seg'],
                spatial_size=dims,
                mode=['trilinear', 'nearest'],
                align_corners=[False, None]
            ) if dims is not None else Identity(),
            Transposed(keys=['img', 'seg'], indices=(2, 1, 0)),
        ]

        if mode == "train":
            xforms.extend(
                [
                    RandAffined(
                        keys=['img', 'seg'],
                        prob=0.15,
                        rotate_range=(0.05, 0.05, None),  # 3 parameters control the transform on 3 dimensions
                        scale_range=(0.1, 0.1, None),
                        mode=("bilinear", "nearest"),
                        as_tensor_output=False,
                    ),
                    # RandCropByPosNegLabeld(keys, label_key=keys[1], spatial_size=(192, 192, 16), num_samples=3),
                    RandGaussianNoised(keys[0], prob=0.15, std=0.05),
                    RandFlipd(keys, spatial_axis=0, prob=0.5),
                    RandFlipd(keys, spatial_axis=1, prob=0.5),
                    RandFlipd(keys, spatial_axis=2, prob=0.5),
                ]
            )
            dtype = (np.float32, np.uint8)
        if mode == "val":
            dtype = (np.float32, np.uint8)
        if mode == "infer":
            dtype = (np.float32,)

        xforms.extend([CastToTyped(keys, dtype=dtype), EnsureTyped(keys)])
        return Compose(xforms)



    def compute_stats(self):
        """
            return (mean, std) for each channel

        Args:
            modality (str): _description_
        """
        log.info(f"> compute_stats {self.hparams.modalities}")        
        modalities = self.hparams.modalities
        for modality in modalities:
            log.info(f"  working on modality {modality}")

            image_labels_for_modality = self.prepare_data_dict([modality])
            log.debug(f"images: {image_labels_for_modality}")
            preprocess_transformations = [
                    LoadImaged(keys=['img', 'seg']),
                    # Transposed(keys=['img', 'seg'], indices=(2, 1, 0)),
                    AddChanneld(keys=['img', 'seg']),                    
                ]
            transforms_ = Compose(transforms=preprocess_transformations)
            ds_ = Dataset(data=image_labels_for_modality, transform=transforms_)
            # dataloader
            loader_ = DataLoader(ds_, batch_size=1)
            print(self.get_mean_and_std(loader_))


    def compute_class_axial_distribution(self):
        """
            return (mean, std) for each channel

        Args:
            modality (str): _description_
        """
        log.info("> compute_class_axial_distribution")
        modalities = list(self.hparams.modalities)
        # print(modalities)
        # print(type(modalities))
        # assert isinstance(modalities, list), "modalities must be list."


        image_labels_for_modality = self.prepare_data_dict(modalities)
        print("working on ", image_labels_for_modality)
        keys = ('img', 'seg')
        dtype = (np.float32, np.uint8)
        preprocess_transformations = [
                LoadImaged(keys=keys),
                CastToTyped(keys, dtype=dtype), 
                # EnsureTyped(keys)
                # Transposed(keys=['img', 'seg'], indices=(2, 1, 0)),
                # add channel (grayscale)
                # AddChanneld(keys=['img', 'seg']),                    
            ]
        transforms_ = Compose(transforms=preprocess_transformations)
        ds_ = Dataset(data=image_labels_for_modality, transform=transforms_)
        # dataloader
        loader_ = self.stats_dataloader(ds_, batch_size=1)
        print(self.get_class_axial_distribution(loader_))



    def compute_distribution(self):
        """
            return (mean, std) for each channel for the dataset

        Args:
            modality (str): _description_
        """
        log.info("> compute_stats")
        modalities = self.hparams.modalities

        image_labels_for_modality = self.prepare_data_dict(modalities)
        self.distribution(image_labels_for_modality)


    # reference: spleen_lightning
    def train_dataloader(self):
        train_loader = DataLoader(
            dataset=self.train_ds, 
            batch_size=self.hparams.batch_size, # 2
            # shuffle=True,
            num_workers=self.hparams.num_workers, # 4
            pin_memory=self.hparams.pin_memory,
            collate_fn=list_data_collate,
        )
        return train_loader


    def val_dataloader(self):
        val_dataloader = DataLoader(
            dataset=self.val_ds,
            batch_size=1,  # self.hparams.batch_size,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False
        )
        return val_dataloader

    # TBD
    def test_dataloader(self):
        test_loader = DataLoader(
            dataset=self.data_test,
            batch_size=self.hparams.batch_size,
            num_workers=self.hparams.num_workers,
            pin_memory=self.hparams.pin_memory,
            shuffle=False,
        )
        return test_loader

    def stats_dataloader(self, ds, batch_size):
        val_dataloader = DataLoader(
            dataset=ds,
            batch_size=batch_size,  # self.hparams.batch_size,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False
        )
        return val_dataloader
