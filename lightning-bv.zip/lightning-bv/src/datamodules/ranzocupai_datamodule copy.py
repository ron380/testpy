from typing import Optional, Tuple, List, Dict, Any, Sequence
# from src.utils.extras import print_dataframe
import numpy as np
import torch
from pytorch_lightning import LightningDataModule
# from torch.utils.data import ConcatDataset, DataLoader, Dataset, random_split
from torchvision.transforms import transforms as torch_transforms
from tqdm import tqdm
import glob
from functools import partial
from itertools import chain
from ..utils import extract_accession_modality
from pathlib import Path
from copy import copy
from omegaconf import OmegaConf
# monai
# https://github.com/Project-MONAI/tutorials/blob/master/modules/image_dataset.ipynb
from monai.data import ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch
from monai.transforms import (
    Compose,
    EnsureChannelFirst,
    EnsureTyped,
    CastToTyped,
    LoadImaged,
    ScaleIntensityRanged,
    ToTensord,
    LoadImage, 
    LoadImaged,
    SaveImaged,
    AsDiscreted,
    Invertd,
    AddChanneld,
    Resized,
    EnsureTyped, )

from monai.transforms.utility.dictionary import (    
    Transposed)
from monai.config import print_config
from monai.utils import first, set_determinism

# local implementations
from ..transforms import (
    CTThresholdIntensityd, 
    ModalityBasedTransformd)

import sys

from src.utils import get_logger

log = get_logger(__name__)


class RANZOCUPAIDataModule(LightningDataModule):
    """Example of LightningDataModule for MNIST dataset.

    A DataModule implements 5 key methods:
        - prepare_data (things to do on 1 GPU/TPU, not on every GPU/TPU in distributed mode)
        - setup (things to do on every accelerator in distributed mode)
        - train_dataloader (the training dataloader)
        - val_dataloader (the validation dataloader(s))
        - test_dataloader (the test dataloader(s))

    This allows you to share a full dataset without explaining how to download,
    split, transform and process the data.

    Read the docs:
        https://pytorch-lightning.readthedocs.io/en/latest/extensions/datamodules.html
    """

    def __init__(
        self,
        dataset_dir: str,
        segmentation_dir: str,
        other_dir: str,
        num_classes: int,
        dims: Sequence,
        transforms: Dict[str, Any],
        **kwargs
    ):
        super().__init__()

        # self.n_classes = kwargs.get('num_classes')
        self.dataset_dir = dataset_dir
        self.segmentation_dir = segmentation_dir
        self.other_dir = other_dir
        self.n_classes = num_classes
        self.transforms = transforms
        self.dims = dims
        # this line allows to access init params with 'self.hparams' attribute
        self.save_hyperparameters(logger=False)

        print_config()

        # show transformations dict
        # print(self.transforms)

        # storage for data train/val/test Datasets
        self.data_train: Optional[Dataset] = None
        self.data_val: Optional[Dataset] = None
        self.data_test: Optional[Dataset] = None

    @property
    def num_classes(self) -> int:
        return self.n_classes


    def prepare_data_dict(self) -> List[Dict[str, Any]]:
        log.info(f"> prepare_data_dict ")
        # Download data if needed.
        
        # This method is called only from a single GPU.
        # Do not use it to assign state (self.x = y).
        # for example, 
        # MNIST(self.hparams.data_dir, train=True, download=True)
        # MNIST(self.hparams.data_dir, train=False, download=True)


        dataset_dir = Path(self.dataset_dir)
        segmentation_dir = Path(self.segmentation_dir)
        other_dir = Path(self.other_dir)
        # print(dataset_dir)
        log.info(f"reading from {dataset_dir}")
        images = sorted(dataset_dir.glob("*.mha") )
        labels = sorted(segmentation_dir.glob("*.mha") )
        others = sorted(other_dir.glob("*.png") )
        # print(images)
        # sys.exit()
        # print(images[0])
        # print(images[0].name)
        
        
        # hash_ = lambda x: int(repr(hash(x))[-1])
        import hashlib, os
        
        hash_ = lambda x: int(repr(int(hashlib.sha1(x.encode('utf8')).hexdigest(), 16))[-1])
        # int(hashlib.sha .sha256(s.encode('utf-8')).hexdigest(), 16) % 10**8
        extract_basename_ = lambda x: os.path.splitext(x)[0]
        
        # print(extract_basename_(images[0].name))
        # generate the data list of {image3d, segmentation, hash, modality}
        data_dicts = [
            {'img': image_name, 'seg': label_name, 'other': other_name, 'hash': hash_(extract_basename_(image_name.name)), 'segname': str(label_name.name)}
            for image_name, label_name, other_name in zip(images, labels, others)
        ]
        
        # print(data_dicts)
        
        return data_dicts


    @staticmethod
    def distribution(data_dicts: List[Dict[str, Any]]):
        from collections import Counter
        from pandas import DataFrame
        counts = Counter( (d['hash'] for d in data_dicts) )
        log.info(f"> distribution {counts}")
        counts_df = DataFrame.from_records(sorted(counts.items()), columns=['hash_id', 'count'])
        log.info(f"> distribution {counts_df}")
        # print_dataframe(DataFrame.from_dict(counts))

    def setup(self, stage: Optional[str] = None):
        # perform train/val/test splits
        # apply transforms (defined explicitly in your datamodule)
        
        """Load data. Set variables: `self.data_train`, `self.data_val`, `self.data_test`.

        This method is called by lightning when doing `trainer.fit()` and `trainer.test()`,
        so be careful not to execute the random split twice! The `stage` can be used to
        differentiate whether it's called before trainer.fit()` or `trainer.test()`.

        stage could be fit/test
        """

        log.info(f">setup: modalities={self.hparams.modalities}")

        data_dicts = self.prepare_data_dict(list(self.hparams.modalities))

        # load datasets only if they're not loaded already
        if not self.data_train and not self.data_val and not self.data_test:
            # trainset = BrainVentricles(self.hparams.dataset_dir, train=True, transform=self.transforms)
            # testset = BrainVentricles(self.hparams.dataset_dir, train=False, transform=self.transforms)
            # dataset = ConcatDataset(datasets=[trainset, testset])
            
            # self.data_train, self.data_val, self.data_test = random_split(
            #     dataset=dataset,
            #     lengths=self.hparams.train_val_test_split,
            #     generator=torch.Generator().manual_seed(42),
            # )
            trainset, testset, valset = [], [], []
            for d in data_dicts:
                h_ = d['hash']  # retrieve the hash code from the stream
                if h_ == self.hparams.val_split_hash_id:
                    valset.append(d)
                elif h_ == self.hparams.test_split_hash_id:
                    testset.append(d)
                else:
                    trainset.append(d)
            
            # self.data_train, self.data_val, self.data_test = trainset, valset, testset
            self.data_train = Dataset(trainset, transform=self.get_transforms(mode='train'))
            self.data_val = Dataset(valset, transform=self.get_transforms(mode='val'))
            self.data_test = Dataset(testset, transform=self.get_transforms(mode='test'))

        log.info(f"> setup: len of datasets: train: {len(self.data_train)}, val {len(self.data_val)}, test {len(self.data_test)}")


    @staticmethod
    def get_mean_and_std(dataloader: DataLoader) -> Tuple[float, float]:
        """ get the mean and std

        Parameters
        ----------
        dataloader : DataLoader
            _description_

        Returns
        -------
        _type_
            _description_
        """

        
        channels_sum, channels_squared_sum, num_batches = 0, 0, 0
        for k, batch in enumerate(tqdm(dataloader, desc="computing stats (mean,std)", disable=True)):
            data, seg, modality, imgname, segname = batch['img'], batch['seg'], batch['mod'], batch['imgname'], batch['segname']

            # Mean over batch, height, width, and depth, but not over the channels
            mean = torch.mean(data, dim=[0,2,3,4])
            
            log.info(f"{imgname} {segname}  shape: {data.shape} mean: {mean} max img: {torch.max(data)}  max seg: {torch.max(seg)}")
            print(torch.mean(data, dim=[0,2,3,4]))
            channels_sum += torch.mean(data, dim=[0,2,3,4])

            channels_squared_sum += torch.mean(data**2, dim=[0,2,3,4])
            num_batches += 1
        
        mean = channels_sum / num_batches

        # std = sqrt(E[X^2] - (E[X])^2)
        std = (channels_squared_sum / num_batches - mean ** 2) ** 0.5

        return mean, std

    

    def get_transforms(self, mode="train", keys=("img", "seg")):
        """returns a composed transform for train/val/infer."""
        assert mode in ("train", "val", "test", "predict")
        
        # get preprocess transformations
        preprocess_xforms = OmegaConf.to_container(self.transforms['preprocess_transforms'], resolve=True) if self.transforms['preprocess_transforms'] else None
        # get training transformations
        train_xforms = OmegaConf.to_container(self.transforms['train_transforms'], resolve=True) if self.transforms['train_transforms'] else None
        # get resize to network transformation
        # resize_xforms = self.transforms['resize_transforms']
        resize_xforms = OmegaConf.to_container(self.transforms['resize_transforms'], resolve=True) if self.transforms['resize_transforms'] else None
        # get label corrections
        label_xforms =  OmegaConf.to_container(self.transforms['label_transforms'], resolve=True) if self.transforms['label_transforms'] else None
        
        # starts with basic transformation: preprocessing + labeling
        xforms = copy(preprocess_xforms)
        # xforms.append(label_xforms)

        # print(xforms)
        if mode == "train":
            # adding the training transformations
            xforms = join(preprocess_xforms, label_xforms, )
            dtype = (np.float32, np.uint8)
        if mode == "val":
            # no adding transformation for validation and testing
            dtype = (np.float32, np.uint8)
        if mode in ("test", "predict"):
            # no adding transformation for validation and testing
            dtype = (np.float32,np.uint8)

        # xforms.extend([resize_xforms, CastToTyped(keys, dtype=dtype), EnsureTyped(keys)])
        # ensuring the final type for transformations
        xforms.extend(chain(*[resize_xforms, [EnsureTyped(keys, data_type='tensor')]]))
        log.info(f"\n\nfinal xforms {mode} = {xforms}")
        return Compose(xforms)


    def get_post_transforms(self):
        num_classes = self.num_classes
        # access to transform (test preprossing)
        val_org_transforms = self.get_transforms(mode="predict")
        # https://github.com/PyTorchLightning/pytorch-lightning/discussions/7884
        post_transforms = Compose([
            EnsureTyped(keys="pred"), # data_type="numpy"),
            Invertd(
                keys="pred",
                transform=val_org_transforms,
                orig_keys="img",
                meta_keys="pred_meta_dict",
                orig_meta_keys="img_meta_dict",
                meta_key_postfix="meta_dict",
                nearest_interp=False,
                to_tensor=True,
            ),
            AsDiscreted(keys="pred", argmax=True, to_onehot=num_classes),
            # can save label
            # AsDiscreted(keys="label", to_onehot=num_classes),
            SaveImaged(keys="pred", meta_keys="pred_meta_dict", output_dir="./outputs", output_postfix="pred", separate_folder=False, resample=False)
            ])
        return post_transforms

    def compute_stats(self):
        """
            return (mean, std) for each channel

        Args:
        
        """
        
        
        log.info(f"...  compute_stats")

        image_labels_for_modality = self.prepare_data_dict()
        log.debug(f"images: {image_labels_for_modality}")
        preprocess_transformations = [
                LoadImaged(keys=['img', 'seg']),
                AddChanneld(keys=['img', 'seg']),                    
            ]
        transforms_ = Compose(transforms=preprocess_transformations)
        ds_ = Dataset(data=image_labels_for_modality, transform=transforms_)
        # dataloader
        loader_ = DataLoader(ds_, batch_size=1)
        print(self.get_mean_and_std(loader_))


    def compute_class_axial_distribution(self):
        """
            return (mean, std) for each channel

        Args:
            modality (str): _description_
        """
        log.info("> compute_class_axial_distribution")
        modalities = list(self.hparams.modalities)
        image_labels_for_modality = self.prepare_data_dict(modalities)
        print("working on ", image_labels_for_modality)
        keys = ('img', 'seg')
        dtype = (np.float32, np.uint8)
        preprocess_transformations = [
                LoadImaged(keys=keys),
                CastToTyped(keys, dtype=dtype), 
                # EnsureTyped(keys)
                # Transposed(keys=['img', 'seg'], indices=(2, 1, 0)),
                # add channel (grayscale)
                # AddChanneld(keys=['img', 'seg']),                    
            ]
        transforms_ = Compose(transforms=preprocess_transformations)
        ds_ = Dataset(data=image_labels_for_modality, transform=transforms_)
        # dataloader
        loader_ = self.stats_dataloader(ds_, batch_size=1)
        print(self.get_class_axial_distribution(loader_))


    def compute_hash_distribution(self):
        """
            return (mean, std) for each channel for the dataset

        Args:
            modality (str): _description_
        """
        log.info("> compute_stats")

        image_labels = self.prepare_data_dict()
        self.distribution(image_labels)


    # view with napari
    @staticmethod
    def visualize(image, label):
        import napari
        viewer = napari.view_image(image.numpy())
        viewer.add_labels(label.numpy().astype(np.int8))
        napari.run()

    def sample_dataset(self, mode='preprocess'):
        loader_dict = [dict(img="/mnt/data/Data/GroundTruth/BrainVentricles/dataset/YFGXRRTF_T1_image.nii.gz", seg="/mnt/data/Data/GroundTruth/BrainVentricles/dataset/YFGXRRTF_T1_label.nii.gz")]
        
        preprocessing_xforms = OmegaConf.to_container(self.transforms['preprocessing_xforms'], resolve=True)
        # label corrections
        label_xforms = self.transforms['label_xforms']
        
        # compose
        xforms = copy(preprocessing_xforms)
        xforms.append(label_xforms)

        _transforms = Compose(transforms=xforms)

        check_ds = Dataset(data=loader_dict, transform=_transforms)
        # pick the first image
        check_loader = DataLoader(check_ds, batch_size=1)
        check_data = first(check_loader)

        image, label = check_data['img'], check_data['seg']

        print(f"image shape: {image.shape}")
        print(f"label shape: {label.shape}")
        return image, label

    
    def visualize_image(self):
        image, label = self.sample_dataset()
        self.visualize(image, label)


    # reference: spleen_lightning
    def train_dataloader(self):
        train_loader = DataLoader(
            dataset=self.data_train, 
            batch_size=self.hparams.batch_size, # 2
            shuffle=True, # reduce overfitting
            num_workers=self.hparams.num_workers, # 4
            pin_memory=self.hparams.pin_memory,
            collate_fn=list_data_collate,
            persistent_workers=self.hparams.persistent_workers
        )
        return train_loader


    def val_dataloader(self):
        val_dataloader = DataLoader(
            dataset=self.data_val,
            batch_size=1,  # self.hparams.batch_size,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False
        )
        return val_dataloader

    # TBD
    def test_dataloader(self):
        test_loader = DataLoader(
            dataset=self.data_test,
            batch_size=1,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False,
        )
        return test_loader

    def predict_dataloader(self):
        predict_loader = DataLoader(
            dataset=self.data_test,
            batch_size=1,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False,
        )
        return predict_loader


    def stats_dataloader(self, ds, batch_size):
        val_dataloader = DataLoader(
            dataset=ds,
            batch_size=batch_size,  # self.hparams.batch_size,
            num_workers=self.hparams.num_workers,
            # pin_memory=self.hparams.pin_memory,
            shuffle=False
        )
        return val_dataloader
