import torch
import numpy as np
from torchmetrics import Metric
# torchmetrics functional
# from torchmetrics.functional import dice_score
from typing import Union
from typing import Tuple

from torch import Tensor
from typing_extensions import Literal

from torchmetrics.utilities.data import to_categorical
from torchmetrics.utilities.distributed import reduce
from torchmetrics.functional.classification.dice import _stat_scores
from torchmetrics.classification.confusion_matrix import _confusion_matrix_update


IoU = lambda Dice: Dice / (2. - Dice)

# see torchmetrics 
# https://torchmetrics.readthedocs.io/en/stable/pages/implement.html
class DiceScore(Metric):
    def __init__(self, num_classes, include_background=False, dist_sync_on_step=False, compute_on_cpu=False):
        super().__init__(dist_sync_on_step=dist_sync_on_step, compute_on_cpu=compute_on_cpu)
        self.num_classes = num_classes
        self.threshold = 0.5
        self.multilabel = True
        self.include_background = include_background
        self.add_state("val", default=torch.tensor(0, dtype=torch.float), dist_reduce_fx="sum")
        self.add_state("total", default=torch.tensor(0, dtype=torch.int), dist_reduce_fx="sum")

    def update(self, preds: torch.Tensor, target: torch.Tensor):
        # preds, target = self._input_format(preds, target)
        print("preds.shape = ", preds.shape)
        # assert preds.shape == target.shape
        ds = dice_score(preds, target, bg=self.include_background)
        # print("numel = ", target.numel())
        # ds_monai = compute_meandice(preds, target, include_background=self.include_background)
        # ds_iou = 0 # _confusion_matrix_update(preds.float(), target, self.num_classes, self.threshold, self.multilabel)
        # print("******************")
        print("ds = ", ds)        
        # print("iou = ", (IoU(ds)))
        # # print("ds_monai = ", ds_monai)
        # print("******************")
        if ds > 0:
            self.val += ds
            self.total += 1 
        
        # print("val = ", self.val)

    def compute(self):
        print("compute = ", self.val, self.total)
        return self.val.float() / self.total



# from monai
def compute_meandice(
    y_pred: torch.Tensor, y: torch.Tensor, include_background: bool = True, ignore_empty: bool = True
) -> torch.Tensor:
    """Computes Dice score metric from full size Tensor and collects average.

    Args:
        y_pred: input data to compute, typical segmentation model output.
            It must be one-hot format and first dim is batch, example shape: [16, 3, 32, 32]. The values
            should be binarized.
        y: ground truth to compute mean dice metric. It must be one-hot format and first dim is batch.
            The values should be binarized.
        include_background: whether to skip Dice computation on the first channel of
            the predicted output. Defaults to True.
        ignore_empty: whether to ignore empty ground truth cases during calculation.
            If `True`, NaN value will be set for empty ground truth cases.
            If `False`, 1 will be set if the predictions of empty ground truth cases are also empty.

    Returns:
        Dice scores per batch and per class, (shape [batch_size, num_classes]).

    Raises:
        ValueError: when `y_pred` and `y` have different shapes.

    """

    if not include_background:
        y_pred, y = ignore_background(y_pred=y_pred, y=y)

    y = y.float()
    y_pred = y_pred.float()
    print("compute_meandice")
    print(y_pred.shape)
    print(y.shape)

    if y.shape != y_pred.shape:
        raise ValueError(f"y_pred and y should have same shapes, got {y_pred.shape} and {y.shape}.")

    # reducing only spatial dimensions (not batch nor channels)
    n_len = len(y_pred.shape)
    reduce_axis = list(range(2, n_len))
    intersection = torch.sum(y * y_pred, dim=reduce_axis)

    y_o = torch.sum(y, reduce_axis)
    y_pred_o = torch.sum(y_pred, dim=reduce_axis)
    denominator = y_o + y_pred_o

    if ignore_empty is True:
        return torch.where(y_o > 0, (2.0 * intersection) / denominator, torch.tensor(float("nan"), device=y_o.device))
    return torch.where(denominator > 0, (2.0 * intersection) / denominator, torch.tensor(1.0, device=y_o.device))



def ignore_background(y_pred: Union[np.ndarray, torch.Tensor], y: Union[np.ndarray, torch.Tensor]):
    """
    This function is used to remove background (the first channel) for `y_pred` and `y`.

    Args:
        y_pred: predictions. As for classification tasks,
            `y_pred` should has the shape [BN] where N is larger than 1. As for segmentation tasks,
            the shape should be [BNHW] or [BNHWD].
        y: ground truth, the first dim is batch.

    """

    y = y[:, 1:] if y.shape[1] > 1 else y
    y_pred = y_pred[:, 1:] if y_pred.shape[1] > 1 else y_pred
    return y_pred, y


# torchmetrics
def dice_score(
    preds: Tensor,
    target: Tensor,
    bg: bool = False,
    nan_score: float = 0.0,
    no_fg_score: float = 0.0,
    reduction: Literal["elementwise_mean", "sum", "none", None] = "elementwise_mean",
) -> Tensor:
    """Compute dice score from prediction scores.

    Args:
        preds: estimated probabilities
        target: ground-truth labels
        bg: whether to also compute dice for the background
        nan_score: score to return, if a NaN occurs during computation
        no_fg_score: score to return, if no foreground pixel was found in target
        reduction: a method to reduce metric score over labels.

            - ``'elementwise_mean'``: takes the mean (default)
            - ``'sum'``: takes the sum
            - ``'none'`` or ``None``: no reduction will be applied

    Return:
        Tensor containing dice score

    Example:
        >>> from torchmetrics.functional import dice_score
        >>> pred = torch.tensor([[0.85, 0.05, 0.05, 0.05],
        ...                      [0.05, 0.85, 0.05, 0.05],
        ...                      [0.05, 0.05, 0.85, 0.05],
        ...                      [0.05, 0.05, 0.05, 0.85]])
        >>> target = torch.tensor([0, 1, 3, 2])
        >>> dice_score(pred, target)
        tensor(0.3333)
    """
    # numclasses only in location 1 of tensor

    print("torchmetrics: dice_score")
    print(preds.shape)
    print(target.shape)

    num_classes = preds.shape[1]
    bg_inv = 1 - int(bg)
    print("bg_inv = ", bg_inv)
    scores = torch.zeros(num_classes - bg_inv, device=preds.device, dtype=torch.float32)
    # no need onehot!
    for i in range(bg_inv, num_classes):
        if not (target == i).any():
            # no foreground class
            scores[i - bg_inv] += no_fg_score
            continue

        # TODO: rewrite to use general `stat_scores`
        # print(preds.dtype)
        # print(target.dtype)
        tp, fp, _, fn, _ = _stat_scores(preds=preds, target=target, class_index=i)
        denom = (2 * tp + fp + fn).to(torch.float)
        # nan result
        score_cls = (2 * tp).to(torch.float) / denom if torch.is_nonzero(denom) else nan_score

        scores[i - bg_inv] += score_cls
    print("scores shape = ", scores.shape)
    return reduce(scores, reduction=reduction)
