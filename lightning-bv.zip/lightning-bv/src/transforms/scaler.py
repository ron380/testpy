'''
Filename: r:\pycode\BrainVentricles\transforms\scaler.py
Path: r:\pycode\BrainVentricles\transforms
Created Date: Wednesday, March 16th 2022, 12:01:29 pm
Author: Ron Shefi

Copyright (c) 2022 Philips
'''

import numpy as np
from typing import Any, Callable, List, Optional, Sequence, Tuple, Union
from monai.config import DtypeLike
from monai.config.type_definitions import NdarrayOrTensor
from monai.data.utils import get_random_patch, get_valid_patch_size
from monai.transforms.transform import RandomizableTransform, Transform, Randomizable
from monai.transforms.utils import Fourier, equalize_hist, is_positive, rescale_array
from monai.transforms.utils_pytorch_numpy_unification import clip, percentile, where
from monai.utils import (
    InvalidPyTorchVersionError,
    convert_data_type,
    convert_to_dst_type,
    ensure_tuple,
    ensure_tuple_rep,
    ensure_tuple_size,
    fall_back_tuple,
    pytorch_after,
)
from monai.utils.deprecate_utils import deprecated_arg
from monai.utils.enums import TransformBackends
from monai.utils.type_conversion import convert_to_tensor, get_equivalent_dtype

# pick the range for CT Window"
# CL - center level
# window width 
# [min, max] = 0-80

__all__ = ['CTThresholdIntensity']




class CTThresholdIntensity(Transform):
    """
    Filter the intensity values of whole image to below threshold or above threshold.
    And fill the remaining parts of the image to the `cval` value.

    Args:
        threshold: the threshold to filter intensity values.
        above: filter values above the threshold or below the threshold, default is True.
        cval: value to fill the remaining parts of the image, default is 0.
    """

    backend = [TransformBackends.TORCH, TransformBackends.NUMPY]

    def __init__(self, a_min: float, a_max: float, normalization=True, dtype: DtypeLike = np.float32) -> None:
        self.a_min = a_min
        self.a_max = a_max
        self.normalization = normalization
        self.dtype = dtype

    def __call__(self, img: NdarrayOrTensor) -> NdarrayOrTensor:
        """
        Apply the transform to `img`.
        """
        img = clip(img, self.a_min, self.a_max)
        if self.normalization:
            epsilon = 1e-7
            img_min = img.min()
            img_range = img.max() - img_min
            res: NdarrayOrTensor = (img - img_min) / float(img_range + epsilon)
         
        res, *_ = convert_data_type(res, dtype=self.dtype)
        return res


class RandomizedSliceAxis(Randomizable, Transform):
    """
    Filter the intensity values of whole image to below threshold or above threshold.
    And fill the remaining parts of the image to the `cval` value.

    Args:
        threshold: the threshold to filter intensity values.
        above: filter values above the threshold or below the threshold, default is True.
        cval: value to fill the remaining parts of the image, default is 0.
    """

    backend = [TransformBackends.TORCH, TransformBackends.NUMPY]


    def __init__(self, axis: int, len: int) -> None:
        self.axis = axis
        self.len = len
   
    def randomize(self, img_size: Sequence[int]) -> None:
         super().randomize(None)

    def __call__(self, img: NdarrayOrTensor) -> NdarrayOrTensor:
        """
        Apply the transform to `img`.
            slice if dim[axis] < len
        """
        axes = [slice(None)] * img.ndim
        img_axis_len = img.shape[self.axis]
        if img_axis_len > self.len:
            # from 0 to img_axis_len - self.len
            max_slices = img_axis_len - self.len
            # nslices = img_axis_len // self.length + 1
            start_idx = self.R.randint(max_slices)
            # create a slice object
            axes[self.axis] = slice( start_idx, start_idx + self.len )

        return img[axes]

# class ConvertLabels(Transform):
#     """
#     Convert labels to multi channels

#     """
#     backend = [TransformBackends.TORCH, TransformBackends.NUMPY]
#     # backend = [TransformBackends.NUMPY]

#     def __init__(
#         self,num_classes: int = 2, allow_missing_keys: bool = False
#     ) -> None:        
#         super().__init__(keys, allow_missing_keys)
#         self.num_classes = num_classes
        


#     def __call__(self, data: Mapping[Hashable, NdarrayOrTensor]) -> Dict[Hashable, NdarrayOrTensor]:
#         d = dict(data)
#         # background is class #0
#         for key in self.key_iterator(d):
#             result = d[key].astype(np.int8)
#             # merge LEFT and RIGHT
#             result = torch.where(d[key] == 2, 1, result)
#             # shift label 3 -> 2
#             # shift label 4 -> 3
#             if self.num_classes > 2:
#                 result = torch.where(d[key] == 3, 2, result)
#             if self.num_classes > 3:
#                 result = torch.where(d[key] == 4, 3, result)
#             d[key] = result.astype(np.int8)
#         return d
