from abc import ABC
import numpy as np
import cv2
from albumentations.augmentations import RandomScale
from albumentations.augmentations import functional as F


class RandomStretchHeight(RandomScale):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def apply(self, img, scale=0, interpolation=cv2.INTER_LINEAR, pad_mode='edge', **params):
        height, width = img.shape[:2]
        new_height = int(height * scale)
        if new_height > height:
            rand_cut = np.random.rand()
            bottom = int((new_height - height) * rand_cut)
            top = height + bottom
            # print(rand_cut, bottom, top, F.resize(img, width, new_height, interpolation).shape,
            #       F.resize(img, width, new_height, interpolation)[:, bottom:top, :].shape)
            return F.resize(img, width, new_height, interpolation)[:, bottom:top, :]
        elif new_height < height:
            padding = ((0, 0), (int(np.ceil((height - new_height) / 2)), int(np.floor((height - new_height)/2))),
                       (0, 0))
            # print(F.resize(img, width, new_height, interpolation).shape,
            #       np.pad(F.resize(img, width, new_height, interpolation), padding, mode=pad_mode).shape)
            return np.pad(F.resize(img, width, new_height, interpolation), padding, mode=pad_mode)
        else:
            return img


class RandomStretchWidth(RandomScale):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def apply(self, img, scale=0, interpolation=cv2.INTER_LINEAR, pad_mode='edge', **params):
        height, width = img.shape[:2]
        new_width = int(width * scale)
        if new_width > width:
            rand_cut = np.random.rand()
            left = int((new_width - width) * rand_cut)
            right = width + left
            # print(rand_cut, left, right, F.resize(img, new_width, height, interpolation).shape,
            #       F.resize(img, new_width, height, interpolation)[left:right, ...].shape)
            return F.resize(img, new_width, height, interpolation)[left:right, ...]
        elif new_width < width:
            padding = ((int(np.ceil((width - new_width) / 2)), int(np.floor((width - new_width) / 2))), (0, 0), (0, 0))
            # print(F.resize(img, new_width, height, interpolation).shape,
            #       np.pad(F.resize(img, new_width, height, interpolation), padding, mode=pad_mode).shape)
            return np.pad(F.resize(img, new_width, height, interpolation), padding, mode=pad_mode)
        else:
            return img
