"""
A collection of dictionary-based wrappers around the MONAI transforms

Class names are ended with 'd' to denote dictionary-based transforms.
"""

from typing import Callable, Dict, Hashable, List, Mapping, Optional, Sequence, Tuple, Union

import numpy as np
import torch
from monai.config import DtypeLike, KeysCollection
from monai.config.type_definitions import NdarrayOrTensor

from src.transforms.array import GammaCorrection
from .scaler import (
    CTThresholdIntensity
)
from monai.transforms.transform import MapTransform, RandomizableTransform, Transform
from monai.transforms.utils import is_positive
from monai.utils import ensure_tuple, ensure_tuple_rep
from monai.utils.enums import TransformBackends
from monai.utils.deprecate_utils import deprecated_arg

from monai.transforms.utils_pytorch_numpy_unification import clip
import skimage
from functools import partial

# __all__ = [
#     "CTThresholdIntensityd", "ConvertLabeld", "Clamp", "GammaCorrectiond"
# ]




class CTThresholdIntensityd(MapTransform):
    """
    Dictionary-based wrapper of :py:class:`monai.transforms.ThresholdIntensity`.

    Args:
        keys: keys of the corresponding items to be transformed.
            See also: monai.transforms.MapTransform
        threshold: the threshold to filter intensity values.
        above: filter values above the threshold or below the threshold, default is True.
        cval: value to fill the remaining parts of the image, default is 0.
        allow_missing_keys: don't raise exception if key is missing.
    """

    backend = CTThresholdIntensity.backend

    def __init__(
        self,
        keys: KeysCollection,
        a_min: float, 
        a_max: float, 
        normalization: bool = True,
        allow_missing_keys: bool = False,
    ) -> None:
        super().__init__(keys, allow_missing_keys)
        self.filter = CTThresholdIntensity(a_min, a_max, normalization)

    def __call__(self, data: Mapping[Hashable, NdarrayOrTensor]) -> Dict[Hashable, NdarrayOrTensor]:
        d = dict(data)
        for key in self.key_iterator(d):
            d[key] = self.filter(d[key])
        return d

class RandomizeCheckd(MapTransform):
    backend = [TransformBackends.TORCH, TransformBackends.NUMPY]

    def __init__(
        self, keys: KeysCollection, transform: Transform, modality: str, allow_missing_keys: bool = True
    ) -> None:
        assert modality in ('CT', 'T1', 'FLAIR'), 'modality not in available list'        
        super().__init__(keys, allow_missing_keys)
        self.modality = modality
        self.transform = transform(keys)

        
    def __call__(self, data: Mapping[Hashable, NdarrayOrTensor]) -> Dict[Hashable, NdarrayOrTensor]:
        d = dict(data)
        mod = d.pop('mod')
        print("inside ModalityBasedTransform", mod)
        if mod == self.modality:
            for key in self.key_iterator(d):
                d[key] = self.transform(d[key])        
        else:
            for key in self.key_iterator(d):
                d[key] = self.identity(d[key])
        return d



class Clampd(MapTransform):

    backend = [TransformBackends.TORCH, TransformBackends.NUMPY]

    def __init__(
        self,
        keys: KeysCollection,
        a_min: float = None,
        a_max: float = None,
        allow_missing_keys: bool = False,
    ) -> None:
        super().__init__(keys, allow_missing_keys)
        self.a_min = a_min
        self.a_max = a_max

    def __call__(self, data: Mapping[Hashable, NdarrayOrTensor]) -> Dict[Hashable, NdarrayOrTensor]:
        d = dict(data)
        for key in self.key_iterator(d):
            d[key] = clip(d[key], self.a_min, self.a_max)   # going to unified clip
        return d


class GammaCorrectiond(MapTransform):

    backend = [TransformBackends.TORCH, TransformBackends.NUMPY]

    def __init__(
        self,
        keys: KeysCollection,
        gamma: float = 0.5,
        nonzero: bool = False,
        channel_wise: bool = False,
        dtype: DtypeLike = np.float32,
        allow_missing_keys: bool = False,
    ) -> None:
        super().__init__(keys, allow_missing_keys)
        self.filter = GammaCorrection(gamma, nonzero, channel_wise, dtype)

    def __call__(self, data: Mapping[Hashable, NdarrayOrTensor]) -> Dict[Hashable, NdarrayOrTensor]:
        d = dict(data)
        for key in self.key_iterator(d):
            d[key] = self.filter(d[key])
        return d


class Sobeld(MapTransform):

    backend = [TransformBackends.TORCH, TransformBackends.NUMPY]

    def __init__(
        self,
        keys: KeysCollection,
        # channel_wise: bool = False,
        dtype: DtypeLike = np.float32,
        allow_missing_keys: bool = False,
    ) -> None:
        super().__init__(keys, allow_missing_keys)
        self.filter = partial(skimage.filters.sobel)

    def __call__(self, data: Mapping[Hashable, NdarrayOrTensor]) -> Dict[Hashable, NdarrayOrTensor]:
        d = dict(data)
        for key in self.key_iterator(d):
            d[key] = self.filter(d[key])
        return d


class ModalityBasedTransformd(MapTransform):
    backend = [TransformBackends.TORCH, TransformBackends.NUMPY]

    def __init__(
        self, keys: KeysCollection, transform: Transform, modality: str, allow_missing_keys: bool = True
    ) -> None:
        assert modality in ('CT', 'T1', 'FLAIR'), 'modality not in available list'        
        super().__init__(keys, allow_missing_keys)
        self.modality = modality
        self.transform = transform(keys)

        
    def __call__(self, data: Mapping[Hashable, NdarrayOrTensor]) -> Dict[Hashable, NdarrayOrTensor]:
        d = dict(data)
        mod = d.pop('mod')
        print("inside ModalityBasedTransform", mod)
        if mod == self.modality:
            for key in self.key_iterator(d):
                d[key] = self.transform(d[key])        
        else:
            for key in self.key_iterator(d):
                d[key] = self.identity(d[key])
        return d



class ConvertLabeld(MapTransform):
    """
    Convert labels to multi channels

    """
    backend = [TransformBackends.TORCH, TransformBackends.NUMPY]
    #backend = [TransformBackends.NUMPY]

    def __init__(
        self, keys: KeysCollection, num_classes: int = 2, allow_missing_keys: bool = False
    ) -> None:        
        super().__init__(keys, allow_missing_keys)
        self.num_classes = num_classes
        


    def __call__(self, data: Mapping[Hashable, NdarrayOrTensor]) -> Dict[Hashable, NdarrayOrTensor]:
        d = dict(data)
        # background is class #0
        for key in self.key_iterator(d):
            # result = d[key].astype(np.int8)
            # print("unique = ", np.unique(result))
            # merge LEFT and RIGHT
            result = np.logical_or(d[key] == 1, d[key] == 2)
            # result = np.zeros_like(d[key], dtype=np.float)
            # result[d[key] == 1] = 1
            # result[d[key] == 2] = 1
            print("sum = ", np.sum(result))
            # shift label 3 -> 2
            # shift label 4 -> 3

            # if self.num_classes > 2:
            #     result = np.where(d[key] == 3, 2, result)
            # if self.num_classes > 3:
            #     result = np.where(d[key] == 4, 3, result)
            # else:
            #     result = np.where(d[key] == 3, 0, result)
            #     result = np.where(d[key] == 4, 0, result)
            # print("unique = ", np.unique(result))
            # d[key] = result.astype(np.float32)
            d[key] = result
        return d



class ConvertLabelSamed(MapTransform):
    """
    Convert labels to multi channels

    """
    #backend = [TransformBackends.TORCH, TransformBackends.NUMPY]
    backend = [TransformBackends.NUMPY]

    def __init__(
        self, keys: KeysCollection, num_classes: int = 2, allow_missing_keys: bool = False
    ) -> None:        
        super().__init__(keys, allow_missing_keys)
        self.num_classes = num_classes
        

    def __call__(self, data):
        d = dict(data)
        for key in self.keys:
            # merge labels 1, 2 to construct GT (ground truth)
            if self.num_classes == 2:
                result = np.logical_or(d[key] == 1, d[key] == 2)
            # merge labels 1, 2 and 3 to construct GT
            if self.num_classes == 3:
                result = np.logical_or(result, d[key] == 3)
            # merge labels 1, 2, 3, 4 to construct GT
            if self.num_classes == 4:
                result = np.logical_or(result, d[key] == 4)

            d[key] = result.astype(np.float32)
        return d

class ConvertLabelMultichanneld(MapTransform):
    """
    Convert labels to multi channels

    """
    #backend = [TransformBackends.TORCH, TransformBackends.NUMPY]
    backend = [TransformBackends.NUMPY]

    def __init__(
        self, keys: KeysCollection, num_classes: int = 2, allow_missing_keys: bool = False
    ) -> None:        
        super().__init__(keys, allow_missing_keys)
        self.num_classes = num_classes
        

    def __call__(self, data):
        d = dict(data)
        for key in self.keys:
            # result = []
            # merge label 2 and label 3 to construct TC
            # result.append(np.logical_or(d[key] == 1, d[key] == 2))
            result = np.logical_or(d[key] == 1, d[key] == 2)
            # merge labels 1, 2 and 3 to construct WT
            # result.append(
            #     np.logical_or(
            #         np.logical_or(d[key] == 2, d[key] == 3), d[key] == 1
            #     )
            # )
            # # label 2 is ET
            # result.append(d[key] == 2)
            # d[key] = np.stack(result, axis=0).astype(np.float32)
            d[key] = result.astype(np.float32)
        return d