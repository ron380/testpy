from typing import Any, List, Dict, Tuple, Union, Optional
# pytorch
import torch
from pytorch_lightning import LightningModule

# MONAI
from monai.transforms import (
    AddChanneld,
    Compose,
    CastToType,
    AsDiscrete,
    AsDiscreted,
    Invertd,
    EnsureTyped,
    EnsureType,
)
# MONAI loss/metrics/data/inferer
from monai.losses import DiceLoss
from monai.inferers import sliding_window_inference
from monai.handlers.utils import from_engine
from monai.data import CacheDataset, list_data_collate, decollate_batch
from monai.config import print_config
# re-implementation of dicemetric (iou)
from ..modules import DiceMetric
# from monai.metrics import DiceMetric 

from numpy import save as npsave
from pandas import DataFrame
from src.utils import get_logger, df_to_richtable
import sys
import re


# loggers
log = get_logger(__name__)   # generic
log_val_files = get_logger("log_val_files")   # for image validations
# nibabel
import nibabel as nib
# clearML
from clearml import Task
# rich
from rich.console import Console
console = Console()
#        rich.console.clear()
# plotly
import plotly.express as px

from collections import namedtuple
LabelIOU = namedtuple('LabelIOU', ['segname', 'bilateral', 'vntr3', 'vntr4'])

class BrainVentriclesModule(LightningModule):
    """Example of LightningModule for BrainVentricles segmentation

    A LightningModule organizes your PyTorch code into 5 sections:
        - Computations (init).
        - Train loop (training_step)
        - Validation loop (validation_step)
        - Test loop (test_step)
        - Optimizers (configure_optimizers)

    Read the docs:
        https://pytorch-lightning.readthedocs.io/en/latest/common/lightning_module.html
    """

    def __init__(
        self,
        net:  torch.nn.Module,
        loss: torch.nn.modules.loss._Loss,
        num_classes: int,
        **kwargs
    ):
        super().__init__()

        # this line allows to access init params with 'self.hparams' attribute
        # it also ensures init params will be stored in ckpt
        self.save_hyperparameters(logger=False)

        self.num_classes = num_classes

        # store model
        self._model = net

        # store loss function
        self.loss_function = loss 


        # post operators: num_classes used for one hot encoding        
        self.post_pred = Compose([EnsureType("tensor", device="cuda"), AsDiscrete(argmax=True, to_onehot=self.num_classes)])
        # post operation for labels: apply on the label (ground truth)
        self.post_label = Compose([EnsureType("tensor", device="cuda"), AsDiscrete(to_onehot=self.num_classes)])

        # record best vals so far
        self.best_val_dice = 0
        self.best_val_iou = 0
        self.best_val_epoch = 0

        # computation metrics (move to yaml) ...
        # dice_metric_mon - metric for dice (jaccard = False)
        # dice_iou_mon    - metric for iou (jaccard = True)
        # for metric evaluation
        self.dice_metric_mon = DiceMetric(include_background=False, reduction="mean", get_not_nans=False, jaccard=False)
        self.iou_metric_mon = DiceMetric(include_background=False, reduction="mean", get_not_nans=False, jaccard=True)
        # metric (summing over batches)
        self.dice_metric_batch = DiceMetric(include_background=False, reduction="mean_batch", jaccard=False)
        self.iou_metric_batch = DiceMetric(include_background=False, reduction="mean_batch", jaccard=True)


        
        # store validation scores
        self.val_report = []
        # get clearML instance ...
        # task.connect(config)
        if Task.current_task():
            Task.current_task().connect(self.hparams)


    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """ model forward operator

        Parameters
        ----------
        x : torch.Tensor
            _description_

        Returns
        -------
        torch.Tensor
            _description_
        """
        return self._model(x)


    def training_step(self, batch: Any, batch_idx: int) -> Optional[Union[torch.Tensor, Dict[str, Any]]]:
        """ model training step

        Parameters
        ----------
        batch : Any
            _description_
        batch_idx : int
            _description_

        Returns
        -------
        dict
            return a loss value and tensorboard logs
        """
        if torch.cuda.is_available():
            images, labels = batch["img"].cuda(), batch["seg"].cuda()
        else:
            images, labels = batch["img"], batch["seg"]
        # apply the model (see function forward)
        output = self.forward(images)

        # compute loss function 
        loss = self.loss_function(output, labels)
        
        # log val metrics (lightning uses tensorboard under the hood and stores the logs to a directory by default in lightning_logs)
        self.log("loss_last/train", loss, on_step=False, on_epoch=True, prog_bar=True)
        self.log("step", self.trainer.current_epoch)
        tensorboard_logs = { "loss/train": loss.item()}
        # required 
        return {"loss": loss, "log": tensorboard_logs}
    

    def training_epoch_end(self, outputs: List[Any]) -> None:
        mean_loss = torch.stack([x["loss"] for x in outputs]).mean()
        self.log("loss/train", mean_loss, on_step=False, on_epoch=True, prog_bar=True)
        self.log("step", self.trainer.current_epoch)


    
    def validation_step(self, batch: Any, batch_idx: int) -> Optional[Union[torch.Tensor, Dict[str, Any]]]:
        """ model validation step

        Parameters
        ----------
        batch : Any
            _description_
        batch_idx : int
            _description_

        Returns
        -------
        dict
            return a loss value and tensorboard logs

        """       
        
        # get images, labels, etc  from the batch
        images, labels, imgnames, segnames = batch["img"], batch["seg"], batch["imgname"], batch["segname"]
        
        # predict the output using roi_size (usually this is image dims)
        roi_size = self.hparams.dims
        sw_batch_size = 1
        outputs = sliding_window_inference(
             images, roi_size, sw_batch_size, self.forward)
        # outputs = self.forward(images)
        # outputs = self.post_pred(outputs)
        # labels = self.post_label(labels)

        # print ("outputs shape = ", outputs.shape)
        # print ("labels orig shape = ", labels_orig.shape)
        # sys.exit()

        # validation loss
        val_loss = self.loss_function(outputs, labels)
        
        # preds and labels using the defintion of the post operators
        preds = [self.post_pred(i) for i in decollate_batch(outputs)]
        labels  = [self.post_label(i) for i in decollate_batch(labels)]
        
        # metric (dice) accumulator
        # print("shape: preds, labels")
        # print(preds[0].shape)
        # print(labels[0].shape)
        # enable unsqueeze for list
        # print("len outputs = ", len(outputs))
        # print("segfiles = ", segfiles)


        # restricted current for batchsize = 1 (cf. sw_batch_size). will look later at any batch size
        # metric monitors both the dice metric and the iou metric averaging over batchxchannel. 
        # only iou_result is being monitored in callbacks and reported
        dice_result = self.dice_metric_mon(preds, labels)
        iou_result = self.iou_metric_mon(preds, labels)
        # update the metric monitors
        self.dice_metric_batch(y_pred=preds, y=labels)
        self.iou_metric_batch(y_pred=preds, y=labels)
        
        # collect validation sample score (iou_result/dice_result). here we choose iou results
        # self.val_report.append(dict(file=segnames[0], val_dice=iou_result.tolist()))
        iou_result_ = iou_result.squeeze().tolist()
        labelIOU = LabelIOU(segnames[0], iou_result_[0], iou_result_[1], iou_result_[2])
        # move to sync buffer to allow for parallel gpu
        self.val_report.append(labelIOU)

        self.log("loss/val", val_loss, on_step=False, on_epoch=True, prog_bar=False)
        self.log("step", self.trainer.current_epoch)
        # used in the aggregate calculations (running average) in the validation_epoch_end
        return {"loss/val": val_loss, "number/val": len(outputs)}


    def validation_epoch_end(self, outputs: List[Any]) -> None:    
        """ model validation epoch end for reporting logging and statistics collection

        Parameters
        ----------
        outputs : List[Any]
            _description_

        """
        # need to get output list
        # here: loss/val, number/val
        val_loss, num_items = 0, 0
        # iou computed formula from dice (not used)
        iou_ = lambda dice_: dice_/(2. - dice_)
        VAL_DEBUG = True
        # log the validation scores report
        if VAL_DEBUG:
            log_val_files.info(f"epoch: {self.trainer.current_epoch}")
            log_val_files_df = DataFrame(self.val_report, columns=LabelIOU._fields)
            # print(log_val_files_df)
            # sys.exit()
            log_val_files_richdf = df_to_richtable(log_val_files_df)
            log_val_files.info(console.print(log_val_files_richdf))
            self.val_report.clear()
            # print(self.val_report)
        
            # create plotly figure to be stored in the log directory and clearml
            df = log_val_files_df.set_index("segname")
            fig = px.box(df, x=df.index, y=df.columns.tolist(), points="all")
            fig.update_yaxes(title="iou")
                # labels={
                #         "sepal_length": "Sepal Length (cm)",
                #         "sepal_width": "Sepal Width (cm)",
                #         "species": "Species of Iris"
                #     },)
            # fig = px.scatter(df, x="sepal_width", y="sepal_length", color="species", marginal_y="rug", marginal_x="histogram")

    
        # aggregate the validation loss (from returned dict)
        for output in outputs:
            val_loss += output["loss/val"].sum().item()
            num_items += output["number/val"]
        # mean loss for the validation 
        mean_val_loss = torch.tensor(val_loss / num_items)
        
        # mean dice/iou metric for the validation
        mean_val_dice = self.dice_metric_mon.aggregate().item()
        mean_val_iou = self.iou_metric_mon.aggregate().item()
        std_val_iou = self.iou_metric_mon.aggregate("std").item()
        # print(f"mean_val_iou {mean_val_iou} std_val_iou {std_val_iou}")
        # and reset for the next epoch
        self.dice_metric_mon.reset()
        self.iou_metric_mon.reset()


        # mean dice/iou metric for each channel (bilateral, vnt3, vnt4)
        metric_batch_ = self.dice_metric_batch.aggregate()
        dice_metric_bilateral = metric_batch_[0].item()
        dice_metric_vnt3 = metric_batch_[1].item()
        dice_metric_vnt4 = metric_batch_[2].item()
        self.dice_metric_batch.reset()

        # mean dice/iou metric for each channel (bilateral, vnt3, vnt4)
        metric_batch_ = self.iou_metric_batch.aggregate()
        iou_metric_bilateral = metric_batch_[0].item()
        iou_metric_vnt3 = metric_batch_[1].item()
        iou_metric_vnt4 = metric_batch_[2].item()
        self.iou_metric_batch.reset()

        # see iou_ formula (this metric is not used just for comparison with the internal computation)
        mean_val_iou_computed = iou_(mean_val_dice)
        
        # tensorboard dict (not used)
        tensorboard_logs = {
            "dice/val": mean_val_dice,
            "loss/val": mean_val_loss,
        }

        # best mean dice over the validation
        if mean_val_iou > self.best_val_iou:
            self.best_val_epoch = self.current_epoch
            self.best_val_iou = mean_val_iou
            self.best_val_dice = max(self.best_val_dice, mean_val_dice)
            self.best_val_iou_computed = iou_(self.best_val_dice)
            self.best_val_iou_labels_fig = fig

        log.info(
            f"current epoch: {self.current_epoch} "
            f"mean dice: {mean_val_dice:.4f} "
            f"mean iou (computed): {mean_val_iou_computed:.4f} "
            f"mean iou: {mean_val_iou:.4f}"
            )

        log.info(            
            f"best at epoch: {self.best_val_epoch} "
            f"mean dice: {self.best_val_dice:.4f} "            
            f"mean iou (computed): {self.best_val_iou_computed:.4f} "
            f"mean iou: {self.best_val_iou:.4f}\n\n"
            )

        # return {"log": tensorboard_logs}
        # log val metrics (lightning uses tensorboard under the hood and stores the logs to a directory by default in lightning_logs)

        self.log("dice/val", mean_val_dice, prog_bar=True)
        self.log("loss/val", mean_val_loss, prog_bar=True)
        self.log("iou/mean", mean_val_iou)
        self.log("iou(computed)/val", mean_val_iou_computed)
        

        self.log("iou/bilateral", iou_metric_bilateral)
        self.log("iou/vnt3", iou_metric_vnt3)
        self.log("iou/vnt4", iou_metric_ventricle4)
        
        return {"iou/val": mean_val_iou, "dice/val": mean_val_dice, "loss/val": mean_val_loss}

    def test_step(self, batch: Any, batch_idx: int):
        images, labels = batch["img"], batch["seg"]
        roi_size = self.hparams.dims
        sw_batch_size = 1
        outputs = sliding_window_inference(
            images, roi_size, sw_batch_size, self.forward)
        loss = self.loss_function(outputs, labels)
        
        preds = [self.post_pred(i) for i in decollate_batch(outputs)]
        labels  = [self.post_label(i) for i in decollate_batch(labels)]
        # metrics
        self.dice_metric_mon(y_pred=preds, y=labels)

        # log val metrics (lightning uses tensorboard under the hood and stores the logs to a directory by default in lightning_logs)
        # acc = self.val_acc(preds, targets)
        self.log("loss/test", loss, on_step=False, on_epoch=True, prog_bar=False)
        # self.log("test/acc", acc, on_step=False, on_epoch=True, prog_bar=True)

        # return {"loss": loss, "preds": preds, "targets": targets}
        return {"loss/test": loss, "number/test": len(outputs)}


    def predict_step(self, batch: Any, batch_idx: int):
        # print("batch = ", batch["segfile"], batch["mod"])
        images, labels, segfiles = batch["img"], batch["seg"], batch["segfile"]

        print("segfile = ", segfiles)
        predfiles = [re.sub("label", "pred", f) for f in segfiles]
        print(predfiles)
        
        # device = torch.device("cuda:0")
        roi_size = self.hparams.dims
        sw_batch_size = 1
        post_transforms = self.trainer.datamodule.get_post_transforms()
        inputs = images # .cpu() # to("cpu")
        # batch["pred"] = sliding_window_inference(
        #     inputs, roi_size, sw_batch_size, self.forward)
        batch["pred"] = sliding_window_inference(
            inputs, roi_size, sw_batch_size, self.forward)
        print(list(batch.keys()))
        batch["pred"] = batch["pred"].cpu()
        outputs = [post_transforms(i) for i in decollate_batch(batch)]
        # can also pick labels from outputs and compute the dice metric
        # val_preds = from_engine(["pred"])(outputs)

        #         # uncomment the following lines to visualize the predicted results
        #         test_output = from_engine(["pred"])(test_data)

        #         original_image = loader(test_data[0]["image_meta_dict"]["filename_or_obj"])[0]

        #         plt.figure("check", (18, 6))
        #         plt.subplot(1, 2, 1)
        #         plt.imshow(original_image[:, :, 20], cmap="gray")
        #         plt.subplot(1, 2, 2)
        #         plt.imshow(test_output[0].detach().cpu()[1, :, :, 20])
        #         plt.show()

        
    def on_predict_epoch_start(self):        
        log.info("on_predict_epoch_start: invert transform")

    def on_test_epoch_start(self):
        log.info("on_test_epoch_start")

    def test_epoch_end(self, outputs: List[Any]):
        test_loss, num_items = 0, 0
        
        for output in outputs:
            test_loss += output["test/dice_loss"].sum().item()
            num_items += output["test/number"]
        
        mean_test_dice = self.dice_metric_mon.aggregate().item()
        self.dice_metric_mon.reset()
        mean_test_loss = torch.tensor(test_loss / num_items)
        print(
            f"current epoch: {self.current_epoch} "
            f"current mean dice: {mean_test_dice:.4f}"
            f"mean loss: {mean_test_loss:.4f}"
        )
        self.log("test/dice", mean_test_dice)
        self.log("test/dice_loss", mean_test_loss)
        return {"test/dice": mean_test_dice, "test/dice_loss": mean_test_loss}

    
    def configure_optimizers(self):
        """Choose what optimizers and learning-rate schedulers to use in your optimization.
        Normally you'd need one. But in the case of GANs or similar you might have multiple.

        See examples here:
            https://pytorch-lightning.readthedocs.io/en/latest/common/lightning_module.html#configure-optimizers
        """
        # or self.parameters()
        # opt = torch.optim.SGD(self._model.parameters(), lr=self.hparams.lr, weight_decay=self.hparams.weight_decay)
        opt = torch.optim.AdamW(self._model.parameters(), lr=self.hparams.lr, weight_decay=self.hparams.weight_decay)
        """
        Set the learning rate of each parameter group using a cosine annealing schedule, where \eta_{max} is set to the initial lr, T_{cur} is the number of epochs since the last restart and T_{i} is the number of epochs between two warm restarts in SGDR:
        """
        # sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max = 10)
        # sch = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(opt, T_0=self.hparams.T_0,
        #             T_mult=1, # A factor increases T_{i}  after a restart. Default: 1.
        #             eta_min=0.0001, # Minimum learning rate. Default: 0
        #             verbose = False)
        sch = None
        # return [opt], [sch]
        return [opt]
