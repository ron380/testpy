from typing import Any, List

import torch
from pytorch_lightning import LightningModule

# MONAI
from monai.transforms import (
    AsDiscrete,
    AddChanneld,
    Compose,
    CropForegroundd,
    LoadImaged,
    Orientationd,
    RandCropByPosNegLabeld,
    ScaleIntensityRanged,
    Spacingd,
    EnsureTyped,
    EnsureType,
)
from monai.metrics import DiceMetric
from monai.losses import DiceLoss
from monai.inferers import sliding_window_inference
from monai.data import CacheDataset, list_data_collate, decollate_batch
from monai.config import print_config

# classification problems
from torchmetrics import MaxMetric
from torchmetrics.classification.accuracy import Accuracy

# from src.models.components.simple_dense_net import SimpleDenseNet


class RANZsrClipModule(LightningModule):
    """Example of LightningModule for BrainVentricles segmentation using MONAI.

    A LightningModule organizes your PyTorch code into 5 sections:
        - Computations (init).
        - Train loop (training_step)
        - Validation loop (validation_step)
        - Test loop (test_step)
        - Optimizers (configure_optimizers)

    Read the docs:
        https://pytorch-lightning.readthedocs.io/en/latest/common/lightning_module.html
    """

    def __init__(
        self,
        net:  torch.nn.Module,
        loss: torch.nn.modules.loss._Loss,
        num_classes: int,
        **kwargs
    ):
        super().__init__()

        # this line allows to access init params with 'self.hparams' attribute
        # it also ensures init params will be stored in ckpt
        self.save_hyperparameters(logger=False)

        self.num_classes = num_classes

        # model from init
        self._model = net

        # loss function from n=init
        self.loss_function = loss     # DiceLoss(to_onehot_y=True, softmax=True)


        # metrics (move to yaml)
        self.dice_metric_mon = DiceMetric(include_background=True, reduction="mean", get_not_nans=False)

        # MONAI post operators: num_classes used for one hot encoding
        # post operation for prediction: apply on the image
        self.post_pred = Compose([EnsureType("tensor", device="cpu"), AsDiscrete(argmax=True, to_onehot=self.num_classes)])
        # post operation for labels: apply on the label(true segmentation)
        self.post_label = Compose([EnsureType("tensor", device="cpu"), AsDiscrete(to_onehot=self.num_classes)])

        self.best_val_dice = 0
        self.best_val_epoch = 0


        # classification problem stuff (not used)
        # use separate metric instance for train, val and test step
        # to ensure a proper reduction over the epoch
        # self.train_acc = Accuracy()
        # self.val_acc = Accuracy()
        # self.test_acc = Accuracy()
        # for logging best so far validation accuracy
        # self.val_acc_best = MaxMetric()

    def forward(self, x: torch.Tensor):
        return self._model(x)

    # classification step
    # def step(self, batch: Any):
    #     x, y = batch
    #     logits = self.forward(x)
    #     loss = self.loss_function(logits, y)
    #     preds = torch.argmax(logits, dim=1)
    #     return loss, preds, y

    def training_step(self, batch: Any, batch_idx: int):
        if torch.cuda.is_available():
            images, labels = batch["img"].cuda(), batch["seg"].cuda()
        else:
            images, labels = batch["img"], batch["seg"]
        output = self.forward(images)
        # loss function
        loss = self.loss_function(output, labels)
        # logging by pytorch-lightning
        # log val metrics (lightning uses tensorboard under the hood and stores the logs to a directory by default in lightning_logs)
        self.log("train/loss", loss, on_step=False, on_epoch=True, prog_bar=False)
        tensorboard_logs = {
            "train/loss": loss.item()
            }
        return {"train/dice_loss": loss, "log": tensorboard_logs}

        # log train metrics
        # acc = self.train_acc(preds, targets)
        # self.log("train/loss", loss, on_step=False, on_epoch=True, prog_bar=False)
        # self.log("train/acc", acc, on_step=False, on_epoch=True, prog_bar=True)

        # we can return here dict with any tensors
        # and then read it in some callback or in `training_epoch_end()`` below
        # remember to always return loss from `training_step()` or else backpropagation will fail!
        # return {"loss": loss, "preds": preds, "targets": targets}

    def training_epoch_end(self, outputs: List[Any]):
        # `outputs` is a list of dicts returned from `training_step()`
        pass

    def validation_step(self, batch: Any, batch_idx: int):        
        images, labels = batch["img"], batch["seg"]
        roi_size = self.hparams.dims
        sw_batch_size = 4
        outputs = sliding_window_inference(
            images, roi_size, sw_batch_size, self.forward)
        loss = self.loss_function(outputs, labels)
        
        preds = [self.post_pred(i) for i in decollate_batch(outputs)]
        labels  = [self.post_label(i) for i in decollate_batch(labels)]
        # metrics
        self.dice_metric_mon(y_pred=preds, y=labels)

        # log val metrics (lightning uses tensorboard under the hood and stores the logs to a directory by
        # default in lightning_logs)
        # acc = self.val_acc(preds, targets)
        self.log("val/dice_loss", loss, on_step=False, on_epoch=True, prog_bar=False)
        # self.log("val/acc", acc, on_step=False, on_epoch=True, prog_bar=True)

        # return {"loss": loss, "preds": preds, "targets": targets}
        return {"val/dice_loss": loss, "val/number": len(outputs)}


    def validation_epoch_end(self, outputs: List[Any]):
        val_loss, num_items = 0, 0
        
        for output in outputs:
            val_loss += output["val_loss"].sum().item()
            num_items += output["val_number"]
        
        mean_val_dice = self.dice_metric_mon.aggregate().item()
        self.dice_metric_mon.reset()
        mean_val_loss = torch.tensor(val_loss / num_items)
        tensorboard_logs = {
            "val/dice": mean_val_dice,
            "val/loss": mean_val_loss,
        }
        if mean_val_dice > self.best_val_dice:
            self.best_val_dice = mean_val_dice
            self.best_val_epoch = self.current_epoch
        print(
            f"current epoch: {self.current_epoch} "
            f"current mean dice: {mean_val_dice:.4f}"
            f"\nbest mean dice: {self.best_val_dice:.4f} "
            f"at epoch: {self.best_val_epoch}"
        )
        # return {"log": tensorboard_logs}
        return {"val/dice": mean_val_dice, "val/loss": mean_val_loss}

    def test_step(self, batch: Any, batch_idx: int):
        images, labels = batch["img"], batch["seg"]
        roi_size = self.hparams.dims
        sw_batch_size = 4
        outputs = sliding_window_inference(
            images, roi_size, sw_batch_size, self.forward)
        loss = self.loss_function(outputs, labels)
        
        preds = [self.post_pred(i) for i in decollate_batch(outputs)]
        labels = [self.post_label(i) for i in decollate_batch(labels)]
        # metrics
        self.dice_metric_mon(y_pred=preds, y=labels)

        # log val metrics (lightning uses tensorboard under the hood and stores the logs to a directory by default in lightning_logs)
        # acc = self.val_acc(preds, targets)
        self.log("test/loss", loss, on_step=False, on_epoch=True, prog_bar=False)
        # self.log("test/acc", acc, on_step=False, on_epoch=True, prog_bar=True)

        # return {"loss": loss, "preds": preds, "targets": targets}
        return {"test/loss": loss, "test/number": len(outputs)}

    def on_test_epoch_start(self):
        print("test_epoch_start")

    def test_epoch_end(self, outputs: List[Any]):
        test_loss, num_items = 0, 0
        
        for output in outputs:
            test_loss += output["test/loss"].sum().item()
            num_items += output["test/number"]
        
        mean_test_dice = self.dice_metric_mon.aggregate().item()
        self.dice_metric_mon.reset()
        mean_test_loss = torch.tensor(test_loss / num_items)
        print(
            f"current epoch: {self.current_epoch} "
            f"current mean dice: {mean_test_dice:.4f}"
            f"mean loss: {mean_test_loss:.4f}"
            f"at epoch: {self.best_test_epoch}"
        )
        return {"test/dice": mean_test_dice, "test/loss": mean_test_loss}


    def configure_optimizers(self):
        """Choose what optimizers and learning-rate schedulers to use in your optimization.
        Normally you'd need one. But in the case of GANs or similar you might have multiple.

        See examples here:
            https://pytorch-lightning.readthedocs.io/en/latest/common/lightning_module.html#configure-optimizers
        """
        # or self.parameters()
        opt = torch.optim.Adam(self._model.parameters(), lr=self.hparams.lr, weight_decay=self.hparams.weight_decay)
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max = 10)
        return [opt], [sch]
