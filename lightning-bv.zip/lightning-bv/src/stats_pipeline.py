import os
from typing import List, Optional

import hydra
from omegaconf import DictConfig
from pytorch_lightning import (
    LightningDataModule,
    seed_everything,
)
from pytorch_lightning.loggers import LightningLoggerBase

from src.utils import get_logger, log_hyperparameters, finish

log = get_logger(__name__)


def stats(config: DictConfig) -> Optional[float]:
    """Contains the training pipeline. Can additionally evaluate model on a testset, using best
    weights achieved during training.

    Args:
        config (DictConfig): Configuration composed by Hydra.

    Returns:
        Optional[float]: Metric score for hyperparameter optimization.
    """

    if 'action' not in config:
        print("add action from possible list\n  +action=[stats,distr,axis-class-distr]")
        return 1

    # Set seed for random number generators in pytorch, numpy and python.random
    if config.get("seed"):
        seed_everything(config.seed, workers=True)

    # fix seed by 


    # Init lightning datamodule
    log.info(f"Instantiating datamodule <{config.datamodule._target_}>")
    datamodule: LightningDataModule = hydra.utils.instantiate(config.datamodule)

    # Init lightning loggers
    logger: List[LightningLoggerBase] = []
    if "logger" in config:
        for _, lg_conf in config.logger.items():
            if "_target_" in lg_conf:
                log.info(f"Instantiating logger <{lg_conf._target_}>")
                logger.append(hydra.utils.instantiate(lg_conf))



    # compute stats the model
    if config.action == 'stats':
        log.info("computing stats (mean, std")
        datamodule.compute_stats()
    elif config.action == 'hash-distr':
        log.info("computing dataset hash distribution")        
        datamodule.compute_hash_distribution()
    elif config.action == 'axial-class-distr':
        log.info("computing class axial distribution")        
        datamodule.compute_class_axial_distribution()
    elif config.action == 'visualize-sample':
        log.info("visualize sample")        
        datamodule.visualize_image()
    else:
        log.error("check commands")        
    
    