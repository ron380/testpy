import numpy as np
import nibabel as nib
import hydra
from omegaconf import DictConfig, OmegaConf
from monai.transforms import LoadImage
import os
import sys
from torch import nn
import torch

# monai
# https://github.com/Project-MONAI/tutorials/blob/master/modules/image_dataset.ipynb
from monai.data import (ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch)
from monai.config import print_config
from monai.utils import first, set_determinism


from typing import List, Optional


from pytorch_lightning import (
    LightningDataModule,
    seed_everything,
)

# from pytorch_lightning.loggers import LightningLoggerBase
# from src.utils import get_logger
# log = get_logger(__name__)

@hydra.main(config_path="configs/", config_name="config.yaml")
def main(config: DictConfig) -> Optional[float]:
    """Contains the training pipeline. Can additionally evaluate model on a testset, using best
    weights achieved during training.

    Args:
        config (DictConfig): Configuration composed by Hydra.

    Returns:
        Optional[float]: Metric score for hyperparameter optimization.
    """

    print(OmegaConf.to_yaml(config))

    # Init lightning datamodule
    datamodule: LightningDataModule = hydra.utils.instantiate(config.datamodule)

    loader_dict = [dict(img=f"{config.dataset_dir}/15.mha", seg=f"{config.segmentation_dir}/15.mha", other=f"{config.other_dir}/15.png")]
    print(loader_dict)
    _transforms = datamodule.get_transforms("train")

    check_ds = Dataset(data=loader_dict, transform=_transforms)
    # pick the first image
    check_loader = DataLoader(check_ds, batch_size=1)
    check_data = first(check_loader)

    image, label, other = check_data['img'], check_data['seg'], check_data['other']

    print(f"image shape: {image.shape}")
    print(f"label shape: {label.shape}")
    print(type(image))
    visualize(image, label, other)

    
# @hydra.main(config_path="configs/appconfig", config_name="ranzocupai")
# def main(cfg : DictConfig) -> None:
#     print(OmegaConf.to_yaml(cfg))

#     load_image1 = LoadImage(reader="itkreader", image_only=True)
#     load_image2 = LoadImage(reader="pilreader", image_only=True)
#     loader_dict = [dict(img=f"{cfg.dataset_dir}/15.mha", seg=f"{cfg.segmentation_dir}/15.mha", other=f"{cfg.other_dir}/15.png")]
#     print(loader_dict)
#     image, label, other = load_image1(loader_dict[0]["img"]), \
#                           load_image1(loader_dict[0]["seg"]), \
#                           load_image2(loader_dict[0]["other"])
#     print(image)
#     # sys.exit()
#     visualize(image, label, other)



# view with napari
def visualize(image, label, other):
    import napari
    viewer = napari.view_image(image.numpy())
    viewer.add_labels(label.numpy().astype(np.int8))
    viewer.add_labels(other.numpy().astype(np.int8))
    
    napari.run()


if __name__ == '__main__':
    main()