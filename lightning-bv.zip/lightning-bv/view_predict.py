import argparse
from pathlib import Path
from encodings import normalize_encoding
import numpy as np
from monai.data import ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch
from monai.transforms import (
    Compose,
    AdjustContrastd, 
    EnsureChannelFirst,
    NormalizeIntensityd,
    RandAdjustContrast,
    RandAffined,
    RandRotated,
    Orientationd,
    Spacingd, 
    LoadImaged,
    Rotate90d,
    RandSpatialCropd,
    RandFlipd,
    ScaleIntensityRanged,
    RandCropByLabelClassesd,
    RandCropByPosNegLabeld,
    ToTensord,
    LoadImage, 
    CropForegroundd,
    LoadImaged,
    AddChanneld,
    Resized,
    EnsureTyped,
    RandRotate90d, 
    Identity)
from monai.transforms.utility.dictionary import (    
    Transposed)
from monai.config import print_config
from monai.utils import first, set_determinism






# view with napari
def visualize(image, label):
    import napari
    viewer = napari.view_image(image.numpy())
    viewer.add_labels(label.numpy().astype(np.int8))
    napari.run()



def visualize_pred(args):
    predfile = Path(args.pred)
    print(predfile.name)
    # import napari
    # viewer = napari.view_image(image.numpy())
    # viewer.add_labels(label.numpy().astype(np.int8))
    # napari.run()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--pred", type=str)
    args = parser.parse_args()
