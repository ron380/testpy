# running stats

  python stats.py train=brainventricles-bilateral +action=stats
  python stats.py train=brainventricles +action=stats


# viewer of images
python view_image.py GIHBCHGT_T1