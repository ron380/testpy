from encodings import normalize_encoding
import numpy as np
import argparse
import nibabel as nib




# view with napari
def visualize(image, label):
    import napari
    viewer = napari.view_image(image.get_fdata())
    viewer.add_labels(label.get_fdata().astype(np.int8))
    napari.run()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("name") # , "patient accession prefix + modality [YFGXRRTF_T1]")
    args = parser.parse_args()

    patient = args.name
    print(patient)
    # patient = "YFGXRRTF_T1"
    loader_dict = [dict(img=f"/mnt/data/Data/GroundTruth/BrainVentricles/dataset/{patient}_image.nii.gz", seg=f"/mnt/data/Data/GroundTruth/BrainVentricles/dataset/{patient}_label.nii.gz")]
    image, label = nib.load(loader_dict[0]["img"]), nib.load(loader_dict[0]["seg"])
    visualize(image, label)