from encodings import normalize_encoding
import numpy as np
import argparse
import nibabel as nib
import hydra
from omegaconf import DictConfig, OmegaConf
from monai.transforms import LoadImage
import sys
from torch import nn
import torch


class Sobel(nn.Module):
    def __init__(self):
        super().__init__()
        self.filter = nn.Conv2d(in_channels=1, out_channels=2, kernel_size=3, stride=1, padding=0, bias=False)

        Gx = torch.tensor([[2.0, 0.0, -2.0], [4.0, 0.0, -4.0], [2.0, 0.0, -2.0]])
        Gy = torch.tensor([[2.0, 4.0, 2.0], [0.0, 0.0, 0.0], [-2.0, -4.0, -2.0]])
        G = torch.cat([Gx.unsqueeze(0), Gy.unsqueeze(0)], 0)
        G = G.unsqueeze(1)
        self.filter.weight = nn.Parameter(G, requires_grad=False)

    def forward(self, img):
        x = self.filter(img)
        x = torch.mul(x, x)
        x = torch.sum(x, dim=1, keepdim=True)
        x = torch.sqrt(x)
        return x




@hydra.main(config_path="configs/appconfig", config_name="ranzocupai")
def main(cfg : DictConfig) -> None:
    print(OmegaConf.to_yaml(cfg))

    load_image1 = LoadImage(reader="itkreader", image_only=True)
    load_image2 = LoadImage(reader="pilreader", image_only=True)
    loader_dict = [dict(img=f"{cfg.dataset_dir}/15.mha", seg=f"{cfg.segmentation_dir}/15.mha", other=f"{cfg.other_dir}/15.png")]
    print(loader_dict)
    image, label, other = load_image1(loader_dict[0]["img"]), \
                          load_image1(loader_dict[0]["seg"]), \
                          load_image2(loader_dict[0]["other"])
    print(image)
    # sys.exit()
    visualize(image, label, other)



# view with napari
def visualize(image, label, other):
    torch_sobel = Sobel()
    rgb_edged = sobel_torch_version(rgb_orig, torch_sobel=torch_sobel)
    import napari
    viewer = napari.view_image(image)
    viewer.add_labels(label.astype(np.int8))
    viewer.add_labels(other.astype(np.int8))
    
    napari.run()


if __name__ == '__main__':
    main()