tensorboard --logdir=lightning_logs/

# from jupyter
%reload_ext tensorboard
%tensorboard --logdir=lightning_logs/

# By default, Lightning logs every 50 steps. Use Trainer flags to Control Logging Frequency.

## self.log("val/dice_loss", loss, on_step=False, on_epoch=True, prog_bar=False)

"""
The self.log() method has a few options:

    on_step: Logs the metric at the current step.

    on_epoch: Automatically accumulates and logs at the end of the epoch.

    prog_bar: Logs to the progress bar (Default: False).

    logger: Logs to the logger like Tensorboard, or any other custom logger passed to the Trainer (Default: True).

    reduce_fx: Reduction function over step values for end of epoch. Uses torch.mean() by default.

    enable_graph: If True, will not auto detach the graph.

    sync_dist: If True, reduces the metric across devices. Use with care as this may lead to a significant communication overhead.

    sync_dist_group: The DDP group to sync across.

    add_dataloader_idx: If True, appends the index of the current dataloader to the name (when using multiple dataloaders). If False, user needs to give unique names for each dataloader to not mix the values.

    batch_size: Current batch size used for accumulating logs logged with on_epoch=True. This will be directly inferred from the loaded batch, but for some data structures you might need to explicitly provide it.

    rank_zero_only: Whether the value will be logged only on rank 0. This will prevent synchronization which would produce a deadlock as not all processes would perform this log call.

"""