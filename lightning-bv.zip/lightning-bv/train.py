#import dotenv
import hydra
from omegaconf import DictConfig, OmegaConf
import src.utils
from src.utils.extras import print_config

@hydra.main(version_base=None, config_path="configs/", config_name="config.yaml")
def main(config: DictConfig):

    from src.utils import extras
    from src.training_pipeline import train

    # print(config)
    # Applies optional utilities
    extras(config)

    # Train model
    return train(config)


if __name__ == "__main__":
    main()
