# %% 

import numpy as np
from monai.data import ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch
from monai.transforms import (
    Compose,
    AdjustContrastd, 
    EnsureChannelFirst,
    NormalizeIntensityd,
    LoadImage,
    LoadImaged
)
import napari
from argparse import Namespace
import os
import sys

# %%


DATA_DIR = "Z:/datasets" if os.name =='nt' else '/mnt/data/Data/datasets'

args = Namespace(
    PY37 = sys.version_info.minor == 7,
    dataset_dir = os.path.join(DATA_DIR, 'OCUPAI_challenge')
)
