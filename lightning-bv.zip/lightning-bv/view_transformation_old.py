from encodings import normalize_encoding
import numpy as np
from monai.data import ImageDataset, Dataset, DataLoader, CacheDataset, list_data_collate, decollate_batch
from monai.transforms import (
    Compose,
    AdjustContrastd, 
    EnsureChannelFirst,
    NormalizeIntensityd,
    RandAdjustContrast,
    RandAffined,
    RandRotated,
    Orientationd,
    Spacingd, 
    LoadImaged,
    Rotate90d,
    RandSpatialCropd,
    RandFlipd,
    ScaleIntensityRanged,
    RandCropByLabelClassesd,
    RandCropByPosNegLabeld,
    ToTensord,
    LoadImage, 
    CropForegroundd,
    LoadImaged,
    AddChanneld,
    Resized,
    EnsureTyped,
    RandRotate90d, 
    Identity)
from monai.transforms.utility.dictionary import (    
    Transposed)
from monai.config import print_config
from monai.utils import first, set_determinism



def transform(loader_dict):
    
    prob = 1.0

    preprocess_transformations = [
        LoadImaged(keys=['img', 'seg']),

        AddChanneld(keys=['img', 'seg']),
        # Orientationd(keys=["img", "seg"], axcodes="RAS"),

        # ZScore std dev [-4, -4] to [0, 1]
        NormalizeIntensityd(keys=['img'], nonzero=True),
        ScaleIntensityRanged(keys=["img"], a_min=-3.5, a_max=3.5, b_min=0, b_max=1, clip=True),



        # affine transformation 
        # shear transformation
        # rand90d
        # random crop, shift, center rotate


        # RandRotate90d(
        #     keys=["img", "seg"],
        #     prob=0.2,
        # ),

        # other randrotoate

        # ok
        # RandRotated(
        #     keys=["img", "seg"],
        #     # mode=("bilinear", "nearest"),
        #     prob=1.0,
        #     range_z=0.5,
        #     keep_size=True,
        #     # padding_mode="zeros",
        #     dtype=np.float32
        # ),
        CropForegroundd(keys=["img", "seg"], source_key='seg')

        # RandCropByPosNegLabeld(
        #     keys=["img", "seg"],
        #     label_key="seg",
        #     image_key="img",
        #     spatial_size=(224, 224, 24),
        #     pos=1,
        #     neg=1,
        #     num_samples=4,
        #     image_threshold=0,
        # ),


        # ok
        # RandFlipd(keys=["img", "seg"], prob=0.5, spatial_axis=0),
        # RandFlipd(keys=["img", "seg"], prob=0.5, spatial_axis=1),
        # RandFlipd(keys=["img", "seg"], prob=0.5, spatial_axis=2),


        # gamma random after zscore 

        # rescale final after 

        # RandSpatialCropd(keys=["img", "seg"], random_center=False, roi_size=(224, 224, -1), random_size=True),
        # NormalizeIntensityd(keys="img", nonzero=True, channel_wise=True),
        # EnsureTyped(keys=["img", "seg"]),
        
        # Rotate90d(
        #     keys=["img", "seg"],
        #     # mode=("bilinear", "nearest"),
        #     # prob=1.0,
        #     # translate_range=(40, 40, 2),
        #     # rotate_range=(np.pi / 10, np.pi / 10, 0),
        #     # range_x=0.4,
        #     # scale_range=(0.15, 0.15, 0.15),
        #     # padding_mode="zeros",
        # )

        # Transposed(keys=['img', 'seg'], indices=(2, 1, 0)),
        # # # add channel (grayscale)
        
        # Resized(keys=['img', 'seg'],
        #     spatial_size=resize_target,
        #     mode=['trilinear', 'nearest'],
        #     align_corners=[False, None]
        # ) if resize_target is not None else Identity(),

        # ModalityBasedTransformd(keys=['img', 'mod'], 
        #     transform=partial(CTThresholdIntensityd, a_min=0, a_max=80), 
        #     modality='CT'),
        # ModalityBasedTransformd(keys=['img', 'mod'], 
        #     transform=partial(NormalizeIntensityd, subtrahend=mean_FLAIR, divisor=std_FLAIR), 
        #     modality='FLAIR'),
        # ModalityBasedTransformd(keys=['img', 'mod'], 
        #     "transform=partial(NormalizeIntensityd, subtrahend=mean_T1, divisor=std_T1), 
        #     modality='T1'),        
        ]

    _transforms = Compose(transforms=preprocess_transformations)

    check_ds = Dataset(data=loader_dict, transform=_transforms)
    # pick the first image
    check_loader = DataLoader(check_ds, batch_size=1)
    check_data = first(check_loader)

    image, label = check_data['img'], check_data['seg']

    print(f"image shape: {image.shape}")
    print(f"label shape: {label.shape}")
    return image, label



# view with napari
def visualize(image, label):
    import napari
    viewer = napari.view_image(image.numpy())
    viewer.add_labels(label.numpy().astype(np.int8))
    napari.run()

if __name__ == '__main__':
    patient = "YFGXRRTF_T1"
    loader_dict = [dict(img=f"/mnt/data/Data/GroundTruth/BrainVentricles/dataset/{patient}_image.nii.gz", seg=f"/mnt/data/Data/GroundTruth/BrainVentricles/dataset/{patient}_label.nii.gz")]
    image, label = transform(loader_dict)
    visualize(image, label)