import numpy as np
import argparse
import nibabel as nib
import sys
from pathlib import Path




# view with napari
def visualize(image, label):
    import napari
    viewer = napari.view_image(image.get_fdata())
    viewer.add_labels(label.get_fdata().astype(np.int8))
    napari.run()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("name") # , "patient accession prefix + modality [fullname, i.e.: UPENN-GBM-00005_11_T1_unstripped.nii.gz]")
    parser.add_argument("eval_dir")
    parser.add_argument("dataset_dir")
    args = parser.parse_args()

    name = args.name
    dataset_dir = args.dataset_dir
    eval_dir = args.eval_dir
    print(name)
    # patient = "YFGXRRTF_T1"
    
    # look for the path
    try:
        imgname = next(Path(dataset_dir).rglob(f"{name}*"))
        print(imgname)
    except StopIteration:
        print(f"can't find {name} in {dataset_dir}")
        sys.exit(1)    
    stem = Path(imgname.stem).stem
    loader_dict = [dict(img=imgname, pred=f"./logs/evaluations/runs/brainventricles/{eval_dir}/preds/{stem}_pred.nii.gz")]    
    image, pred = nib.load(loader_dict[0]["img"]), nib.load(loader_dict[0]["pred"])
    visualize(image, pred)
    
    # # patient = "YFGXRRTF_T1"
    # loader_dict = [dict(img=f"ata/GroundTruth/BrainVentricles/dataset/{patient}_label.nii.gz")]
    # image, label = nib.load(loader_dict[0]["img"]), nib.load(loader_dict[0]["seg"])
    # visualize(image, label)