#!/usr/bin/env python
import sys
import getopt
import json
import os
import pandas as pd


def main(argv):
	inputfile = ''
	outputfile = ''
	try:
		opts, args = getopt.getopt(argv, "hi:o:", ["ifile=", "ofile="])
	except getopt.GetoptError:
		print('test.py -i <inputfile> -o <outputfile>')
		sys.exit(2)
	for opt, arg in opts:
		if opt == '-h':
			print('test.py -i <inputfile> -o <outputfile>')
			sys.exit()
		elif opt in ("-i", "--ifile"):
			inputfile = arg
		elif opt in ("-o", "--ofile"):
			outputfile = arg
	#print('Input file is ', inputfile)
	#print('Output file is ', outputfile)

	if inputfile != '':
		if outputfile == '':
			outputfile = os.path.splitext(inputfile)[0] + ".csv"
		print(outputfile)

		with open(inputfile, "r") as f:
			content = json.load(f)
			df = pd.json_normalize(content)
			df.to_csv(outputfile, index=False)


if __name__ == "__main__":
	main(sys.argv[1:])
