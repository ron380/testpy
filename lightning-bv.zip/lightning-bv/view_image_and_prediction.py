from encodings import normalize_encoding
import numpy as np
import argparse
import nibabel as nib




# view with napari
def visualize(image, label, pred):
    import napari
    viewer = napari.view_image(image.get_fdata())
    viewer.add_labels(label.get_fdata().astype(np.int8), name="groundtruth", opacity=0.3)
    viewer.add_labels(pred.get_fdata().astype(np.int8), name="preds", opacity=0.7)
    
    napari.run()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("name") # , "patient accession prefix + modality [YFGXRRTF_T1]")
    parser.add_argument("evaldir")
    args = parser.parse_args()

    patient = args.name
    evaldir = args.evaldir
    print(patient)
    # patient = "YFGXRRTF_T1"
    loader_dict = [dict(img=f"/mnt/data/Data/GroundTruth/BrainVentricles/dataset/{patient}_image.nii.gz", seg=f"/mnt/data/Data/GroundTruth/BrainVentricles/dataset/{patient}_label.nii.gz", pred=
    f"./logs/evaluations/runs/brainventricles/{evaldir}/preds/{patient}_image_pred.nii.gz")]    
    # f"./preds/{patient}_image_pred.nii.gz")]
    image, label, pred = nib.load(loader_dict[0]["img"]), nib.load(loader_dict[0]["seg"]), nib.load(loader_dict[0]["pred"])
    visualize(image, label, pred)