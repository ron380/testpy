
library(rpart)

# cat("iris = ", nrow(iris), "\n")
# print(iris$Species)

data("Forbes2000", package = "HSAUR")

Forbes2000 <- subset(Forbes2000, !is.na(profits))
# print(Forbes2000)

forbes_rpart <- rpart(profits ~ country + assets + marketvalue + sales, data = Forbes2000)
# m = rpart(Species ~ ., data=iris)