library(devtools)

devtools::install_local(".", force=TRUE)