
# As a sop to S, I need to keep the total number of external symbols
# somewhat smaller.  So, pack most of them all into a structure.
# convert to structure
rp <- list(
  complexity = 0,
  alpha = 0,
  iscale = 0,
  ydata = NULL,
  xdata = NULL,
  xtemp = NULL,
  wt = NULL,
  ytemp = NULL,
  wtemp = NULL,
  lwt = NULL,
  rwt = NULL,
  vcost = NULL,
  numcat = NULL,
  sorts = NULL,
  n = 0,
  num_y = 0,
  nvar = 0,
  maxpri = 0,
  maxsur = 0,
  usesurrogate = 0,
  num_unique_cp = 0,
  min_node = 0,
  min_split = 0,
  num_resp = 0,
  sur_agree = 0,
  maxnode = 0,
  tempvec = NULL,
  which = NULL,
  csplit = NULL,
  left = NULL,
  right = NULL
)

cptable_tail <- NULL
nodesize <- 0

# called to initialize a splitting function
rp_init <- NULL

# set to the splitting function
rp_choose <- NULL

# set to the evaluation routine
rp_eval <- NULL

# set to the prediction error routine
rp_error <- NULL



#
# The main entry point for recursive partitioning routines.
#
# Input variables:
#      ncat    = # categories for each var, 0 for continuous variables.
#      method  = 1 - anova
#                2 - exponential survival
#		         3 - classification
#	             4 - user defined callback
#      opt     = vector of options.  Same order as rpart.control, as a vector
#                   of doubles.
#      parms   = extra parameters for the split function, e.g. poissoninit
#      xvals    = number of cross-validations to do
#      xgrp     = indices for the cross-validations
#      ymat    = vector of response variables
#      xmat    = matrix of continuous variables
#      ny      = number of columns of the y matrix (it is passed in as a vector)
#      wt       = vector of case weights
#
# Returned: a list with elements
#      which = vector of final node numbers for each input obs
#      cptable = the complexity table
#      dsplit = for each split, numeric variables (doubles)
#      isplit = for each split, integer variables
#      dnode =  for each node, numeric variables
#      inode =  for each node, integer variables
#
# Naming convention: ncat = pointer to an integer vector, ncat2 = the
#   input R object (SEXP) containing that vector, ncat3 = an output S object
#   containing that vector.
#


parent <- function(i) floor(i/2)
leftchild <- function(i) 2*i
rightchild <- function(i) 2*i+1


Node <- function() {
    node <- list(risk=risk,                # risk for the node
        complexity=complexity,              # complexity at which it will collapse
        sum_wt=sum_wt,                      # sum of the weights for the node
        
        # pSplit primary, surrogate;
        left =NULL,
        right=NULL,
    
        num_obs=num_obs,
        lastsurrogate=lastsurrogate)
        # double response_est[20];   # actual length depends on splitting rule */

}


rp_tree <- rp <- list(
    complexity = 0.0,
    alpha = 0.0,
    iscale = 0.0,                   # used to check improvement==0, with error
    ydata = NULL,                   # array of y data
    xdata = NULL,                   # array of x data
    xtemp = NULL,                   # temporary vector for x
    wt = NULL,                      # weights
    ytemp = NULL,                   # temporary array of y data
    wtemp = NULL,                   # temp vector of weights
    lwt = NULL,                     # vector of weights (lwt)
    rwt = NULL,                     # scratch double vectors, of length ncat
    vcost = NULL,                   # variable costs
    numcat = NULL,                  # variable type: 0=cont, 1+  =#categories
    sorts = NULL,                   # matrix of sort indices
    n = 0,                          # total number of subjects
    num_y = 0,                      # number of y variables
    nvar = 0,                       # number of predictors
    maxpri = 0,
    maxsur = 0,                     # max # of primary or surrogate splits to use
    usesurrogate = 0,
    num_unique_cp = 0,
    min_node = 0,                   # minimum size for any terminal node
    min_split = 0,                  # minimum size before we attempt a split
    num_resp = 0,                   # length of the response vector
    sur_agree = 0,                  # 0 = my style, 1=CART style
    maxnode = 0,                    # controls the maximum depth of the tree
    tempvec = NULL,                 # to be allocated by the mainline, of length n
    which = NULL,
    csplit = NULL,
    left = NULL,
    right = NULL
)


# ncat - categories in input X
rpart_rp <- function(ncat, method, rpart_control, exrea_parms, n_crossvals, n_crossvals_indices, y, X, weights, n_y, cost) {

    N <- nrow(X)
    cat(">>> rpart_rp: begi\n")
    cat(">>> rpart_rp: dataframe")
    print(X)
    cat(">>> rpart_rp: y")
    print(y)
    
    # update the tree object pNode
    num_obs <-N
    sum_weights 

    
    # rp object
    # initialize the top node of the tree
    
    which3 = PROTECT(allocVector(INTSXP, n));
    rp.which = INTEGER(which3);
    temp = 0;

    sum_weights <- sum(weights)
    
    # for (i = 0; i < n; i++) {
	# rp.which[i] = 1;
	# temp += wt[i];
    # }


}


rpart_fit <- function(features, target) {


}

partition.rpartr <- function(me, n1, n2, ...) {
    if (!inherits(me, "Node"))
        stop("Not rpartr node")

    if (me$num_obs < rp_control$min_split || temp_cp <= alpha) {
        me$complexity <- rp_control$alpha
        # write out sumrisk
        me$left = NULL
    	me$right = NULL
    	me$primary = NULL
	    me$surrogate = NULL
	    return (0)

    }


}


best_feature_split = function() {

    # sapply is a map function that is applied by default on each column
    results <- sapply(X, FUN=function(feature) max_information_gain_split(feature))
    
    
    if (!all(is.na(unlist(results['best_change',])))) {
        best_name <- names(which.max(results['best_change',]))
        best_result <- results[,best_name]
        best_result[["name"]] <- best_name
        best_split <<- best_result
    }          
}

#
# The routine which will find the best split for a node
#
# Input :      node
#              node number
#
# Output:      Fills in the node's
#                      primary splits
#                      competitor splits

best_split <- function(me, n1, n2) {
    if (!inherits(me, "Node"))
        stop("Not rpartr node")

    improve <- 0
    split <- 0.0
    tsplit <- NULL
    
    xtemp <- rp$xtemp
    ytemp <- rp$ytemp
    wtemp <- rp$wtemp
    
    # Test out the variables one at a time
    me$primary <- NULL
    for (i in 1:rp$nvar) {
        index <- rp$sorts[[i]]
        nc <- rp$numcat[i]
        
        # Extract x and y data
        k <- 0
        for (j in n1:n2) {
            kk <- index[j]
            if (kk >= 0 && rp$wt[kk] > 0) {  # x data not missing and wt > 0
                xtemp[k] <- rp$xdata[[i]][kk]
                ytemp[k] <- rp$ydata[[kk]]
                wtemp[k] <- rp$wt[[kk]]
                k <- k + 1
            }
        }
        
        if (k == 0 || (nc == 0 && xtemp[1] == xtemp[k])) {
            next  # no place to split
        }
        
        rp_choose(k, ytemp, xtemp, nc, rp$min_node, improve, split, rp$csplit, me$risk, wtemp)
        
        # Originally, this just said "if (improve > 0)", but rounding
        # error will sometimes create a non zero that should be 0. Yet we
        # want to retain invariance to the scale of "improve".
        if (improve > rp$iscale) {
            rp$iscale <- improve  # largest seen so far
        }
        if (improve > (rp$iscale * 1e-10)) {
            improve <- improve / rp$vcost[i]  # scale the improvement
            tsplit <- insert_split(me$primary, nc, improve, rp$maxpri)
            if (!is.null(tsplit)) {
                tsplit$improve <- improve
                tsplit$var_num <- i
                tsplit$spoint <- split
                tsplit$count <- k
                if (nc == 0) {
                    tsplit$spoint <- split
                    tsplit$csplit[1] <- rp$csplit[1]
                } else {
                    for (k in 1:nc) {
                        tsplit$csplit[k] <- rp$csplit[k]
                    }
                }
            }
        }
    }
}



# /*called to initialize a splitting function */
# EXTERN int (*rp_init) (int, double **, int, char **, double *, int *,
# 		       int, double *);
# /*set to the splitting function */
# EXTERN void (*rp_choose) (int, double **, double *, int, int, double *,
# 			  double *, int *, double, double *);
# /*set to the evaluation routine */
# EXTERN void (*rp_eval) (int, double **, double *, double *, double *);
# /*set to the prediction error routine */
# EXTERN double (*rp_error) (double *, double *);
