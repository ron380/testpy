# done with the R internals
LEFT <- -1
RIGHT <- 1
MISSING <- 0
