# https://github.com/bryantravissmith/FromScratch/blob/master/SupervisedLearning/DecisionTrees/Implementing%20Decision%20Trees%20From%20Scratch%20Using%20R.ipynb

# from In[6]
entropy <- function(y) {
    # assumes y is a factor with all levels
    if(length(y)==0) return(0)
    
    # table is the frequency count in R for a vector
    p <- table(y)/length(y)
    sum(-p*log2(p+1e-9))
}

gini_impurity <- function(y) {
    # assumes y if a factor with all levels
    if(length(y) == 0) return(0)
    
    p <- table(y)/length(y)
    1-sum(p^2)
}

variance <- function(y){
    if(length(y) <= 1) return(0)
    
    var(y)
}

information_gain <- function(y, mask, FUN) {
    if (!is.function(FUN))
        stop("not a function.")
    
    if (length(y) != length(mask))
        stop("length mismatch.")
    
    # create two groups with count s1 and s2 for each group
    n <- length(mask)
    # mask is zero/one array
    s1 <- sum(mask)
    
    if (s1 == 0 || s1 == n) return(0)
    
    FUN(y) - s1/n * FUN(y[mask]) - (1 - s1/n) * FUN(y[!mask])
}


# x is a single predictor and y is the target
# copied from R From Scratch Decision Tree
max_information_gain_split <- function(rp, x, y, func) {
    # initialization
    best_change = NA
    split_value = NA
    previous_val <- NA

    is_numeric = !(is.factor(x) || is.logical(x) || is.character(x))
    
    # go over a discretized vector x sorted
    for( val in sort(unique(x))) {
        mask <- ifelse(is_numeric, x < val, x == val)

        change <- information_gain(y, mask, func)
        
        s1 <- sum(mask)
        s2 <- length(mask) - s1
        # update best_change
        if (is.na(best_change) && s1 >= rp$min_leaf_size && s2 >= min_leaf_size) {
            best_change = change
            split_value = ifelse(is.na(previous_val),
                                        val,
                                        mean(c(val,previous_val)))            
        } else if (change > best_change && s1 >= min_leaf_size && s2 >= min_leaf_size ) {
            best_change = change
            split_value = ifelse(is_numeric,
                                    mean(c(val,previous_val)),
                                    val)            
        }
        
        previous_val <- val
    }

    # structure
    list(best_change=best_change, split_value=split_value, is_numeric=is_numeric)
}


best_feature_split = function(rp, X, y, func) {
    results <- sapply(X, FUN=function(x) max_information_gain_split(rp, x, y, func))
    
    if (!all(is.na(unlist(results['best_change',])))) {
        best_name <- names(which.max(results['best_change',]))
        best_result <- results[,best_name]
        best_result[["name"]] <- best_name
        best_split <<- best_result
    }
    return (best_split)
          
}

best_mask = function(best_split, X) {
    best_mask <- x[,best_split$name] == best_split$split_value
    
    if(best_split$is_numeric) {
        best_mask <- X[,best_split$name] < best_split$split_value
    }
    return(best_mask)
}