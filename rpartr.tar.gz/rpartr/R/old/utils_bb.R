# Auxiliary function that determines if all the components of a vector are integers
testInteger <- function(x) {
    test <- round(x, 10) - round(x, 0)
    tolerance <- rep(-1e-10, length(test))

    # test passed
    if (all(test < tolerance) || all(test == 0))
        return(TRUE)
        
    
    return(FALSE)
}

# Auxiliary function that gets the component furthest from being integer of a vector
furtherFromInteger <- function(x) {
    j <- 1
    max <- -Inf
    furthest <- c(-1, -1)
    flag <- FALSE
    for (i in x) {
        if ((abs(i - round(i, 0))) > 0.5) {
            flag <- TRUE
        }

        if (flag == FALSE && round(abs(i - round(i, 0)), 10) > round(max, 10)) {
            max <- round(abs(i - round(i, 0)), 10)
            if (max != 0) {
                furthest[1] <- i
                furthest[2] <- j
            }
        } else if (flag == TRUE && round((round(i, 0) + 1) - i, 10) > round(max, 10)) {
            max <- round((round(i, 0) + 1) - i, 10)
            if (max != 0) {
                furthest[1] <- i
                furthest[2] <- j
            }
        }
        flag <- FALSE
        j <- j + 1
    }
    return(furthest)
}


# Auxiliary function that determines if a solution is feasible
isFeasible <- function(A, b, x) {
    flag_feasible <- TRUE

    for (i in 1:nrow(A)) {
        if (A[i, ] %*% x > b[i]) {
            flag_feasible <- FALSE
        }
    }

    return(flag_feasible)
}
