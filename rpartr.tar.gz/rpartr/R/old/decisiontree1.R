# Define a class for DecisionTree
DecisionTree <- setClass("DecisionTree",
    slots = c(
        root = "list"
    )
)

# Function to create a new node
new_node <- function(split_feature = NULL, split_value = NULL, is_leaf = FALSE, prediction = NULL) {
    node <- list(
        split_feature = split_feature,
        split_value = split_value,
        is_leaf = is_leaf,
        prediction = prediction,
        left_child = NULL,
        right_child = NULL
    )
    return(node)
}

# Function to fit the decision tree
fit_decision_tree <- function(data, target_col, max_depth = Inf) {
    # Recursively build decision tree
    build_tree <- function(data, depth) {
        n <- nrow(data)
        if (depth == 0 || n == 0) {
            # Create a leaf node with the majority class as prediction
            prediction <- mean(data[[target_col]])
            return(new_node(is_leaf = TRUE, prediction = prediction))
        }

        best_split <- find_best_split(data, target_col)
        if (is.null(best_split)) {
            # Create a leaf node with the majority class as prediction
            prediction <- mean(data[[target_col]])
            return(new_node(is_leaf = TRUE, prediction = prediction))
        }

        # Split the data based on the best split
        left_data <- data[data[[best_split$feature]] <= best_split$value, , drop = FALSE]
        right_data <- data[data[[best_split$feature]] > best_split$value, , drop = FALSE]

        # Recursively build left and right subtrees
        left_child <- build_tree(left_data, depth - 1)
        right_child <- build_tree(right_data, depth - 1)

        # Create a decision node
        node <- new_node(split_feature = best_split$feature, split_value = best_split$value)
        node$left_child <- left_child
        node$right_child <- right_child

        return(node)
    }

    # Find the best split based on information gain
    find_best_split <- function(data, target_col) {
        best_gain <- -Inf
        best_split <- NULL
        n_features <- ncol(data) - 1

        for (i in 1:n_features) {
            values <- unique(data[[i]])
            for (value in values) {
                left_data <- data[data[[i]] <= value, , drop = FALSE]
                right_data <- data[data[[i]] > value, , drop = FALSE]

                if (nrow(left_data) == 0 || nrow(right_data) == 0) next

                gain <- information_gain(data[[target_col]], left_data[[target_col]], right_data[[target_col]])
                if (gain > best_gain) {
                    best_gain <- gain
                    best_split <- list(feature = i, value = value)
                }
            }
        }

        return(best_split)
    }

    # Calculate information gain
    information_gain <- function(parent, left_child, right_child) {
        total_entropy <- entropy(parent)
        left_weight <- length(left_child) / length(parent)
        right_weight <- length(right_child) / length(parent)
        gain <- total_entropy - (left_weight * entropy(left_child) + right_weight * entropy(right_child))
        return(gain)
    }

    # Calculate entropy
    entropy <- function(data) {
        if (length(data) == 0) {
            return(0)
        }
        proportions <- table(data) / length(data)
        entropy <- -sum(proportions * log2(proportions))
        return(entropy)
    }

    # Build the decision tree
    root <- build_tree(data, max_depth)

    # Create and return the DecisionTree object
    return(DecisionTree(root = root))
}

# Predict method for DecisionTree
predict.DecisionTree <- function(model, newdata) {
    predict_tree <- function(node, row) {
        if (node$is_leaf) {
            return(node$prediction)
        }

        if (row[[node$split_feature]] <= node$split_value) {
            return(predict_tree(node$left_child, row))
        } else {
            return(predict_tree(node$right_child, row))
        }
    }

    predictions <- sapply(1:nrow(newdata), function(i) predict_tree(model@root, newdata[i, , drop = FALSE]))
    return(predictions)
}

# Example usage:
# Load iris dataset
data(iris)

# Fit decision tree model
tree_model <- fit_decision_tree(iris[, -5], target_col = "Species", max_depth = 3)

# Make predictions
predictions <- predict(tree_model, iris[, -5])
print(predictions)
