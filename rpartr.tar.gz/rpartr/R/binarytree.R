# Define a structure for the tree node

TreeNode <- function(value = NULL, left = NULL, right = NULL) {
    structure(
        list(
            value = value,
            left = left,
            right = right
        ),
        class = "TreeNode"
    )
}

# Define a function to create a new binary tree
#' @export
create_binary_tree <- function() {
  structure(
    list(
      root = NULL
    ),
    class = "BinaryTree"
  )
}

# Define a function to insert a value into the binary tree
insert <- function(tree, value) {
    
    if (is.null(tree$root)) {
        tree$root <- TreeNode(value)
    } 
    else {
        current <- tree$root
        while (TRUE) {
        if (value < current$value) {
            if (is.null(current$left)) {
                current$left <- TreeNode(value)
                break
            } 
            else {
                current <- current$left
            }
        } else {
            if (is.null(current$right)) {
                current$right <- TreeNode(value)
                break
            } 
            else {
                current <- current$right
            }
        }
        }
    }
}

# Define a function to traverse the binary tree in-order
traverse_inorder <- function(node) {
    if (!is.null(node)) {
        traverse_inorder(node$left)
        cat(node$value, " ")
        traverse_inorder(node$right)
    }
}

# Define a print method for the BinaryTree class
#' @export
print.BinaryTree <- function(tree) {
  cat("In-order traversal of the binary tree: ")
  traverse_inorder(tree$root)
  cat("\n")
}

# Example usage:
# Create a new binary tree
tree <- create_binary_tree()

# Insert values into the binary tree
insert(tree, 5)
insert(tree, 3)
insert(tree, 7)
insert(tree, 2)
insert(tree, 4)
insert(tree, 6)
insert(tree, 8)

# Print the binary tree
print(tree)
