
# Function to find the maximal fraction value in a x
max_fraction <- function(x) {
    fractions <- x %% 1  # Get the fractional part of each element
    idx_fraction <- which.max(fractions)
    # the index of the maximal fraction
    return(idx_fraction)
}