# Define a tree node structure
createNode <- function(value, left = NULL, right = NULL) {
  list(value = value, left = left, right = right)
}

# Insert a value into the binary tree
# using root as the current node to work on
insert <- function(root, value) {
  if (is.null(root)) {
    return createNode(value)
  }
  if (value < root$value) {
    root$left <- insert(root$left, value)
  } else {
    root$right <- insert(root$right, value)
  }
  return root
}

# In-order traversal of the binary tree
# left (recursive), current node, right (recursive)
inOrderTraversal <- function(root) {
  if (!is.null(root)) {
    inOrderTraversal(root$left)
    cat(root$value, " ")
    inOrderTraversal(root$right)
  }
}

# Example usage
root <- NULL
values <- c(5, 3, 8, 2, 4, 7, 9)

for (value in values) {
  root <- insert(root, value)
}

cat("In-order traversal: ")
inOrderTraversal(root)
