
###############
### Implementation
###############

# Auxiliary function that determines if all the components of a vector are integers
testInteger <- function(x, digits=6) {
    tol <- 10**(-digits)
    test <- round(x, digits) - round(x, 0)
    tolerance <- rep(-tol, length(test))
    
    if (all(test < tolerance) || all(test == 0))
        return(TRUE)
    return (FALSE)
}
