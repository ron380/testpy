

# gini <- list(init_split=gini_init, choose_split=gini, eval=gini_dev, pred=gini_pred)


information_gain <- function(mask, minimize_func) {
    s1 = sum(mask)
    s2 = length(mask)-s1
    
    if ( s1 == 0 | s2 == 0) 
        return(0)
    
    minimize_func(y)-s1/(s1+s2)*minimize_func(y[mask])-s2/(s1+s2)*minimize_func(y[!mask])
}