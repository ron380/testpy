# Classification Metrics for Decision Trees

## Gini Impurity
Gini Impurity is a very intuitive metric to try to improve because it is a measure of the misclassification rate. If the fraction of the data set that has outcome class $c$ is $f_c$, we can make predictions for each data point as being class $c_1 f_c$ of the time. The error rate for a class is the probability of getting the class times the probability of getting it wrong.
$$
\text { Error }_c=f_c *\left(1-f_c\right)
$$

The Gini Impurity is the sum of these error rates for all classes.
$$
\begin{gathered}
\text { Gini Impurity }=\sum_c \text { Error }_c=\sum_c f_c *\left(1-f_c\right) = \sum_c f_c-\sum_c f_c^2 = 1-\sum_c f_c^2
\end{gathered}
$$

If we divide the data set in regions that improve the weighted sum of the Gini Impurity, the misclassification rate will be reduced.

**Example: Gini Impurity for a Coin Flip**
A coin flip is about as simple as a process there is to calculate the Gini Impurity for. We have a coin with probability of head, $p_H$. The Gini Impurity is then
$$
\text { Gini Impurity }=1-p_H^2-\left(1-p_H\right)^2=2 * p_H *\left(1-p_H\right)
$$

We see that if $p_H=0$ or $p_H=1$ there is no misclassification. If $p_H=0.5$, we see that we get the coin flip wrong $50 \%$ of the time. This should match our intuition.

## Entropy
Another, and less intuitive, measure of prediction accuracy is entropy. It is defined as the expected information content of a class. If $f_c$ is the fraction of the class in a dataset, and $I(c)$ is the information content in the class, then entropy is defined as following
$$
\text { Entropy }=\sum_c f_c * I(c)
$$

For reasons I will not get into in this post, $I(c)=-\log _2\left(f_c\right)$, so the entropy of a dataset follows:
$$
\text { Entropy }=-\sum_c f_c * \log _2\left(f_c\right)
$$

The base 2 of the log can be anything, really. But since we will be using binary trees throughout this series, I will keep the base 2 .


## Pruning the tree

We have built a complete tree, possibly quite large and/or complex, and must now decide how much of that model to retain. In stepwise regression, for instance, this issue is addressed sequentially and the fit is stopped when the $\mathrm{F}$ test fails to achieve some level $\alpha$.
Let $T_1, T_2, \ldots, T_k$ be the terminal nodes of a tree T. Define
$|T|=$ number of terminal nodes
risk of $T=R(T)=\sum_{i=1}^k P\left(T_i\right) R\left(T_i\right)$

In comparison to regression, $|T|$ is analogous to the degrees of freedom and $R(T)$ to the residual sum of squares.

Now let $\alpha$ be some number between 0 and $\infty$ which measures the 'cost' of adding another variable to the model; $\alpha$ will be called a complexity parameter. Let $R\left(T_0\right)$ be the risk for the zero split tree. Define
$$
R_\alpha(T)=R(T)+\alpha|T|
$$

to be the cost for the tree, and define $T_\alpha$ to be that sub tree of the full model which has minimal cost. Obviously $T_0=$ the full model and $T_{\infty}=$ the model with no splits at all. The following results are shown in [1].
1. If $T_1$ and $T_2$ are sub trees of $T$ with $R_\alpha\left(T_1\right)=R_\alpha\left(T_2\right)$, then either $T_1$ is a sub tree of $T_2$ or $T_2$ is a sub tree of $T_1$; hence either $\left|T_1\right|<\left|T_2\right|$ or $\left|T_2\right|<\left|T_1\right|$.
2. If $\alpha>\beta$ then either $T_\alpha=T_\beta$ or $T_\alpha$ is a strict sub tree of $T_\beta$.
3. Given some set of numbers $\alpha_1, \alpha_2, \ldots, \alpha_m$; both $T_{\alpha_1}, \ldots, T_{\alpha_m}$ and $R\left(T_{\alpha_1}\right), \ldots, R\left(T_{\alpha_m}\right)$ can be computed efficiently.

Using the first result, we can uniquely define $T_\alpha$ as the smallest tree $T$ for which $R_\alpha(T)$ is minimized.

Since any sequence of nested trees based on $T$ has at most $|T|$ members, result 2 implies that all possible values of $\alpha$ can be grouped into $m$ intervals, $m \leq|T|$
$$
\begin{aligned}
I_1 & =\left[0, \alpha_1\right] \\
I_2 & =\left(\alpha_1, \alpha_2\right] \\
\vdots & \\
I_m & =\left(\alpha_{m-1}, \infty\right]
\end{aligned}
$$
where all $\alpha \in I_i$ share the same minimizing sub tree.
