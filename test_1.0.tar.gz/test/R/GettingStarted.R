library(Rcpp)

cppFunction('int add(int x, int y, int z) {
  int sum = x + y + z;
  return sum;
}')

# Define a simple C++ function
cpp_code <- '
  #include <Rcpp.h>
  using namespace Rcpp;
  
  // [[Rcpp::export]]
  double my_cpp_function(double x) {
    return x * x;
  }
'

# Specify a directory for caching
cache_dir <- "cache"

# Compile and source the C++ function, using caching
# sourceCpp(code = cpp_code, cacheDir = cache_dir)

# # Now, you can use my_cpp_function without recompilation
# result1 <- my_cpp_function(5)
# result2 <- my_cpp_function(10)

# print(result1)
# print(result2)


# add works like a regular R function
add
#> function (x, y, z) 
#> .Call(<pointer: 0x107536a00>, x, y, z)
add(1, 2, 3)
#> [1] 6