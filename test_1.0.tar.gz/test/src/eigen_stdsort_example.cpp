#include <Eigen/Dense>
#include <iostream>

using namespace Eigen;
using std::cout;

int main() {
    VectorXi v = VectorXi::Random(4);
    cout << "Here is the vector v:\n";
    for(auto x : v) cout << x << " ";
    cout << "\n";

    Array4i v2 = Array4i::Random().abs();
    cout << "Here is the initial vector v2:\n" << v2.transpose() << "\n";
    std::sort(v2.begin(), v2.end());
    cout << "Here is the sorted vector v2:\n" << v2.transpose() << "\n";
    return 0;
}
