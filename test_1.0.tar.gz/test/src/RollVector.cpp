#include <Eigen/Dense>
#include <algorithm>
#include <iostream>

using namespace Eigen;

int main() {
  // Define a vector
  VectorXd v(4);
  v << 1, 2, 3, 4;

  // Shift elements to the left
  std::copy_backward(v.begin()+1, v.end(), v.end()-1);

  // Print the shifted vector
  std::cout << v << std::endl;

  return 0;
}
