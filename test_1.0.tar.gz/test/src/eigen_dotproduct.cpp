#include <Eigen/Dense>
#include <iostream>
#include <algorithm>

using namespace Eigen;
using std::cout, std::endl;


VectorXd arange(double low, double high, double step = 1, bool with_last = false)
{
    //  if with_last == false then we remove the last element 
    high -= (with_last) ? 0 : step;
    int N = static_cast<int>(std::floor((high - low) / step) + 1);
    return VectorXd::LinSpaced(N, low, high);
}


// Standard partition process of QuickSort(). 
// It considers the last element as pivot 
// and moves all smaller element to left of 
// it and greater elements to right 
template <typename T>
size_t partition(std::vector<T> &v, size_t l, size_t r) 
{ 
    T pivot = v[r]; 
    size_t i = l; 
    for (size_t j = l; j <= r - 1; j++) { 
        if (v[j] <= pivot) { 
            swap(v[i], v[j]); 
            i++; 
        } 
    } 
    swap(v[i], v[r]); 
    return i; 
} 

template <typename T>
std::vector<size_t> sort_indexes(const std::vector<T> &v) {

  // initialize original index locations
  std::vector<size_t> idx(v.size());
  std::iota(idx.begin(), idx.end(), 0); //  increasinh sequence starting with 0

  // sort indexes based on comparing values in v
  // using std::stable_sort instead of std::sort
  // to avoid unnecessary index re-orderings
  // when v contains elements of equal values 
  std::stable_sort(idx.begin(), idx.end(),
       [&v](size_t i1, size_t i2) {return v[i1] < v[i2];});

  return idx;
}


int main() {

    std::vector<double> a = {1, 2, 3, 4};
    // VectorXd a()

    VectorXd v = arange(1, 19);
    cout << v << endl;
    
    // int rowNumber = 6, columnNumber = 3;
    // MatrixXd matrixIdentity;
    // matrixIdentity = MatrixXd::Identity(rowNumber,columnNumber);
    // cout << "\n \n" << matrixIdentity << endl;

    

    return 0;
}
