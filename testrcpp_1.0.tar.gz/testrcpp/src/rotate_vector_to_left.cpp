#include <iostream>
#include <vector>
#include <algorithm>
#include <iterator>

using std::cout, std::endl;

void rollLeft(std::vector<int>& vec, size_t positions) {
    // Make sure positions is less than the size of the vector
    positions %= vec.size();
    
    // Use std::rotate to perform the left rotation
    std::rotate(vec.begin(), vec.begin() + positions, vec.end());
}



template <typename T>
void displayVector(const std::vector<T>& vec) {
    // Use std::copy to copy elements to std::cout
    std::copy(vec.begin(), vec.end(), std::ostream_iterator<T>(std::cout, " "));

    // Add a newline at the end
    std::cout << std::endl;
}


int main() {
    // Example usage
    std::vector<int> myVector = {1, 2, 3, 4, 5};

    std::cout << "print vector" << std::endl;
    displayVector(myVector);
    // Number of positions to roll to the left
    size_t positions = 1;

    // Roll the vector to the left
    rollLeft(myVector, positions);

    // Display the rolled vector
    for (const auto& element : myVector) {
        std::cout << element << " ";
    }

    return 0;
}
